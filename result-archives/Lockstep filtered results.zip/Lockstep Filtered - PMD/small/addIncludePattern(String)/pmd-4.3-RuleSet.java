public void addIncludePattern(String includePattern) {
+        this.includePatterns.add(includePattern);
    }