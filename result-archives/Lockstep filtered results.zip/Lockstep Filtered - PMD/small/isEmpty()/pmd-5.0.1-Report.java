public boolean isEmpty() {
+        return !violations.iterator().hasNext() && !hasErrors();
    }
public boolean hasErrors() {
+    	return errors != null;
    }