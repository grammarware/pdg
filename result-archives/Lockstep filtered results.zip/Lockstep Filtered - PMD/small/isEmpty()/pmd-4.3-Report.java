public boolean isEmpty() {
+        return !violations.iterator().hasNext() && errors.isEmpty();
    }