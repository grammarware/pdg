+public String getLine(int number) {
        int count = 1;
+        for (StringTokenizer st = new StringTokenizer(getText(), "\n"); st.hasMoreTokens();) {
            String tok = st.nextToken();
+            if (count == number) {
+                return tok;
            }
            count++;
        }
+        throw new RuntimeException("Line number " + number + " not found");
    }