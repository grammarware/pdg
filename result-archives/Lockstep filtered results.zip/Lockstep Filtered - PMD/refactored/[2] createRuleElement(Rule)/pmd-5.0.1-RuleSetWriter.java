+private Element createRuleElement() {
+    	return document.createElementNS(RULESET_NS_URI, "rule");
    }
private Element createPropertyDefinitionElementBR(PropertyDescriptor<?> propertyDescriptor) {
		
+		final Element propertyElement = createPropertyValueElement(propertyDescriptor, propertyDescriptor.defaultValue());
+		propertyElement.setAttribute(PropertyDescriptorFields.TYPE, PropertyDescriptorUtil.typeIdFor(propertyDescriptor.type()));
		
		Map<String, String> propertyValuesById = propertyDescriptor.attributeValuesById();
+		for (Map.Entry<String, String> entry : propertyValuesById.entrySet()) {
+			propertyElement.setAttribute(entry.getKey(), entry.getValue());
		}
		
+		return propertyElement;
    }
private Element createPropertiesElement() {
+    	return document.createElementNS(RULESET_NS_URI, "properties");
    }
+private Element createRuleElement(Rule rule) {
+		if (rule instanceof RuleReference) {
+		    RuleReference ruleReference = (RuleReference) rule;
+		    RuleSetReference ruleSetReference = ruleReference.getRuleSetReference();
+		    if (ruleSetReference.isAllRules()) {
+			if (!ruleSetFileNames.contains(ruleSetReference.getRuleSetFileName())) {
+			    ruleSetFileNames.add(ruleSetReference.getRuleSetFileName());
+			    Element ruleSetReferenceElement = createRuleSetReferenceElement(ruleSetReference);
+			    return ruleSetReferenceElement;
			} else {
+			    return null;
			}
		    } else {
			Language language = ruleReference.getOverriddenLanguage();
			LanguageVersion minimumLanguageVersion = ruleReference.getOverriddenMinimumLanguageVersion();
			LanguageVersion maximumLanguageVersion = ruleReference.getOverriddenMaximumLanguageVersion();
			Boolean deprecated = ruleReference.isOverriddenDeprecated();
+			String name = ruleReference.getOverriddenName();
+			String ref = ruleReference.getRuleSetReference().getRuleSetFileName() + "/" + ruleReference.getName();
+			String message = ruleReference.getOverriddenMessage();
+			String externalInfoUrl = ruleReference.getOverriddenExternalInfoUrl();
+			String description = ruleReference.getOverriddenDescription();
			RulePriority priority = ruleReference.getOverriddenPriority();
+			List<PropertyDescriptor<?>> propertyDescriptors = ruleReference.getOverriddenPropertyDescriptors();
			Map<PropertyDescriptor<?>, Object> propertiesByPropertyDescriptor = ruleReference.getOverriddenPropertiesByPropertyDescriptor();
+			List<String> examples = ruleReference.getOverriddenExamples();
			
+			return createSingleRuleElement(language, minimumLanguageVersion, maximumLanguageVersion, deprecated,
				name, null, ref, message, externalInfoUrl, null, null, null, description, priority,
				propertyDescriptors, propertiesByPropertyDescriptor, examples);
		    }
		} else {
+		    return createSingleRuleElement(rule instanceof ImmutableLanguage ? null : rule.getLanguage(), 
		    	rule.getMinimumLanguageVersion(), rule.getMaximumLanguageVersion(), rule.isDeprecated(),
			    rule.getName(), rule.getSince(), null, rule.getMessage(), rule.getExternalInfoUrl(),
			    rule.getRuleClass(), rule.usesDFA(), rule.usesTypeResolution(), rule.getDescription(), 
+			    rule.getPriority(), rule.getPropertyDescriptors(), rule.getPropertiesByPropertyDescriptor(),
			    rule.getExamples());
		}
    }
+private Element createExampleElement(String example) {
+    	return createCDATASectionElement("example", example);
    }
private void setIfNonNull(Object value, Element target, String id) {
+    	if (value != null) {
+    		target.setAttribute(id, value.toString());
    	}
    }
+private Element createPropertyValueElement(PropertyDescriptor propertyDescriptor, Object value) {
+		Element propertyElement = document.createElementNS(RULESET_NS_URI, "property");
+		propertyElement.setAttribute("name", propertyDescriptor.name());
+		String valueString = propertyDescriptor.asDelimitedString(value);
+		if (XPathRule.XPATH_DESCRIPTOR.equals(propertyDescriptor)) {
+		    Element valueElement = createCDATASectionElement("value", valueString);
+		    propertyElement.appendChild(valueElement);
		} else {
+		    propertyElement.setAttribute("value", valueString);
		}
	
+		return propertyElement;
    }
+private Element createTextElement(String name, String value) {
+		Element element = document.createElementNS(RULESET_NS_URI, name);
+		Text text = document.createTextNode(value);
+		element.appendChild(text);
+		return element;
    }
+private Element createRuleSetReferenceElement(RuleSetReference ruleSetReference) {
+		Element ruleSetReferenceElement = createRuleElement();
+		ruleSetReferenceElement.setAttribute("ref", ruleSetReference.getRuleSetFileName());
+		for (String exclude : ruleSetReference.getExcludes()) {
+		    Element excludeElement = createExcludeElement(exclude);
+		    ruleSetReferenceElement.appendChild(excludeElement);
		}
+		return ruleSetReferenceElement;
    }
+private Element createDescriptionElement(String description) {
+    	return createTextElement("description", description);
    }
+private Element createPriorityElement(RulePriority priority) {
+    	return createTextElement("priority", String.valueOf(priority.getPriority()));
    }
+private Element createCDATASectionElement(String name, String value) {
+		Element element = document.createElementNS(RULESET_NS_URI, name);
+		CDATASection cdataSection = document.createCDATASection(value);
+		element.appendChild(cdataSection);
+		return element;
    }
+private Element createExcludeElement(String exclude) {
+    	return createTextElement("exclude", exclude);
    }
+@SuppressWarnings("PMD.CompareObjectsWithEquals")
+    private Element createPropertiesElement(List<PropertyDescriptor<?>> propertyDescriptors,  Map<PropertyDescriptor<?>, Object> propertiesByPropertyDescriptor) {

+		Element propertiesElement = null;
+		if (propertyDescriptors != null) {
		    
+		    for (PropertyDescriptor<?> propertyDescriptor : propertyDescriptors) {		// For each provided PropertyDescriptor
			
+			if (propertyDescriptor instanceof PropertyDescriptorWrapper) {				// Any wrapper property needs to go out as a definition.
+			    if (propertiesElement == null) {
+			    	propertiesElement = createPropertiesElement();
			    }
			    
+			    Element propertyElement = createPropertyDefinitionElementBR(((PropertyDescriptorWrapper<?>) propertyDescriptor).getPropertyDescriptor());
+			    propertiesElement.appendChild(propertyElement);
			} else {			    
+			    if (propertiesByPropertyDescriptor != null) {		// Otherwise, any property which has a value different than the default needs to go out as a value.
				Object defaultValue = propertyDescriptor.defaultValue();
				Object value = propertiesByPropertyDescriptor.get(propertyDescriptor);
+				if (value != defaultValue && (value == null || !value.equals(defaultValue))) {
				    if (propertiesElement == null) {
				    	propertiesElement = createPropertiesElement();
				    }
				    
+				    Element propertyElement = createPropertyValueElement(propertyDescriptor, value);
+				    propertiesElement.appendChild(propertyElement);
					}
			    }
			}
		}
	}

+	if (propertiesByPropertyDescriptor != null) {
+	    // Then, for each PropertyDescriptor not explicitly provided
	    for (Map.Entry<PropertyDescriptor<?>, Object> entry : propertiesByPropertyDescriptor.entrySet()) {
		// If not explicitly given...
		PropertyDescriptor<?> propertyDescriptor = entry.getKey();
+		if (!propertyDescriptors.contains(propertyDescriptor)) {
		    // Otherwise, any property which has a value different than the
		    // default needs to go out as a value.
		    Object defaultValue = propertyDescriptor.defaultValue();
		    Object value = entry.getValue();
+		    if (value != defaultValue && (value == null || !value.equals(defaultValue))) {
			if (propertiesElement == null) {
			    propertiesElement = createPropertiesElement();
			}
+			Element propertyElement = createPropertyValueElement(propertyDescriptor, value);
+			propertiesElement.appendChild(propertyElement);
		    }
		}
	    }
	}
+	return propertiesElement;
    }
private Element createSingleRuleElement(Language language, LanguageVersion minimumLanguageVersion,
	    LanguageVersion maximumLanguageVersion, Boolean deprecated, String name, String since, String ref,
	    String message, String externalInfoUrl, String clazz, Boolean dfa, Boolean typeResolution,
+	    String description, RulePriority priority, List<PropertyDescriptor<?>> propertyDescriptors,
	    Map<PropertyDescriptor<?>, Object> propertiesByPropertyDescriptor, List<String> examples) {
+		Element ruleElement = createRuleElement();
+		if (language != null) {
+		    ruleElement.setAttribute("language", language.getTerseName());
		}
+		if (minimumLanguageVersion != null) {
+		    ruleElement.setAttribute("minimumLanguageVersion", minimumLanguageVersion.getVersion());
		}
+		if (maximumLanguageVersion != null) {
+		    ruleElement.setAttribute("maximumLanguageVersion", maximumLanguageVersion.getVersion());
		}
		
		setIfNonNull(deprecated, 	  ruleElement, 	"deprecated");
		setIfNonNull(name, 			  ruleElement, 	"name");
		setIfNonNull(since, 		  ruleElement, 	"since");
+		setIfNonNull(ref, 			  ruleElement,	"ref");
		setIfNonNull(message, 		  ruleElement, 	"message");
		setIfNonNull(clazz, 		  ruleElement, 	"class");
		setIfNonNull(externalInfoUrl, ruleElement,  "externalInfoUrl");
		setIfNonNull(dfa, 			  ruleElement,  "dfa");
		setIfNonNull(typeResolution,  ruleElement,  "typeResolution");
	
+		if (description != null) {
+		    Element descriptionElement = createDescriptionElement(description);
+		    ruleElement.appendChild(descriptionElement);
		}
+		if (priority != null) {
+		    Element priorityElement = createPriorityElement(priority);
+		    ruleElement.appendChild(priorityElement);
		}
+		Element propertiesElement = createPropertiesElement(propertyDescriptors, propertiesByPropertyDescriptor);
+		if (propertiesElement != null) {
+		    ruleElement.appendChild(propertiesElement);
		}
+		if (examples != null) {
+		    for (String example : examples) {
+			Element exampleElement = createExampleElement(example);
+			ruleElement.appendChild(exampleElement);
		    }
		}
+		return ruleElement;
    }