private JComponent createSymbolTableResultPanel() {
+    	symbolTableTreeWidget.setCellRenderer(createNoImageTreeCellRenderer());
+        return new JScrollPane(symbolTableTreeWidget);
    }
+private JMenuBar createMenuBar() {
+        JMenuBar menuBar = new JMenuBar();
+        JMenu menu = new JMenu("JDK");
+        ButtonGroup group = new ButtonGroup();

        for (int i=0; i<sourceTypeSets.length; i++) {
        	JRadioButtonMenuItem button = new JRadioButtonMenuItem(sourceTypeSets[i][0].toString());
        	sourceTypeMenuItems[i] = button;
+        	group.add(button);
+        	menu.add(button);
        }
        sourceTypeMenuItems[defaultSourceTypeSelectionIndex].setSelected(true);
+        menuBar.add(menu);

+        JMenu actionsMenu = new JMenu("Actions");
+        JMenuItem copyXMLItem = new JMenuItem("Copy xml to clipboard");
+        copyXMLItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                copyXmlToClipboard();
            }
        });
+        actionsMenu.add(copyXMLItem);
+        JMenuItem createRuleXMLItem = new JMenuItem("Create rule XML");
+        createRuleXMLItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                createRuleXML();
            }
        });
+        actionsMenu.add(createRuleXMLItem);
+        menuBar.add(actionsMenu);

+        return menuBar;
    }
private static void makeTextComponentUndoable(JTextComponent textConponent) {
+        final UndoManager undoManager = new UndoManager();
+        textConponent.getDocument().addUndoableEditListener(new UndoableEditListener() {
			     public void undoableEditHappened(
			       UndoableEditEvent evt) {
			         undoManager.addEdit(evt.getEdit());
			     }
  			 });
+        ActionMap actionMap = textConponent.getActionMap();
+        InputMap inputMap = textConponent.getInputMap();
+        actionMap.put("Undo", new AbstractAction("Undo") {
		         public void actionPerformed(ActionEvent evt) {
		             try {
		                 if (undoManager.canUndo()) {
		                     undoManager.undo();
		                 }
		             } catch (CannotUndoException e) {
		             }
		         }
        	 });
+        inputMap.put(KeyStroke.getKeyStroke("control Z"), "Undo");

+        actionMap.put("Redo", new AbstractAction("Redo") {
			    public void actionPerformed(ActionEvent evt) {
			        try {
			            if (undoManager.canRedo()) {
			                undoManager.redo();
			            }
			        } catch (CannotRedoException e) {
			        }
			    }
            });
+        inputMap.put(KeyStroke.getKeyStroke("control Y"), "Redo");
    }
+private JPanel createXPathQueryPanel() {
+        JPanel p = new JPanel();
+        p.setLayout(new BorderLayout());
+        xpathQueryArea.setBorder(BorderFactory.createLineBorder(Color.black));
+        makeTextComponentUndoable(xpathQueryArea);
+        JScrollPane scrollPane = new JScrollPane(xpathQueryArea);
+        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
+        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
+        final JButton b = createGoButton();

+        p.add(new JLabel("XPath Query (if any):"), BorderLayout.NORTH);
+        p.add(scrollPane, BorderLayout.CENTER);
+        p.add(b, BorderLayout.SOUTH);

+        return p;
    }
+private JButton createGoButton() {
+        JButton b = new JButton("Go");
+        b.setMnemonic('g');
+        b.addActionListener(new ShowListener());
+        b.addActionListener(codeEditorPane);
+        b.addActionListener(new XPathListener());
+        b.addActionListener(new DFAListener());
+        return b;
    }
private TreeCellRenderer createNoImageTreeCellRenderer() {
+    	DefaultTreeCellRenderer treeCellRenderer = new DefaultTreeCellRenderer();
+    	treeCellRenderer.setLeafIcon(null);
+    	treeCellRenderer.setOpenIcon(null);
+    	treeCellRenderer.setClosedIcon(null);
+    	return treeCellRenderer;
    }
+private JComponent createASTPanel() {
+    	astTreeWidget.setCellRenderer(createNoImageTreeCellRenderer());
+    	TreeSelectionModel model = astTreeWidget.getSelectionModel();
+    	model.setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
+    	model.addTreeSelectionListener(new SymbolTableListener());
+    	model.addTreeSelectionListener(new CodeHighlightListener());
+        return new JScrollPane(astTreeWidget);
    }
+private JComponent createXPathResultPanel() {
+        xpathResults.addElement("No XPath results yet, run an XPath Query first.");
+        xpathResultList.setBorder(BorderFactory.createLineBorder(Color.black));
+        xpathResultList.setFixedCellWidth(300);
+        xpathResultList.setCellRenderer(new ASTListCellRenderer());
+        xpathResultList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
+        xpathResultList.getSelectionModel().addListSelectionListener(new ASTSelectionListener());
+        JScrollPane scrollPane = new JScrollPane();
+        scrollPane.getViewport().setView(xpathResultList);
+        return scrollPane;
    }
+public Designer(String[] args) {
+		if (args.length > 0) {
+			exitOnClose = !args[0].equals("-noexitonclose");
		}

		MatchesFunction.registerSelfInSimpleContext();
        TypeOfFunction.registerSelfInSimpleContext();

+        xpathQueryArea.setFont(new Font("Verdana", Font.PLAIN, 16));
+        JSplitPane controlSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, createCodeEditorPanel(), createXPathQueryPanel());

+        JSplitPane astAndSymbolTablePane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, createASTPanel(), createSymbolTableResultPanel());

+        JSplitPane resultsSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, astAndSymbolTablePane, createXPathResultPanel());

+        JTabbedPane tabbed = new JTabbedPane();
+        tabbed.addTab("Abstract Syntax Tree / XPath / Symbol Table", resultsSplitPane);
+        tabbed.addTab("Data Flow Analysis", dfaPanel);
+        try {
            // Remove when minimal runtime support is >= JDK 1.4
            Method setMnemonicAt = JTabbedPane.class.getMethod("setMnemonicAt", new Class[]{Integer.TYPE, Integer.TYPE});
            if (setMnemonicAt != null) {
                //        // Compatible with >= JDK 1.4
                //        tabbed.setMnemonicAt(0, KeyEvent.VK_A);
                //        tabbed.setMnemonicAt(1, KeyEvent.VK_D);
                setMnemonicAt.invoke(tabbed, new Object[]{NumericConstants.ZERO, KeyEvent.VK_A});
                setMnemonicAt.invoke(tabbed, new Object[]{NumericConstants.ONE, KeyEvent.VK_D});
            }
        } catch (NoSuchMethodException nsme) { // Runtime is < JDK 1.4
+        } catch (IllegalAccessException e) { // Runtime is >= JDK 1.4 but there was an error accessing the function
+            e.printStackTrace();
            throw new InternalError("Runtime reports to be >= JDK 1.4 yet String.split(java.lang.String) is broken.");
+        } catch (IllegalArgumentException e) {
+            e.printStackTrace();
            throw new InternalError("Runtime reports to be >= JDK 1.4 yet String.split(java.lang.String) is broken.");
+        } catch (InvocationTargetException e) { // Runtime is >= JDK 1.4 but there was an error accessing the function
+            e.printStackTrace();
            throw new InternalError("Runtime reports to be >= JDK 1.4 yet String.split(java.lang.String) is broken.");
        }

+        JSplitPane containerSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, controlSplitPane, tabbed);
+        containerSplitPane.setContinuousLayout(true);

+        JMenuBar menuBar = createMenuBar();
+        frame.setJMenuBar(menuBar);
        frame.getContentPane().add(containerSplitPane);
+        frame.setDefaultCloseOperation(exitOnClose ? JFrame.EXIT_ON_CLOSE : JFrame.DISPOSE_ON_CLOSE);

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenHeight = screenSize.height;
        int screenWidth = screenSize.width;

+        frame.pack();
+        frame.setSize((screenWidth*3/4),(screenHeight*3/4));
+        frame.setLocation((screenWidth -frame.getWidth()) / 2, (screenHeight  - frame.getHeight()) / 2);
+        frame.setVisible(true);
        int horozontalMiddleLocation = controlSplitPane.getMaximumDividerLocation() * 3 / 5;
+        controlSplitPane.setDividerLocation(horozontalMiddleLocation);
+        containerSplitPane.setDividerLocation(containerSplitPane.getMaximumDividerLocation() / 2);
+        astAndSymbolTablePane.setDividerLocation(astAndSymbolTablePane.getMaximumDividerLocation()/3);
+        resultsSplitPane.setDividerLocation(horozontalMiddleLocation);
    }
private JComponent createCodeEditorPanel()
    {
+        JPanel p = new JPanel();
+        p.setLayout(new BorderLayout());
+        codeEditorPane.setBorder(BorderFactory.createLineBorder(Color.black));
+        makeTextComponentUndoable(codeEditorPane);

+        p.add(new JLabel("Source code:"), BorderLayout.NORTH);
+        p.add(new JScrollPane(codeEditorPane), BorderLayout.CENTER);

+        return p;
    }