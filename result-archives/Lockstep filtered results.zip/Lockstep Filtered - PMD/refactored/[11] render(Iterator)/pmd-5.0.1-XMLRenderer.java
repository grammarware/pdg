private Element addCodeSnippet(Document doc, Element duplication, Match match) {
+        String codeSnipet = match.getSourceCodeSlice();
        if (codeSnipet != null) {
        	Element codefragment = doc.createElement("codefragment");
            codefragment.appendChild(doc.createCDATASection(codeSnipet));
            duplication.appendChild(codefragment);
        }
        return duplication;
    }
+public String render(Iterator<Match> matches) {
    	Document doc = createDocument();
		Element root = doc.createElement("pmd-cpd");
		doc.appendChild(root);

+        Match match;
+        while (matches.hasNext()) {
+            match = matches.next();
+            root.appendChild( addCodeSnippet(doc, addFilesToDuplicationElement(doc, createDuplicationElement(doc, match), match), match ) );
        }
+        return xmlDocToString(doc);
    }
private Element addFilesToDuplicationElement(Document doc, Element duplication, Match match) {
+    	TokenEntry mark;
+        for (Iterator<TokenEntry> iterator = match.iterator(); iterator.hasNext();) {
+            mark = iterator.next();
            Element file = doc.createElement("file");
            file.setAttribute("line", String.valueOf(mark.getBeginLine()));
            file.setAttribute("path", mark.getTokenSrcID());
            duplication.appendChild(file);
        }
        return duplication;
    }