private LanguageVersion getLanguageVersion() {
+		return getSupportedLanguageVersions()[selectedLanguageVersionIndex()];
	}
private static LanguageVersion[] getSupportedLanguageVersions() {
		List<LanguageVersion> languageVersions = new ArrayList<LanguageVersion>();
+		for (LanguageVersion languageVersion : LanguageVersion.values()) {
			LanguageVersionHandler languageVersionHandler = languageVersion.getLanguageVersionHandler();
+			if (languageVersionHandler != null) {
+				Parser parser = languageVersionHandler.getParser(languageVersionHandler.getDefaultParserOptions());
				if (parser != null && parser.canParse()) {
					languageVersions.add(languageVersion);
				}
			}
		}
		return languageVersions.toArray(new LanguageVersion[languageVersions.size()]);
	}
private int selectedLanguageVersionIndex() {
+		for (int i = 0; i < languageVersionMenuItems.length; i++) {
+			if (languageVersionMenuItems[i].isSelected()) {
+				return i;
			}
		}
+		throw new RuntimeException("Initial default language version not specified");
	}
private Node getCompilationUnit() {
+		LanguageVersionHandler languageVersionHandler = getLanguageVersionHandler();
+		Parser parser = languageVersionHandler.getParser(languageVersionHandler.getDefaultParserOptions());
		Node node = parser.parse(null, new StringReader(codeEditorPane.getText()));
+		languageVersionHandler.getSymbolFacade().start(node);
+		languageVersionHandler.getTypeResolutionFacade(null).start(node);
		return node;
	}
private LanguageVersionHandler getLanguageVersionHandler() {
+		LanguageVersion languageVersion = getLanguageVersion();
		return languageVersion.getLanguageVersionHandler();
	}
private final void copyXmlToClipboard() {
+		if (codeEditorPane.getText() != null && codeEditorPane.getText().trim().length() > 0) {
+			String xml = "";
+			Node cu = getCompilationUnit();
+			if (cu != null) {
+				try {
+					xml = getXmlString(cu);
+				} catch (TransformerException e) {
+					e.printStackTrace();
+					xml = "Error trying to construct XML representation";
				}
			}
+			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(xml), this);
		}
	}
+/**
	 * Returns an unformatted xml string (without the declaration)
	 *
	 * @throws TransformerException if the XML cannot be converted to a string
	 */
	private String getXmlString(Node node) throws TransformerException {
+		StringWriter writer = new StringWriter();

+		Source source = new DOMSource(node.getAsDocument());
+		Result result = new StreamResult(writer);
+		TransformerFactory transformerFactory = TransformerFactory.newInstance();
+		transformerFactory.setAttribute("indent-number", 3);
+		Transformer xformer = transformerFactory.newTransformer();
+		xformer.setOutputProperty(OutputKeys.INDENT, "yes");
+		xformer.transform(source, result);

+		return writer.toString();
	}