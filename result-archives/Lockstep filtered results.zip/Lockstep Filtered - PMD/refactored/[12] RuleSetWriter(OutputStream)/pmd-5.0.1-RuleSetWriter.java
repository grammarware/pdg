+public RuleSetWriter(OutputStream outputStream) {
+		this.outputStream = outputStream;
    }