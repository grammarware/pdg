+private static boolean findBooleanSwitch(String[] args, String name) {
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals(name)) {
+                return true;
            }
        }
+        return false;
    }
private static void setSystemProperties(String[] args) {
+        boolean ignoreLiterals = findBooleanSwitch(args, "--ignore-literals"),
+        ignoreIdentifiers = findBooleanSwitch(args, "--ignore-identifiers");
+        Properties properties = System.getProperties();
+        if (ignoreLiterals) {
+            properties.setProperty(JavaTokenizer.IGNORE_LITERALS, "true");
        }
+        if (ignoreIdentifiers) {
+            properties.setProperty(JavaTokenizer.IGNORE_IDENTIFIERS, "true");
        }
+        System.setProperties(properties);
    }