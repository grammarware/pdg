/**
     * This will write some byte to the stream.
     *
     * @param b The source byte array.
     * @param off The offset into the array to start writing.
     * @param len The number of bytes to write.
     *
     * @throws IOException If the underlying stream throws an exception.
     */
    @Override
+    public void write(byte[] b, int off, int len) throws IOException
    {
        checkPos();
+        setOnNewLine(false);
+        out.write(b, off, len);
+        pos += len;
    }
/**
     * This will set a flag telling if we are on a newline.
     *
     * @param newOnNewLine The new value for the onNewLine attribute.
     */
+    public void setOnNewLine(boolean newOnNewLine)
    {
+        onNewLine = newOnNewLine;
    }