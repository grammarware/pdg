/**
     * This will get a dictionary object by type.
     *
     * @param type The type of the object.
     *
     * @return This will return an object with the specified type.
     * @throws IOException If there is an error getting the object
     */
    public List<COSObject> getObjectsByType( COSName type ) throws IOException
    {
+        List<COSObject> retval = new ArrayList<COSObject>();
+        for( COSObject object : objectPool.values() )
        {
+            COSBase realObject = object.getObject();
+            if( realObject instanceof COSDictionary )
            {
+                try
                {
+                    COSDictionary dic = (COSDictionary)realObject;
+                    COSName objectType = (COSName)dic.getItem( COSName.TYPE );
+                    if( objectType != null && objectType.equals( type ) )
                    {
+                        retval.add( object );
                    }
                }
+                catch (ClassCastException e)
                {
+                    log.warn(e, e);
                }
            }
        }
+        return retval;
    }
+/**
     * This will get an object from the pool.
     *
     * @param key The object key.
     *
     * @return The object in the pool or a new one if it has not been parsed yet.
     *
     * @throws IOException If there is an error getting the proxy object.
     */
    public COSObject getObjectFromPool(COSObjectKey key) throws IOException
    {
+        COSObject obj = null;
+        if( key != null )
        {
+            obj = (COSObject) objectPool.get(key);
        }
+        if (obj == null)
        {
+            // this was a forward reference, make "proxy" object
            obj = new COSObject(null);
+            if( key != null )
            {
+                obj.setObjectNumber( COSInteger.get( key.getNumber() ) );
+                obj.setGenerationNumber( COSInteger.get( key.getGeneration() ) );
+                objectPool.put(key, obj);
            }
        }
+        return obj;
    }
/**
     * This method will search the list of objects for types of ObjStm.  If it finds
     * them then it will parse out all of the objects from the stream that is contains.
     *
     * @throws IOException If there is an error parsing the stream.
     */
    public void dereferenceObjectStreams() throws IOException
    {
+        for( COSObject objStream : getObjectsByType( "ObjStm" ) )
        {
+            COSStream stream = (COSStream)objStream.getObject();
+            PDFObjectStreamParser parser =
                new PDFObjectStreamParser(stream, this, forceParsing);
+            parser.parse();
+            for( COSObject next : parser.getObjects() )
            {
+                COSObjectKey key = new COSObjectKey( next );
+                if(objectPool.get(key) == null || objectPool.get(key).getObject() == null)
                {
+                    COSObject obj = getObjectFromPool(key);
+                    obj.setObject(next.getObject());
                }
            }
        }
    }
/**
     * This will get all dictionary objects by type.
     *
     * @param type The type of the object.
     *
     * @return This will return an object with the specified type.
     * @throws IOException If there is an error getting the object
     */
    public List<COSObject> getObjectsByType( String type ) throws IOException
    {
+        return getObjectsByType( COSName.getPDFName( type ) );
    }