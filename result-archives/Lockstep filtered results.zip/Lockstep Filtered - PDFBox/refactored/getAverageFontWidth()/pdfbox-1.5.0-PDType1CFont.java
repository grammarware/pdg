/**
     * {@inheritDoc}
     */
    public float getAverageFontWidth() throws IOException
    {
+        if( this.avgWidth == null )
        {
+            this.avgWidth = Float.valueOf(this.fontMetric.getAverageCharacterWidth());
        }

+        return this.avgWidth.floatValue();
    }