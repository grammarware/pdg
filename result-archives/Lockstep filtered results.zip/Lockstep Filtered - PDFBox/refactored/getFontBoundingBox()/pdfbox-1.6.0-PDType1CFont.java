private FontMetric prepareFontMetric( CFFFont font ) throws IOException
    {
        byte[] afmBytes = AFMFormatter.format(font);

        InputStream is = new ByteArrayInputStream(afmBytes);
        try
        {
            AFMParser afmParser = new AFMParser(is);
            afmParser.parse();

            FontMetric result = afmParser.getResult();

            // Replace default FontBBox value with a newly computed one
            BoundingBox bounds = result.getFontBBox();
            List<Integer> numbers = Arrays.asList(
                    Integer.valueOf((int)bounds.getLowerLeftX()),
                    Integer.valueOf((int)bounds.getLowerLeftY()),
                    Integer.valueOf((int)bounds.getUpperRightX()),
                    Integer.valueOf((int)bounds.getUpperRightY())
                );
            font.addValueToTopDict("FontBBox", numbers);

+            return result;
        }
        finally
        {
            is.close();
        }
    }
/**
     * {@inheritDoc}
     */
    public PDRectangle getFontBoundingBox() throws IOException
    {
+        if( this.fontBBox == null )
        {
+            this.fontBBox = new PDRectangle(getFontMetric().getFontBBox());
        }

+        return this.fontBBox;
    }
private FontMetric getFontMetric() 
    {
+        if (fontMetric == null)
        {
            try
            {
+                fontMetric = prepareFontMetric(cffFont);
            }
            catch (IOException exception)
            {
                log.error("An error occured while extracting the font metrics!", exception);
            }
        }
+        return fontMetric;
    }