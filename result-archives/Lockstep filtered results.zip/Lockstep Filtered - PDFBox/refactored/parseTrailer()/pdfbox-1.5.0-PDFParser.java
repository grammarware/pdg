/**
     * This will parse the trailer from the stream and add it to the state.
     *            
     * @return false on parsing error
     * @throws IOException If an IO error occurs.
     */
    private boolean parseTrailer() throws IOException
    {
+        if(pdfSource.peek() != 't')
        {
+            return false;
        }
+        //read "trailer"
+        String nextLine = readLine();
+        if( !nextLine.trim().equals( "trailer" ) ) 
        {
+            // in some cases the EOL is missing and the trailer immediately 
            // continues with "<<" or with a blank character
            // even if this does not comply with PDF reference we want to support as many PDFs as possible
            // Acrobat reader can also deal with this.
+            if (nextLine.startsWith("trailer")) 
            {
+                byte[] b = nextLine.getBytes("ISO-8859-1");
+                int len = "trailer".length();
+                pdfSource.unread('\n');
+                pdfSource.unread(b, len, b.length-len);
            }
            else 
            {
+                return false;
            }
        }

        // in some cases the EOL is missing and the trailer continues with " <<"
        // even if this does not comply with PDF reference we want to support as many PDFs as possible
        // Acrobat reader can also deal with this.
+        skipSpaces();

+        COSDictionary parsedTrailer = parseCOSDictionary();
+        COSDictionary docTrailer = document.getTrailer();
+        if( docTrailer == null )
        {
+            document.setTrailer( parsedTrailer );
        }
        else
        {
            docTrailer.addAll( parsedTrailer );
        }
+        skipSpaces();
+        return true;
    }