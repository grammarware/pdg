/**
     * This will parse the startxref section from the stream.
     * The startxref value is ignored.
     *            
     * @return false on parsing error 
     * @throws IOException If an IO error occurs.
     */
    private boolean parseStartXref() throws IOException
    {
+        if(pdfSource.peek() != 's')
        {
+            return false; 
        }
+        String startXRef = readString();
+        if( !startXRef.trim().equals( "startxref" ) )
        {
+            return false;
        }
+        skipSpaces();
        /* This integer is the byte offset of the first object referenced by the xref or xref stream
         * Not needed for PDFbox
         */
        readInt();
+        return true;
    }