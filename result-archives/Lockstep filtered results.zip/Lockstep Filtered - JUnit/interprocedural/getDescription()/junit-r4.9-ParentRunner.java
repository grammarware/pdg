private List<T> getFilteredChildren() {
+		if (fFilteredChildren == null)
+			fFilteredChildren = new ArrayList<T>(getChildren());
+		return fFilteredChildren;
	}
@Override
	public Description getDescription() {
+		Description description= Description.createSuiteDescription(getName(),
				fTestClass.getAnnotations());
+		for (T child : getFilteredChildren())
+			description.addChild(describeChild(child));
+		return description;
	}
/**
	 * Returns a name used to describe this Runner
	 */
	protected String getName() {
+		return fTestClass.getName();
	}