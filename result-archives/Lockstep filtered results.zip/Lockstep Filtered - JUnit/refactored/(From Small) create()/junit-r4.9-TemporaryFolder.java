// testing purposes only
	/**
	 * for testing purposes only.  Do not use.
	 */
	public void create() throws IOException {
+		folder= File.createTempFile("junit", "");
+		folder.delete();
+		folder.mkdir();
	}