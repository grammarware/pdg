/**
	 * Adds a Throwable to the table.  Execution continues, but the test will fail at the end.
	 */
	public void addError(Throwable error) {
+		errors.add(error);
	}
/**
	 * Adds to the table the exception, if any, thrown from {@code callable}.  
	 * Execution continues, but the test will fail at the end if {@code callable}
	 * threw an exception.
	 */
	public Object checkSucceeds(Callable<Object> callable) {
+		try {
+			return callable.call();
+		} catch (Throwable e) {
+			addError(e);
+			return null;
		}		
	}
/**
	 * Adds a failure to the table if {@code matcher} does not match {@code value}.  
	 * Execution continues, but the test will fail at the end if the match fails.
	 */
	public <T> void checkThat(final T value, final Matcher<T> matcher) {
+		checkSucceeds(new Callable<Object>() {
			public Object call() throws Exception {
				assertThat(value, matcher);
				return value;
			}
		});
	}