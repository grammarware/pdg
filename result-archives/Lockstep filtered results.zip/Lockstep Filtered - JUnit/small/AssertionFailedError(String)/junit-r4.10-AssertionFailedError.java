public AssertionFailedError(String message) {
+		super(defaultString(message));
	}