@Test
		public void testUsingTempFolder() throws IOException {
			createdFile= folder.newFile("myfile.txt");
			assertTrue(createdFile.exists());
		}