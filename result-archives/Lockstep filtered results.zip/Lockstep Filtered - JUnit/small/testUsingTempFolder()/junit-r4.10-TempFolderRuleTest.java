@Test
		public void testUsingTempFolder() throws IOException {
			createdFiles[0]= folder.newFile("myfile.txt");
			assertTrue(createdFiles[0].exists());
		}