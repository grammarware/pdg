+/**
     * Return a 512-block buffer size suggestion, based on the size of what
     * needs to be read or written, and default and typical JVM constraints.
     * <P>
     * <B>Algorithm details:</B>
     * </P> <P>
     * Minimum system I want support is a J2SE system with 256M physical
     * RAM.  This system can hold a 61 MB byte array (real 1024^2 M).
     * (61MB with Java 1.6, 62MB with Java 1.4).
     * This decreases to just 60 MB with (pre-production, non-optimized)
     * HSQLDB v. 1.9 on Java 1.6.
     * Allow the user 40 MB of for data (this only corresponds to a much
     * smaller quantity of real data due to the huge overhead of Java and
     * database structures).
     * This allows 20 MB for us to use.  User can easily use more than this
     * by raising JVM settings and/or getting more PRAM or VRAM.
     * Therefore, ceiling = 20MB = 20 MB / .5 Kb = 40 k blocks
     * </P> <P>
     * We make the conservative simplification that each data file contains
     * just one huge data entry component.  This is a good estimation, since in
     * most cases, the contents of the single largest file will be many orders
     * of magnitude larger than the other files and the single block entry
     * headers.
     * </P> <P>
     * We aim for reading or writing these biggest file with 10 reads/writes.
     * In the case of READING Gzip files, there will actually be many more
     * reads than this, but that's the price you pay for smaller file size.
     * </P>
     *
     * @param files  Null array elements are permitted.  They will just be
     *               skipped by the algorithm.
     */
    static protected int generateBufferBlockValue(File[] files) {

+        long maxFileSize = 0;

+        for (File file : files) {
+            if (file == null) {
+                continue;
            }

+            if (file.length() > maxFileSize) {
+                maxFileSize = file.length();
            }
        }

+        int idealBlocks = (int) (maxFileSize / (10L * 512L));

+        // I.e., 1/10 of the file, in units of 512 byte blocks.
        // It's fine that operations will truncate down instead of round.
        if (idealBlocks < 1) {
+            return 1;
        }

+        if (idealBlocks > 40 * 1024) {
+            return 40 * 1024;
        }

+        return idealBlocks;
    }
/**
     * This method always backs up the .properties and .script files.
     * It will back up all of .backup, .data, and .log which exist.
     *
     * If abortUponModify is set, no tar file will be created, and this
     * method will throw.
     *
     * @throws IOException for any of many possible I/O problems
     * @throws IllegalStateException only if abortUponModify is set, and
     *                               database is open or is modified.
     */
    public void write() throws IOException, TarMalformatException {

+        File   propertiesFile = new File(dbDir, instanceName + ".properties");
+        File   scriptFile     = new File(dbDir, instanceName + ".script");
        File[] componentFiles = new File[] {
            propertiesFile, scriptFile,
            new File(dbDir, instanceName + ".backup"),
            new File(dbDir, instanceName + ".data"),
            new File(dbDir, instanceName + ".log"),
            new File(dbDir, instanceName + ".lobs")
        };
        boolean[] existList = new boolean[componentFiles.length];
+        long      startTime = new java.util.Date().getTime();

+        for (int i = 0; i < existList.length; i++) {
+            existList[i] = componentFiles[i].exists();

+            if (i < 2 && !existList[i]) {

+                // First 2 files are REQUIRED
                throw new FileNotFoundException(
                        RB.file_missing.getString(
                        componentFiles[i].getAbsolutePath()));
            }
        }

+        if (abortUponModify) {
+            Properties      p   = new Properties();
+            FileInputStream fis = null;

+            try {
                fis = new FileInputStream(propertiesFile);

+                p.load(fis);
            } finally {
+                try {
+                    if (fis != null) {
+                        fis.close();
                    }
                } finally {
+                    fis = null; // Encourage buffer GC
                }
            }

+            String modifiedString = p.getProperty("modified");

+            if (modifiedString != null
                    && (modifiedString.equalsIgnoreCase("yes")
                        || modifiedString.equalsIgnoreCase("true"))) {
+                throw new IllegalStateException(
                        RB.modified_property.getString(modifiedString));
            }
        }

+        TarGenerator generator = new TarGenerator(archiveFile, overWrite,
+            new Integer(DbBackup.generateBufferBlockValue(componentFiles)));

+        for (File componentFile : componentFiles) {
+            if (!componentFile.exists()) {
+                continue;

                // We've already verified that required files exist, therefore
                // there is no error condition here.
            }

+            generator.queueEntry(componentFile.getName(), componentFile);
        }

+        generator.write();

+        if (abortUponModify) {
+            try {
+                for (int i = 0; i < componentFiles.length; i++) {
+                    if (componentFiles[i].exists()) {
+                        if (!existList[i]) {
+                            throw new FileNotFoundException(
                                    RB.file_disappeared.getString(
                                    componentFiles[i].getAbsolutePath()));
                        }

+                        if (componentFiles[i].lastModified() > startTime) {
+                            throw new FileNotFoundException(
                                    RB.file_changed.getString(
                                    componentFiles[i].getAbsolutePath()));
                        }
+                    } else if (existList[i]) {
+                        throw new FileNotFoundException(
                                RB.file_appeared.getString(
                                componentFiles[i].getAbsolutePath()));
                    }
                }
+            } catch (IllegalStateException ise) {
                if (!archiveFile.delete()) {
                    System.out.println(
                            RB.cleanup_rmfail.getString(
                            archiveFile.getAbsolutePath()));

                    // Be-it-known.  This method can write to stderr if
                    // abortUponModify is true.
                }

+                throw ise;
            }
        }
    }