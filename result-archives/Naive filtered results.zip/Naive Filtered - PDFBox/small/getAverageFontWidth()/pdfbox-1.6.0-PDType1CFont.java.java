/**
     * {@inheritDoc}
     */
    public float getAverageFontWidth() throws IOException
    {
+        if( this.avgWidth == null )
        {
+            this.avgWidth = Float.valueOf(getFontMetric().getAverageCharacterWidth());
        }

        return this.avgWidth.floatValue();
    }