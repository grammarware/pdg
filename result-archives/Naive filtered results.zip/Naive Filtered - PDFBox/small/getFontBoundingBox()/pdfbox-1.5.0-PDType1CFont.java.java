/**
     * {@inheritDoc}
     */
    public PDRectangle getFontBoundingBox() throws IOException
    {
+        if( this.fontBBox == null )
        {
+            this.fontBBox = new PDRectangle(this.fontMetric.getFontBBox());
        }

        return this.fontBBox;
    }