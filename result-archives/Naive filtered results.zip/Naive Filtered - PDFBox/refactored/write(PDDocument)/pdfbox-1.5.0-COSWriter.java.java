/**
     * This will write the pdf document.
     *
     * @param doc The document to write.
     *
     * @throws COSVisitorException If an error occurs while generating the data.
     */
    public void write(PDDocument doc) throws COSVisitorException
    {
        document = doc;
        
+        // if the document says we should remove encryption, then we shouldn't encrypt
        if(doc.isAllSecurityToBeRemoved())
        {
+            this.willEncrypt = false;
+            // also need to get rid of the "Encrypt" in the trailer so readers 
            // don't try to decrypt a document which is not encrypted
            COSDocument cosDoc = doc.getDocument();
+            COSDictionary trailer = cosDoc.getTrailer();
+            trailer.removeItem(COSName.ENCRYPT);
        }
        else
        {
+            SecurityHandler securityHandler = document.getSecurityHandler();
+            if(securityHandler != null)
            {
+                try
                {
+                    securityHandler.prepareDocumentForEncryption(document);
+                    this.willEncrypt = true;
                }
+                catch(IOException e)
                {
+                    throw new COSVisitorException( e );
                }
+                catch(CryptographyException e)
                {
+                    throw new COSVisitorException( e );
                }
            }
            else
            {
+                    this.willEncrypt = false;
            }        
        }

+        COSDocument cosDoc = document.getDocument();
+        COSDictionary trailer = cosDoc.getTrailer();
+        COSArray idArray = (COSArray)trailer.getDictionaryObject( COSName.ID );
+        if( idArray == null )
        {
+            try
            {

+                //algorithm says to use time/path/size/values in doc to generate
                //the id.  We don't have path or size, so do the best we can
+                MessageDigest md = MessageDigest.getInstance( "MD5" );
+                md.update( Long.toString( System.currentTimeMillis()).getBytes("ISO-8859-1") );
+                COSDictionary info = (COSDictionary)trailer.getDictionaryObject( COSName.INFO );
+                if( info != null )
                {
+                    Iterator<COSBase> values = info.getValues().iterator();
+                    while( values.hasNext() )
                    {
+                        md.update( values.next().toString().getBytes("ISO-8859-1") );
                    }
                }
+                idArray = new COSArray();
+                COSString id = new COSString( md.digest() );
+                idArray.add( id );
+                idArray.add( id );
+                trailer.setItem( COSName.ID, idArray );
            }
+            catch( NoSuchAlgorithmException e )
            {
+                throw new COSVisitorException( e );
            }
+            catch( UnsupportedEncodingException e )
            {
+                throw new COSVisitorException( e );
            }
        }
+        cosDoc.accept(this);
    }