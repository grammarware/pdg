/**
     * This will set the standard output stream.
     *
     * @param newStandardOutput The new standard output stream.
     */
+    private void setStandardOutput(COSStandardOutputStream newStandardOutput)
    {
+        standardOutput = newStandardOutput;
    }
/**
     * COSWriter constructor comment.
     *
     * @param os The wrapped output stream.
     */
    public COSWriter(OutputStream os)
    {
        super();
+        setOutput(os);
+        setStandardOutput(new COSStandardOutputStream(output));
+        formatDecimal.setMaximumFractionDigits( 10 );
+        formatDecimal.setGroupingUsed( false );
    }
/**
     * This will set the output stream.
     *
     * @param newOutput The new output stream.
     */
    private void setOutput( OutputStream newOutput )
    {
+        output = newOutput;
    }