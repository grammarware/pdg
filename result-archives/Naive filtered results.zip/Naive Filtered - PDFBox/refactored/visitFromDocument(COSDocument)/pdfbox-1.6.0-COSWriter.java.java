/**
     * This will write the body of the document.
     *
     * @param doc The document to write the body for.
     *
     * @throws IOException If there is an error writing the data.
     * @throws COSVisitorException If there is an error generating the data.
     */
    protected void doWriteBody(COSDocument doc) throws IOException, COSVisitorException
    {
+        COSDictionary trailer = doc.getTrailer();
+        COSDictionary root = (COSDictionary)trailer.getDictionaryObject( COSName.ROOT );
+        COSDictionary info = (COSDictionary)trailer.getDictionaryObject( COSName.INFO );
+        COSDictionary encrypt = (COSDictionary)trailer.getDictionaryObject( COSName.ENCRYPT );
+          if( root != null )
          {
+              addObjectToWrite( root );
          }
+          if( info != null )
          {
+              addObjectToWrite( info );
          }

+        while( objectsToWrite.size() > 0 )
        {
+            COSBase nextObject = (COSBase)objectsToWrite.removeFirst();
+            objectsToWriteSet.remove(nextObject);
+            doWriteObject( nextObject );
        }


+        willEncrypt = false;

+        if( encrypt != null )
        {
+            addObjectToWrite( encrypt );
        }

+        while( objectsToWrite.size() > 0 )
        {
+            COSBase nextObject = (COSBase)objectsToWrite.removeFirst();
+            objectsToWriteSet.remove(nextObject);
+            doWriteObject( nextObject );
        }
    }
/**
     * check the xref entries and write out the ranges.  The format of the
     * returned array is exactly the same as the pdf specification.  See section
     * 7.5.4 of ISO32000-1:2008, example 1 (page 40) for reference.
     * <p>
     * example: 0 1 2 5 6 7 8 10
     * <p>
     * will create a array with follow ranges
     * <p>
     * 0 3 5 4 10 1
     * <p>
     * this mean that the element 0 is followed by two other related numbers 
     * that represent a cluster of the size 3. 5 is follow by three other
     * related numbers and create a cluster of size 4. etc.
     * 
     * @param xRefEntries list with the xRef entries that was written
     * @return a integer array with the ranges
     */
    protected Integer[] getXRefRanges(List<COSWriterXRefEntry> xRefEntries)
    {
+        int nr = 0;
+        int last = -2;
+        int count = 1;

        ArrayList<Integer> list = new ArrayList<Integer>();
+        for( Object object : xRefEntries )
        {
            nr = (int)((COSWriterXRefEntry)object).getKey().getNumber();
+            if (nr == last + 1)
            {
                ++count;
                last = nr;
            }
+            else if (last == -2)
            {
                last = nr;
            }
            else
            {
+                list.add(last - count + 1);
+                list.add(count);
                last = nr;
                count = 1;
            }
        }
+        // If no new entry is found, we need to write out the last result
        if(xRefEntries.size() > 0)
        {
+            list.add(last - count + 1);
+            list.add(count);
        }
        return list.toArray(new Integer[list.size()]);
    }
/**
     * The visit from document method.
     *
     * @param doc The object that is being visited.
     *
     * @throws COSVisitorException If there is an exception while visiting this object.
     *
     * @return null
     */
    public Object visitFromDocument(COSDocument doc) throws COSVisitorException
    {
        try
        {
+            if(!incrementalUpdate)
+                doWriteHeader(doc);
+            doWriteBody(doc);
+            if(incrementalUpdate)
+                doWriteXRefInc(doc);
            else
+                doWriteXRef(doc);
+            doWriteTrailer(doc);
+            doWriteSignature(doc);
            
+            return null;
        }
+        catch (IOException e)
        {
+            throw new COSVisitorException(e);
        }
+        catch (SignatureException e)
        {
+            throw new COSVisitorException(e);
        }
    }
/**
     * This will write a COS object.
     *
     * @param obj The object to write.
     *
     * @throws COSVisitorException If there is an error visiting objects.
     */
+    public void doWriteObject( COSBase obj ) throws COSVisitorException
    {
+        try
        {
+            writtenObjects.add( obj );
+            if(obj instanceof COSDictionary) 
            {
+                COSDictionary dict = (COSDictionary)obj;
                COSName item = (COSName)dict.getItem(COSName.TYPE);
                if(COSName.SIG.equals(item)) {
                    reachedSignature = true;
                }
            }
            
+            // find the physical reference
+            currentObjectKey = getObjectKey( obj );
            // add a x ref entry
+            addXRefEntry( new COSWriterXRefEntry(getStandardOutput().getPos(), obj, currentObjectKey));
            // write the object
+            getStandardOutput().write(String.valueOf(currentObjectKey.getNumber()).getBytes("ISO-8859-1"));
+            getStandardOutput().write(SPACE);
+            getStandardOutput().write(String.valueOf(currentObjectKey.getGeneration()).getBytes("ISO-8859-1"));
+            getStandardOutput().write(SPACE);
+            getStandardOutput().write(OBJ);
+            getStandardOutput().writeEOL();
+            obj.accept( this );
+            getStandardOutput().writeEOL();
+            getStandardOutput().write(ENDOBJ);
+            getStandardOutput().writeEOL();
        }
+        catch (IOException e)
        {
+            throw new COSVisitorException(e);
        }
    }
/**
     * This will write the trailer to the PDF document.
     *
     * @param doc The document to create the trailer for.
     *
     * @throws IOException If there is an IOError while writing the document.
     * @throws COSVisitorException If there is an error while generating the data.
     */
    protected void doWriteTrailer(COSDocument doc) throws IOException, COSVisitorException
    {
+        getStandardOutput().write(TRAILER);
+        getStandardOutput().writeEOL();

+        COSDictionary trailer = doc.getTrailer();
        //sort xref, needed only if object keys not regenerated
+        Collections.sort(getXRefEntries());
+        COSWriterXRefEntry lastEntry = getXRefEntries().get( getXRefEntries().size()-1);
+        trailer.setInt(COSName.SIZE, (int)lastEntry.getKey().getNumber()+1);
+        // Only need to stay, if an incremental update will be performed
        if (!incrementalUpdate)
+          trailer.removeItem( COSName.PREV );
        // Remove a checksum if present
+        trailer.removeItem( COSName.getPDFName("DocChecksum") );
        
        /**
        COSObject catalog = doc.getCatalog();
        if (catalog != null)
        {
            trailer.setItem(COSName.getPDFName("Root"), catalog);
        }
        */
+        trailer.accept(this);

+        getStandardOutput().write(STARTXREF);
+        getStandardOutput().writeEOL();
+        getStandardOutput().write(String.valueOf(getStartxref()).getBytes("ISO-8859-1"));
+        getStandardOutput().writeEOL();
+        getStandardOutput().write(EOF);
+        getStandardOutput().writeEOL();
    }
/**
     * add an entry in the x ref table for later dump.
     *
     * @param entry The new entry to add.
     */
    protected void addXRefEntry(COSWriterXRefEntry entry)
    {
+        getXRefEntries().add(entry);
    }
+private void addObjectToWrite( COSBase object )
    {
+        COSBase actual = object;
+        if( actual instanceof COSObject )
        {
+            actual = ((COSObject)actual).getObject();
        }

+        if( !writtenObjects.contains( object ) &&
            !objectsToWriteSet.contains( object ) &&
            !actualsAdded.contains( actual ) )
        {
+            COSBase cosBase=null;
+            COSObjectKey cosObjectKey = null;
+            if(actual != null)
+                cosObjectKey= objectKeys.get(actual);
          
+            if(cosObjectKey!=null)
+                cosBase = keyObject.get(cosObjectKey);
          
+            if(actual != null && objectKeys.containsKey(actual) &&
                    !object.isNeedToBeUpdate() && (cosBase!= null &&
                    !cosBase.isNeedToBeUpdate()))
            {
                return;
            }
          
+            objectsToWrite.add( object );
+            objectsToWriteSet.add( object );
+            if( actual != null )
            {
+                actualsAdded.add( actual );
            }
        }
    }
+/**
     * This will get the current object number.
     *
     * @return The current object number.
     */
    protected long getNumber()
    {
+        return number;
    }
protected void writeXrefRange(long x, long y) throws IOException
    {
+        getStandardOutput().write(String.valueOf(x).getBytes());
+        getStandardOutput().write(SPACE);
+        getStandardOutput().write(String.valueOf(y).getBytes());
+        getStandardOutput().writeEOL();
    }
protected void doWriteXRefInc(COSDocument doc) throws IOException
    {
+        COSDictionary trailer = doc.getTrailer();
+        trailer.setLong(COSName.PREV, doc.getStartXref());
+        addXRefEntry(COSWriterXRefEntry.getNullEntry());

        // sort xref, needed only if object keys not regenerated
+        Collections.sort(getXRefEntries());
      
        // remember the position where x ref was written
+        setStartxref(getStandardOutput().getPos());

+        getStandardOutput().write(XREF);
+        getStandardOutput().writeEOL();
        // write start object number and object count for this x ref section
        // we assume starting from scratch

+        Integer[] xRefRanges = getXRefRanges(getXRefEntries());
+        int xRefLength = xRefRanges.length;
+        int x = 0;
+        int j = 0;
+        while(x < xRefLength && (xRefLength % 2) == 0)
        {
+            writeXrefRange(xRefRanges[x], xRefRanges[x + 1]);

+            for(int i = 0 ; i < xRefRanges[x + 1] ; ++i)
            {
+                writeXrefEntry(xRefEntries.get(j++));
            }
            x += 2;
        }
    }
/**
     * This will set the start xref.
     *
     * @param newStartxref The new start xref attribute.
     */
    protected void setStartxref(long newStartxref)
    {
+        startxref = newStartxref;
    }
/**
     * This will get the xref entries.
     *
     * @return All available xref entries.
     */
    protected List<COSWriterXRefEntry> getXRefEntries()
    {
+        return xRefEntries;
    }
/**
     * write the x ref section for the pdf file
     *
     * currently, the pdf is reconstructed from the scratch, so we write a single section
     *
     * todo support for incremental writing?
     *
     * @param doc The document to write the xref from.
     *
     * @throws IOException If there is an error writing the data to the stream.
     */
    protected void doWriteXRef(COSDocument doc) throws IOException
    {
        // sort xref, needed only if object keys not regenerated
+        Collections.sort(getXRefEntries());
+        COSWriterXRefEntry lastEntry = getXRefEntries().get( getXRefEntries().size()-1 );

        // remember the position where x ref is written
+        setStartxref(getStandardOutput().getPos());
        //
+        getStandardOutput().write(XREF);
+        getStandardOutput().writeEOL();
        // write start object number and object count for this x ref section
        // we assume starting from scratch
+        writeXrefRange(0, lastEntry.getKey().getNumber() + 1);
        // write initial start object with ref to first deleted object and magic generation number
+        writeXrefEntry(COSWriterXRefEntry.getNullEntry());
+        // write entry for every object
        long lastObjectNumber = 0;
+        for (Iterator<COSWriterXRefEntry> i = getXRefEntries().iterator(); i.hasNext();)
        {
+            COSWriterXRefEntry entry = i.next();
+            while( lastObjectNumber<entry.getKey().getNumber()-1 )
            {
+              writeXrefEntry(COSWriterXRefEntry.getNullEntry());
            }
+            lastObjectNumber = entry.getKey().getNumber();
+            writeXrefEntry(entry);
        }
    }
/**
     * This will get the current start xref.
     *
     * @return The current start xref.
     */
    protected long getStartxref()
    {
+        return startxref;
    }
/**
     * This will set the current object number.
     *
     * @param newNumber The new object number.
     */
+    protected void setNumber(long newNumber)
    {
+        number = newNumber;
    }
protected void doWriteSignature(COSDocument doc) throws IOException, SignatureException
    {
+        // need to calculate the ByteRange
        if (signaturePosition[0]>0 && byterangePosition[1] > 0)
        {
+            int left = (int)getStandardOutput().getPos()-signaturePosition[1];
+            String newByteRange = "0 "+signaturePosition[0]+" "+signaturePosition[1]+" "+left+"]";
+            int leftByterange = byterangePosition[1]-byterangePosition[0]-newByteRange.length();
+            if(leftByterange<0)
                throw new IOException("Can't write new ByteRange, not enough space");
+            getStandardOutput().setPos(byterangePosition[0]);
+            getStandardOutput().write(newByteRange.getBytes());
+            for(int i=0;i<leftByterange;++i)
            {
+                getStandardOutput().write(0x20);
            }
        
+            getStandardOutput().setPos(0);
+            // Begin - extracting document
            InputStream filterInputStream = new COSFilterInputStream(in, new int[] {0,signaturePosition[0],signaturePosition[1],left});
+            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try {
                byte[] buffer = new byte[1024];
+                int c;
+                while((c = filterInputStream.read(buffer)) != -1)
+                    bytes.write(buffer, 0, c);
            } finally {
                if(filterInputStream !=null)
                    filterInputStream.close();
            }

            byte[] pdfContent = bytes.toByteArray();
            // End - extracting document
        
+            SignatureInterface signatureInterface = doc.getSignatureInterface();
            byte[] sign = signatureInterface.sign(new ByteArrayInputStream(pdfContent));
+            String signature = new COSString(sign).getHexString();
+            int leftSignaturerange = signaturePosition[1]-signaturePosition[0]-signature.length();
+            if(leftSignaturerange<0)
                throw new IOException("Can't write signature, not enough space");
+            getStandardOutput().setPos(signaturePosition[0]+1);
+            getStandardOutput().write(signature.getBytes());
        }
    }
+/**
     * This will get the standard output stream.
     *
     * @return The standard output stream.
     */
    protected COSStandardOutputStream getStandardOutput()
    {
+        return standardOutput;
    }
+/**
     * This will get the object key for the object.
     *
     * @param obj The object to get the key for.
     *
     * @return The object key for the object.
     */
+    private COSObjectKey getObjectKey( COSBase obj )
    {
+        COSBase actual = obj;
+        if( actual instanceof COSObject )
        {
+            actual = ((COSObject)obj).getObject();
        }
+        COSObjectKey key = null;
+        if( actual != null )
        {
+            key = objectKeys.get(actual);
        }
+        if( key == null )
        {
+            key = objectKeys.get(obj);
        }
+        if (key == null)
        {
+            setNumber(getNumber()+1);
+            key = new COSObjectKey(getNumber(),0);
+            objectKeys.put(obj, key);
+            if( actual != null )
            {
+                objectKeys.put(actual, key);
            }
        }
+        return key;
    }
/**
     * This will write the header to the PDF document.
     *
     * @param doc The document to get the data from.
     *
     * @throws IOException If there is an error writing to the stream.
     */
    protected void doWriteHeader(COSDocument doc) throws IOException
    {
+        getStandardOutput().write( doc.getHeaderString().getBytes("ISO-8859-1") );
+        getStandardOutput().writeEOL();
+        getStandardOutput().write(COMMENT);
+        getStandardOutput().write(GARBAGE);
+        getStandardOutput().writeEOL();
    }
protected void writeXrefEntry(COSWriterXRefEntry entry) throws IOException
    {
+        String offset = formatXrefOffset.format(entry.getOffset());
+        String generation = formatXrefGeneration.format(entry.getKey().getGeneration());
+        getStandardOutput().write(offset.getBytes("ISO-8859-1"));
+        getStandardOutput().write(SPACE);
+        getStandardOutput().write(generation.getBytes("ISO-8859-1"));
+        getStandardOutput().write(SPACE);
+        getStandardOutput().write(entry.isFree() ? XREF_FREE : XREF_USED);
+        getStandardOutput().writeCRLF();
    }