/**
     * {@inheritDoc}
     */
    public float getFontWidth( byte[] bytes, int offset, int length ) throws IOException
    {
        String name = getName(bytes, offset, length);
+        if( name == null && !Arrays.equals(SPACE_BYTES, bytes) )
        {
+            log.debug("No name for code " + (bytes[offset] & 0xff) + " in " + this.cffFont.getName());

+            return 0;
        }

+        Float width = (Float)this.glyphWidths.get(name);
+        if( width == null )
        {
+            width = Float.valueOf(this.fontMetric.getCharacterWidth(name));
+            this.glyphWidths.put(name, width);
        }

+        return width.floatValue();
    }
private String getName( byte[] bytes, int offset, int length )
    {
+        if (length > 2)
        {
+            return null;
        }
        
+        int code = bytes[offset] & 0xff;
+        if (length == 2)
        {
+            code = code * 256 + bytes[offset+1] & 0xff;
        }

+        return (String)this.codeToName.get(code);
    }