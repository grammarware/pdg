/**
     * This will set the start xref.
     *
     * @param newStartxref The new start xref attribute.
     */
    protected void setStartxref(long newStartxref)
    {
+        startxref = newStartxref;
    }
/**
     * write the x ref section for the pdf file
     *
     * currently, the pdf is reconstructed from the scratch, so we write a single section
     *
     * todo support for incremental writing?
     *
     * @param doc The document to write the xref from.
     *
     * @throws IOException If there is an error writing the data to the stream.
     */
    protected void doWriteXRef(COSDocument doc) throws IOException
    {
        // sort xref, needed only if object keys not regenerated
        Collections.sort(getXRefEntries());
        COSWriterXRefEntry lastEntry = getXRefEntries().get( getXRefEntries().size()-1 );

        // remember the position where x ref is written
+        setStartxref(getStandardOutput().getPos());
        //
        getStandardOutput().write(XREF);
        getStandardOutput().writeEOL();
        // write start object number and object count for this x ref section
        // we assume starting from scratch
        writeXrefRange(0, lastEntry.getKey().getNumber() + 1);
        // write initial start object with ref to first deleted object and magic generation number
        writeXrefEntry(COSWriterXRefEntry.getNullEntry());
        // write entry for every object
        long lastObjectNumber = 0;
+        for (Iterator<COSWriterXRefEntry> i = getXRefEntries().iterator(); i.hasNext();)
        {
+            COSWriterXRefEntry entry = i.next();
+            while( lastObjectNumber<entry.getKey().getNumber()-1 )
            {
+              writeXrefEntry(COSWriterXRefEntry.getNullEntry());
            }
+            lastObjectNumber = entry.getKey().getNumber();
+            writeXrefEntry(entry);
        }
    }
/**
     * This will get the standard output stream.
     *
     * @return The standard output stream.
     */
    protected COSStandardOutputStream getStandardOutput()
    {
+        return standardOutput;
    }
protected void writeXrefEntry(COSWriterXRefEntry entry) throws IOException
    {
+        String offset = formatXrefOffset.format(entry.getOffset());
+        String generation = formatXrefGeneration.format(entry.getKey().getGeneration());
+        getStandardOutput().write(offset.getBytes("ISO-8859-1"));
+        getStandardOutput().write(SPACE);
+        getStandardOutput().write(generation.getBytes("ISO-8859-1"));
+        getStandardOutput().write(SPACE);
+        getStandardOutput().write(entry.isFree() ? XREF_FREE : XREF_USED);
+        getStandardOutput().writeCRLF();
    }