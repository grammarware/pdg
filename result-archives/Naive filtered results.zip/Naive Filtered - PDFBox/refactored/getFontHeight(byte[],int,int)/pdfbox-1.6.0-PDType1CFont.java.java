/**
     * {@inheritDoc}
     */
    public float getFontHeight( byte[] bytes, int offset, int length ) throws IOException
    {
        String name = getName(bytes, offset, length);
+        if( name == null )
        {
+            log.debug("No name for code " + (bytes[offset] & 0xff) + " in " + this.cffFont.getName());

+            return 0;
        }

+        Float height = (Float)this.glyphHeights.get(name);
+        if( height == null )
        {
+            height = Float.valueOf(getFontMetric().getCharacterHeight(name));
+            this.glyphHeights.put(name, height);
        }

+        return height.floatValue();
    }
+private FontMetric prepareFontMetric( CFFFont font ) throws IOException
    {
        byte[] afmBytes = AFMFormatter.format(font);

+        InputStream is = new ByteArrayInputStream(afmBytes);
        try
        {
+            AFMParser afmParser = new AFMParser(is);
+            afmParser.parse();

+            FontMetric result = afmParser.getResult();

+            // Replace default FontBBox value with a newly computed one
            BoundingBox bounds = result.getFontBBox();
            List<Integer> numbers = Arrays.asList(
                    Integer.valueOf((int)bounds.getLowerLeftX()),
                    Integer.valueOf((int)bounds.getLowerLeftY()),
                    Integer.valueOf((int)bounds.getUpperRightX()),
                    Integer.valueOf((int)bounds.getUpperRightY())
                );
+            font.addValueToTopDict("FontBBox", numbers);

            return result;
        }
        finally
        {
            is.close();
        }
    }
private FontMetric getFontMetric() 
    {
+        if (fontMetric == null)
        {
            try
            {
+                fontMetric = prepareFontMetric(cffFont);
            }
            catch (IOException exception)
            {
+                log.error("An error occured while extracting the font metrics!", exception);
            }
        }
        return fontMetric;
    }
private String getName( byte[] bytes, int offset, int length )
    {
+        if (length > 2)
        {
+            return null;
        }
        
+        int code = bytes[offset] & 0xff;
+        if (length == 2)
        {
+            code = code * 256 + bytes[offset+1] & 0xff;
        }

+        return (String)this.codeToName.get(code);
    }