/**
     * {@inheritDoc}
     */
    public float getFontHeight( byte[] bytes, int offset, int length ) throws IOException
    {
        String name = getName(bytes, offset, length);
+        if( name == null )
        {
+            log.debug("No name for code " + (bytes[offset] & 0xff) + " in " + this.cffFont.getName());

+            return 0;
        }

+        Float height = (Float)this.glyphHeights.get(name);
+        if( height == null )
        {
+            height = Float.valueOf(this.fontMetric.getCharacterHeight(name));
+            this.glyphHeights.put(name, height);
        }

+        return height.floatValue();
    }
private String getName( byte[] bytes, int offset, int length )
    {
+        if (length > 2)
        {
+            return null;
        }
        
+        int code = bytes[offset] & 0xff;
+        if (length == 2)
        {
+            code = code * 256 + bytes[offset+1] & 0xff;
        }

+        return (String)this.codeToName.get(code);
    }