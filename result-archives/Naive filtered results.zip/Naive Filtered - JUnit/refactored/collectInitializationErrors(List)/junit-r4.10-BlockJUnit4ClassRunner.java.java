/**
	 * Adds to {@code errors} if the test class's single constructor takes
	 * parameters (do not override)
	 */
	protected void validateZeroArgConstructor(List<Throwable> errors) {
+		if (!getTestClass().isANonStaticInnerClass()
+				&& hasOneConstructor()
				&& (getTestClass().getOnlyConstructor().getParameterTypes().length != 0)) {
+			String gripe= "Test class should have exactly one public zero-argument constructor";
+			errors.add(new Exception(gripe));
		}
	}
/**
	 * Adds to {@code errors} if the test class has more than one constructor,
	 * or if the constructor takes parameters. Override if a subclass requires
	 * different validation rules.
	 */
	protected void validateConstructor(List<Throwable> errors) {
+		validateOnlyOneConstructor(errors);
+		validateZeroArgConstructor(errors);
	}
/**
	 * Returns the methods that run tests. Default implementation returns all
	 * methods annotated with {@code @Test} on this class and superclasses that
	 * are not overridden.
	 */
	protected List<FrameworkMethod> computeTestMethods() {
+		return getTestClass().getAnnotatedMethods(Test.class);
	}
protected void validateNoNonStaticInnerClass(List<Throwable> errors) {
+		if (getTestClass().isANonStaticInnerClass()) {
+			String gripe= "The inner class " + getTestClass().getName()
					+ " is not static.";
+			errors.add(new Exception(gripe));
		}
	}
/**
	 * Adds to {@code errors} for each method annotated with {@code @Test},
	 * {@code @Before}, or {@code @After} that is not a public, void instance
	 * method with no arguments.
	 * 
	 * @deprecated unused API, will go away in future version
	 */
	@Deprecated
	protected void validateInstanceMethods(List<Throwable> errors) {
+		validatePublicVoidNoArgMethods(After.class, false, errors);
+		validatePublicVoidNoArgMethods(Before.class, false, errors);
+		validateTestMethods(errors);

+		if (computeTestMethods().size() == 0)
+			errors.add(new Exception("No runnable methods"));
	}
private boolean hasOneConstructor() {
+		return getTestClass().getJavaClass().getConstructors().length == 1;
	}
private void validateFields(List<Throwable> errors) {
+		RULE_VALIDATOR.validate(getTestClass(), errors);
	}
/**
	 * Adds to {@code errors} if the test class has more than one constructor
	 * (do not override)
	 */
	protected void validateOnlyOneConstructor(List<Throwable> errors) {
+		if (!hasOneConstructor()) {
+			String gripe= "Test class should have exactly one public constructor";
+			errors.add(new Exception(gripe));
		}
	}
@Override
	protected void collectInitializationErrors(List<Throwable> errors) {
		super.collectInitializationErrors(errors);

+		validateNoNonStaticInnerClass(errors);
+		validateConstructor(errors);
+		validateInstanceMethods(errors);
+		validateFields(errors);
	}
/**
	 * Adds to {@code errors} for each method annotated with {@code @Test}that
	 * is not a public, void instance method with no arguments.
	 */
	protected void validateTestMethods(List<Throwable> errors) {
+		validatePublicVoidNoArgMethods(Test.class, false, errors);
	}