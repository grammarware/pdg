public Object visit(MethodNode methodNode, Object data) {
+		if (methodNode.getUsers().isEmpty()) {
+			boolean log = true;
+			if (options.isIgnoreMethodAllOverride()) {
+				if (ClassLoaderUtil.isOverridenMethod(methodNode.getClassNode().getClass(), methodNode.getMember(),
						false)) {
+					ignore("method all override", methodNode);
+					log = false;
				}
+			} else if (options.isIgnoreMethodJavaLangObjectOverride()) {
+				if (ClassLoaderUtil.isOverridenMethod(java.lang.Object.class, methodNode.getMember(), true)) {
+					ignore("method java.lang.Object override", methodNode);
+					log = false;
				}
			}
+			if (options.isIgnoreMethodMain()) {
+				if (methodNode.getMember().getName().equals("main")
						&& Modifier.isPublic(methodNode.getMember().getModifiers())
						&& Modifier.isStatic(methodNode.getMember().getModifiers())
						&& methodNode.getMember().getReturnType() == Void.TYPE
						&& methodNode.getMember().getParameterTypes().length == 1
						&& methodNode.getMember().getParameterTypes()[0].isArray()
						&& methodNode.getMember().getParameterTypes()[0].getComponentType().equals(
								java.lang.String.class)) {
+					ignore("method public static void main(String[])", methodNode);
+					log = false;
				}
			}
+			if (log) {
+				System.out.println("\t" + methodNode.toStringLong());
			}
		}
		return super.visit(methodNode, data);
	}
private void ignore(String description, MemberNode memberNode) {
+		System.out.println("Ignoring " + description + ": " + memberNode.toStringLong());
	}