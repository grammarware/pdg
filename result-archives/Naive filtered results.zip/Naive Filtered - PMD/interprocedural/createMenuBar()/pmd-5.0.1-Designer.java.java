private JMenuBar createMenuBar() {
+		JMenuBar menuBar = new JMenuBar();
+		JMenu menu = new JMenu("Language");
+		ButtonGroup group = new ButtonGroup();

		LanguageVersion[] languageVersions = getSupportedLanguageVersions();
+		for (int i = 0; i < languageVersions.length; i++) {
+			LanguageVersion languageVersion = languageVersions[i];
+			JRadioButtonMenuItem button = new JRadioButtonMenuItem(languageVersion.getShortName());
+			languageVersionMenuItems[i] = button;
+			group.add(button);
+			menu.add(button);
		}
		languageVersionMenuItems[DEFAULT_LANGUAGE_VERSION_SELECTION_INDEX].setSelected(true);
+		menuBar.add(menu);

+		JMenu actionsMenu = new JMenu("Actions");
+		JMenuItem copyXMLItem = new JMenuItem("Copy xml to clipboard");
+		copyXMLItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				copyXmlToClipboard();
			}
		});
+		actionsMenu.add(copyXMLItem);
+		JMenuItem createRuleXMLItem = new JMenuItem("Create rule XML");
+		createRuleXMLItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				createRuleXML();
			}
		});
+		actionsMenu.add(createRuleXMLItem);
+		menuBar.add(actionsMenu);

		return menuBar;
	}