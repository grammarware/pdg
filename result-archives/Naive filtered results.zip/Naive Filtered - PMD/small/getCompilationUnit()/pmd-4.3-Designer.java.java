private int selectedSourceTypeIndex() {
+    	for (int i=0; i<sourceTypeMenuItems.length; i++) {
+    		if (sourceTypeMenuItems[i].isSelected()) return i;
    	}
+    	throw new RuntimeException("Initial default source type not specified");
    }