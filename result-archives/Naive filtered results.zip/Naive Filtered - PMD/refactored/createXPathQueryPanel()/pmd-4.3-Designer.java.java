private static void makeTextComponentUndoable(JTextComponent textConponent) {
+        final UndoManager undoManager = new UndoManager();
+        textConponent.getDocument().addUndoableEditListener(new UndoableEditListener() {
			     public void undoableEditHappened(
			       UndoableEditEvent evt) {
			         undoManager.addEdit(evt.getEdit());
			     }
  			 });
+        ActionMap actionMap = textConponent.getActionMap();
+        InputMap inputMap = textConponent.getInputMap();
+        actionMap.put("Undo", new AbstractAction("Undo") {
		         public void actionPerformed(ActionEvent evt) {
		             try {
		                 if (undoManager.canUndo()) {
		                     undoManager.undo();
		                 }
		             } catch (CannotUndoException e) {
		             }
		         }
        	 });
+        inputMap.put(KeyStroke.getKeyStroke("control Z"), "Undo");

+        actionMap.put("Redo", new AbstractAction("Redo") {
			    public void actionPerformed(ActionEvent evt) {
			        try {
			            if (undoManager.canRedo()) {
			                undoManager.redo();
			            }
			        } catch (CannotRedoException e) {
			        }
			    }
            });
+        inputMap.put(KeyStroke.getKeyStroke("control Y"), "Redo");
    }
private JPanel createXPathQueryPanel() {
+        JPanel p = new JPanel();
+        p.setLayout(new BorderLayout());
+        xpathQueryArea.setBorder(BorderFactory.createLineBorder(Color.black));
+        makeTextComponentUndoable(xpathQueryArea);
+        JScrollPane scrollPane = new JScrollPane(xpathQueryArea);
+        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
+        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
+        final JButton b = createGoButton();

+        p.add(new JLabel("XPath Query (if any):"), BorderLayout.NORTH);
+        p.add(scrollPane, BorderLayout.CENTER);
+        p.add(b, BorderLayout.SOUTH);

        return p;
    }
+private JButton createGoButton() {
+        JButton b = new JButton("Go");
+        b.setMnemonic('g');
+        b.addActionListener(new ShowListener());
+        b.addActionListener(codeEditorPane);
+        b.addActionListener(new XPathListener());
+        b.addActionListener(new DFAListener());
+        return b;
    }