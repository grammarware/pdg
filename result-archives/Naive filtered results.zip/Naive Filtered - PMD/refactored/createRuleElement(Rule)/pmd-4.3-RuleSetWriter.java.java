+private Element createCDATASectionElement(String name, String value) {
+		Element element = document.createElement(name);
+		CDATASection cdataSection = document.createCDATASection(value);
+		element.appendChild(cdataSection);
+		return element;
	}
private Element createRuleElement(Rule rule) {
+		if (rule instanceof RuleReference) {
+			RuleReference ruleReference = (RuleReference)rule;
+			RuleSetReference ruleSetReference = ruleReference.getRuleSetReference();
+			if (ruleSetReference.isAllRules()) {
+				if (!ruleSetFileNames.contains(ruleSetReference.getRuleSetFileName())) {
+					ruleSetFileNames.add(ruleSetReference.getRuleSetFileName());
+					Element ruleSetReferenceElement = createRuleSetReferenceElement(ruleSetReference);
+					return ruleSetReferenceElement;
				} else {
+					return null;
				}
			} else {
+				String name = ruleReference.getOverriddenName();
+				String ref = ruleReference.getRuleSetReference().getRuleSetFileName() + "/" + ruleReference.getName();
+				String message = ruleReference.getOverriddenMessage();
+				String externalInfoUrl = ruleReference.getOverriddenExternalInfoUrl();
+				String description = ruleReference.getOverriddenDescription();
+				Integer priority = ruleReference.getOverriddenPriority();
+				Properties properties = ruleReference.getOverriddenProperties();
+				List<String> examples = ruleReference.getOverriddenExamples();
+				return createSingleRuleElement(name, null, ref, message, externalInfoUrl, null, null, null,
+						description, priority, properties, examples);
			}
		} else {
+			return createSingleRuleElement(rule.getName(), rule.getSince(), null, rule.getMessage(),
					rule.getExternalInfoUrl(), rule.getRuleClass(), rule.usesDFA(), rule.usesTypeResolution(),
					rule.getDescription(), rule.getPriority(), rule.getProperties(), rule.getExamples());
		}
	}
+private Element createExampleElement(String example) {
+		return createCDATASectionElement("example", example);
	}
+private Element createPriorityElement(Integer priority) {
+		return createTextElement("priority", priority.toString());
	}
+private Element createTextElement(String name, String value) {
+		Element element = document.createElement(name);
+		Text text = document.createTextNode(value);
+		element.appendChild(text);
+		return element;
	}
+private Element createPropertyElement(Properties properties, String key, String value) {
+		Element propertyElement = document.createElement("property");
+		propertyElement.setAttribute("name", key);
+		if ("xpath".equals(key)) {
+			if (properties.containsKey("pluginname")) {
+				propertyElement.setAttribute("pluginname", properties.getProperty("pluginname"));
			}
+			Element valueElement = createCDATASectionElement("value", value);
+			propertyElement.appendChild(valueElement);
+		} else if ("pluginname".equals(key)) {
+			if (properties.containsKey("xpath")) {
+				return null;
			} else {
+				propertyElement.setAttribute("value", value);
			}
		} else {
+			propertyElement.setAttribute("value", value);
		}

+		return propertyElement;
	}
+private Element createPropertiesElement(Properties properties) {
+		if (properties != null && !properties.isEmpty()) {
+			Element propertiesElement = document.createElement("properties");
+			for (Map.Entry<Object, Object> entry : properties.entrySet()) {
+				Element propertyElement = createPropertyElement(properties, (String)entry.getKey(),
						(String)entry.getValue());
+				if (propertyElement != null) {
+					propertiesElement.appendChild(propertyElement);
				}
			}
+			return propertiesElement;
		} else {
+			return null;
		}
	}
+private Element createRuleSetReferenceElement(RuleSetReference ruleSetReference) {
+		Element ruleSetReferenceElement = document.createElement("rule");
+		ruleSetReferenceElement.setAttribute("ref", ruleSetReference.getRuleSetFileName());
+		for (String exclude : ruleSetReference.getExcludes()) {
+			Element excludeElement = createExcludeElement(exclude);
+			ruleSetReferenceElement.appendChild(excludeElement);
		}
+		return ruleSetReferenceElement;
	}
+private Element createDescriptionElement(String description) {
+		return createTextElement("description", description);
	}
private Element createSingleRuleElement(String name, String since, String ref, String message,
			String externalInfoUrl, String clazz, Boolean dfa, Boolean typeResolution, String description,
+			Integer priority, Properties properties, List<String> examples) {
+		Element ruleElement = document.createElement("rule");
+		if (name != null) {
+			ruleElement.setAttribute("name", name);
		}
+		if (since != null) {
+			ruleElement.setAttribute("since", since);
		}
+		if (ref != null) {
+			ruleElement.setAttribute("ref", ref);
		}
+		if (message != null) {
+			ruleElement.setAttribute("message", message);
		}
+		if (externalInfoUrl != null) {
+			ruleElement.setAttribute("externalInfoUrl", externalInfoUrl);
		}
+		if (clazz != null) {
+			ruleElement.setAttribute("class", clazz);
		}
+		if (dfa != null) {
+			ruleElement.setAttribute("dfa", dfa.toString());
		}
+		if (typeResolution != null) {
+			ruleElement.setAttribute("typeResolution", typeResolution.toString());
		}

+		if (description != null) {
+			Element descriptionElement = createDescriptionElement(description);
+			ruleElement.appendChild(descriptionElement);
		}
+		if (priority != null) {
+			Element priorityElement = createPriorityElement(priority);
+			ruleElement.appendChild(priorityElement);
		}
+		if (properties != null) {
+			Element propertiesElement = createPropertiesElement(properties);
+			if (propertiesElement != null) {
+				ruleElement.appendChild(propertiesElement);
			}
		}
+		if (examples != null) {
+			for (String example : examples) {
+				Element exampleElement = createExampleElement(example);
+				ruleElement.appendChild(exampleElement);
			}
		}
+		return ruleElement;
	}
+private Element createExcludeElement(String exclude) {
+		return createTextElement("exclude", exclude);
	}