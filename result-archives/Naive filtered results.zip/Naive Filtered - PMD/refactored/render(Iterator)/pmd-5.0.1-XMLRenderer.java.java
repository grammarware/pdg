+private Element addCodeSnippet(Document doc, Element duplication, Match match) {
+        String codeSnipet = match.getSourceCodeSlice();
+        if (codeSnipet != null) {
+        	Element codefragment = doc.createElement("codefragment");
+            codefragment.appendChild(doc.createCDATASection(codeSnipet));
+            duplication.appendChild(codefragment);
        }
+        return duplication;
    }
public String render(Iterator<Match> matches) {
+    	Document doc = createDocument();
+		Element root = doc.createElement("pmd-cpd");
+		doc.appendChild(root);

        Match match;
+        while (matches.hasNext()) {
+            match = matches.next();
+            root.appendChild( addCodeSnippet(doc, addFilesToDuplicationElement(doc, createDuplicationElement(doc, match), match), match ) );
        }
        return xmlDocToString(doc);
    }
+private Element createDuplicationElement(Document doc, Match match) {
+        Element duplication = doc.createElement("duplication");
+        duplication.setAttribute("lines", String.valueOf(match.getLineCount()));
+        duplication.setAttribute("tokens", String.valueOf(match.getTokenCount()));
+        return duplication;
    }
+private Element addFilesToDuplicationElement(Document doc, Element duplication, Match match) {
+    	TokenEntry mark;
+        for (Iterator<TokenEntry> iterator = match.iterator(); iterator.hasNext();) {
+            mark = iterator.next();
+            Element file = doc.createElement("file");
+            file.setAttribute("line", String.valueOf(mark.getBeginLine()));
+            file.setAttribute("path", mark.getTokenSrcID());
+            duplication.appendChild(file);
        }
+        return duplication;
    }
private String xmlDocToString(Document doc) {
        try {
	        TransformerFactory tf = TransformerFactory.newInstance();
+	        Transformer transformer = tf.newTransformer();
+	        transformer.setOutputProperty(OutputKeys.METHOD, "xml");
+	        transformer.setOutputProperty(OutputKeys.ENCODING, encoding);
+	        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
+	        transformer.setOutputProperty(OutputKeys.CDATA_SECTION_ELEMENTS, "codefragment");
	        StringWriter writer = new StringWriter();
+	        transformer.transform(new DOMSource(doc), new StreamResult(writer));
	        return writer.getBuffer().toString();
        }  catch (TransformerException e) {
        	throw new IllegalStateException(e);
		}
	}