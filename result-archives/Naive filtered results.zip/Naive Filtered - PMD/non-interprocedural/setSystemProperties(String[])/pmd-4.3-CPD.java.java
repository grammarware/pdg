private static void setSystemProperties(String[] args) {
        boolean ignoreLiterals = findBooleanSwitch(args, "--ignore-literals"),
        ignoreIdentifiers = findBooleanSwitch(args, "--ignore-identifiers");
+        Properties properties = System.getProperties();
+        if (ignoreLiterals) {
+            properties.setProperty(JavaTokenizer.IGNORE_LITERALS, "true");
        }
+        if (ignoreIdentifiers) {
+            properties.setProperty(JavaTokenizer.IGNORE_IDENTIFIERS, "true");
        }
        System.setProperties(properties);
    }