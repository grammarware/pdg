/**
	 * Returns a new fresh folder with a random name under the temporary
	 * folder.
	 */
	public File newFolder() throws IOException {
		File createdFolder= File.createTempFile("junit", "", folder);
+		createdFolder.delete();
+		createdFolder.mkdir();
		return createdFolder;
	}
// testing purposes only
	/**
	 * for testing purposes only.  Do not use.
	 */
	public void create() throws IOException {
+		folder= newFolder();
	}