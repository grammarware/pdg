@Test public void verifierRunsAfterTest() {
+		assertThat(testResult(UsesVerifier.class), isSuccessful());
	}