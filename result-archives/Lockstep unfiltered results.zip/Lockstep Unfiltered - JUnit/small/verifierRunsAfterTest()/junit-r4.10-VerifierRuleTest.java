@Test public void verifierRunsAfterTest() {
		sequence = "";
+		assertThat(testResult(UsesVerifier.class), isSuccessful());
		assertEquals("test verify ", sequence);
	}