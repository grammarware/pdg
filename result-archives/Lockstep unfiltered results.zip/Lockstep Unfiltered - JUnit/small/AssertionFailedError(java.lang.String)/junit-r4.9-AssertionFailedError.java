public AssertionFailedError(String message) {
+		super(message);
	}