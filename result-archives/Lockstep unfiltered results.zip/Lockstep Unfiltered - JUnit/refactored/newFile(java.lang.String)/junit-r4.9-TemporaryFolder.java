/**
	 * Returns a new fresh file with the given name under the temporary folder.
	 */
	public File newFile(String fileName) throws IOException {
+		File file= new File(folder, fileName);
+		file.createNewFile();
+		return file;
	}