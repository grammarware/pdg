/**
     * Get the metadata that is part of the document catalog.  This will
     * return null if there is no meta data for this object.
     *
     * @return The metadata for this object.
     */
    public PDMetadata getMetadata()
    {
+        PDMetadata retval = null;
+        COSStream mdStream = (COSStream)xobject.getStream().getDictionaryObject( "Metadata" );
+        if( mdStream != null )
        {
+            retval = new PDMetadata( mdStream );
        }
+        return retval;
    }