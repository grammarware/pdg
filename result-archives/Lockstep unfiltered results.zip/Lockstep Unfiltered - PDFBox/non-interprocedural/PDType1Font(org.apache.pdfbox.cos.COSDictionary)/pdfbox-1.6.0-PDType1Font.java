/**
     * Constructor.
     *
     * @param fontDictionary The font dictionary according to the PDF specification.
     */
    public PDType1Font( COSDictionary fontDictionary )
    {
+        super( fontDictionary );
+        PDFontDescriptor fd = getFontDescriptor();
+        if (fd != null && fd instanceof PDFontDescriptorDictionary)
        {
+            // a Type1 font may contain a Type1C font
+            PDStream fontFile3 = ((PDFontDescriptorDictionary)fd).getFontFile3();
+            if (fontFile3 != null)
            {
+                try 
                {
+                    type1CFont = new PDType1CFont( super.font );
                }
                catch (IOException exception) 
                {
                    log.info("Can't read the embedded type1C font " + fd.getFontName() );
                }
            }
        }
    }