/**
     * scn Set color space for non stroking operations.
     * @param operator The operator that is being executed.
     * @param arguments List
     * @throws IOException If an error occurs while processing the font.
     */
    public void process(PDFOperator operator, List<COSBase> arguments) throws IOException
    {
+        PDColorState colorInstance = context.getGraphicsState().getNonStrokingColor();
+        PDColorSpace colorSpace = colorInstance.getColorSpace();
        
+        if (colorSpace != null) 
        {
            List<COSBase> argList = arguments;
            OperatorProcessor newOperator = null;

+            if (colorSpace instanceof PDSeparation) {
+                PDSeparation sep = (PDSeparation) colorSpace;
+                colorSpace = sep.getAlternateColorSpace();
                argList = sep.calculateColorValues(arguments.get(0)).toList();
            }

+            if (colorSpace instanceof PDDeviceGray)
            {
+                newOperator = new SetNonStrokingGrayColor();
            }
+            else if (colorSpace instanceof PDDeviceRGB)
            {
+                newOperator = new SetNonStrokingRGBColor();
            }
+            else if (colorSpace instanceof PDDeviceCMYK)
            {
+                newOperator = new SetNonStrokingCMYKColor();
            }
+            else if (colorSpace instanceof PDICCBased)
            {
+                newOperator = new SetNonStrokingICCBasedColor();
            }
+            else if (colorSpace instanceof PDCalRGB)
            {
+                newOperator = new SetNonStrokingCalRGBColor();
            }
    
            if (newOperator != null) 
            {
                colorInstance.setColorSpace(colorSpace);
                newOperator.setContext(getContext());
                newOperator.process(operator, argList);
            }
            else
            {
                log.warn("Not supported colorspace "+colorSpace.getName() 
                        + " within operator "+operator.getOperation());
            }
        }
        
    }