/**
     * scn Set color space for non stroking operations.
     * @param operator The operator that is being executed.
     * @param arguments List
     * @throws IOException If an error occurs while processing the font.
     */
    public void process(PDFOperator operator, List<COSBase> arguments) throws IOException
    {
+        PDColorState color = context.getGraphicsState().getStrokingColor();
+        PDColorSpace colorSpace = color.getColorSpace();

+        if (colorSpace != null) 
        {
            OperatorProcessor newOperator = null;
            List<COSBase> argList = arguments;

+            if (colorSpace instanceof PDSeparation) 
            {
+                PDSeparation sep = (PDSeparation) colorSpace;
+                colorSpace = sep.getAlternateColorSpace();
                argList = sep.calculateColorValues(arguments.get(0)).toList();
            }

+            if (colorSpace instanceof PDDeviceGray)
            {
+                newOperator = new SetStrokingGrayColor();
            }
+            else if (colorSpace instanceof PDDeviceRGB)
            {
+                newOperator = new SetStrokingRGBColor();
            }
+            else if (colorSpace instanceof PDDeviceCMYK)
            {
+                newOperator = new SetStrokingCMYKColor();
            }
+            else if (colorSpace instanceof PDICCBased)
            {
+                newOperator = new SetStrokingICCBasedColor();
            }
+            else if (colorSpace instanceof PDCalRGB)
            {
+                newOperator = new SetStrokingCalRGBColor();
            }

            if (newOperator != null) 
            {
                color.setColorSpace(colorSpace);
                newOperator.setContext(getContext());
                newOperator.process(operator, argList);
            }
            else
            {
                log.warn("Not supported colorspace "+colorSpace.getName() 
                        + " within operator "+operator.getOperation());
            }
        }
    }