+private int getQ()
    {
+        int q = parent.getQ();
+        if( parent.getDictionary().getDictionaryObject( COSName.Q ) == null )
        {
+            COSArray kids = (COSArray)parent.getDictionary().getDictionaryObject( COSName.KIDS );
+            if( kids != null && kids.size() > 0 )
            {
+                COSDictionary firstKid = (COSDictionary)kids.getObject( 0 );
+                COSNumber qNum = (COSNumber)firstKid.getDictionaryObject( COSName.Q );
+                if( qNum != null )
                {
+                    q = qNum.intValue();
                }
            }
        }
+        return q;
    }