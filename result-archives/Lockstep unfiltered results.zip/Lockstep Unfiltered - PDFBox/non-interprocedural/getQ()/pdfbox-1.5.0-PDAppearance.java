+private int getQ()
    {
+        int q = parent.getQ();
+        if( parent.getDictionary().getDictionaryObject( "Q" ) == null )
        {
+            COSArray kids = (COSArray)parent.getDictionary().getDictionaryObject( "Kids" );
+            if( kids != null && kids.size() > 0 )
            {
+                COSDictionary firstKid = (COSDictionary)kids.getObject( 0 );
+                COSNumber qNum = (COSNumber)firstKid.getDictionaryObject( "Q" );
+                if( qNum != null )
                {
+                    q = qNum.intValue();
                }
            }
        }
+        return q;
    }