/**
     * Create the correct xobject from the cos base.
     *
     * @param xobject The cos level xobject to create.
     *
     * @return a pdmodel xobject
     * @throws IOException If there is an error creating the xobject.
     */
+    public static PDXObject createXObject( COSBase xobject ) throws IOException
    {
+        PDXObject retval = null;
+        if( xobject == null )
        {
+            retval = null;
        }
+        else if( xobject instanceof COSStream )
        {
+            COSStream xstream = (COSStream)xobject;
+            String subtype = xstream.getNameAsString( "Subtype" );
+            if( subtype.equals( PDXObjectImage.SUB_TYPE ) )
            {
+                PDStream image = new PDStream( xstream );
+                // See if filters are DCT or JPX otherwise treat as Bitmap-like
                // There might be a problem with several filters, but that's ToDo until
                // I find an example
+                List filters = image.getFilters();
+                if( filters != null && filters.contains( COSName.DCT_DECODE.getName() ) )
                {
+                    return new PDJpeg(image);
                }
+                else if ( filters != null && filters.contains( COSName.CCITTFAX_DECODE.getName() ) )
                {
+                    return new PDCcitt(image);
                }
+                else if( filters != null && filters.contains(COSName.JPX_DECODE.getName()))
                {
                    //throw new IOException( "JPXDecode has not been implemented for images" );
                    //JPX Decode is not really supported right now, but if we are just doing
                    //text extraction then we don't want to throw an exception, so for now
                    //just return a PDPixelMap, which will break later on if it is
                    //actually used, but for text extraction it is not used.
            
+                    return new PDPixelMap( image );

                }
                /*else if( filters != null && filters.contains(COSName.FLATE_DECODE.getName()))
                {
            retval = new PDPixelMap(image);
        }*/
                else
                {
+                    retval = new PDPixelMap(image);
            //throw new IOException ("Default branch: filters = " + filters.toString());
                }
            }
+            else if( subtype.equals( PDXObjectForm.SUB_TYPE ) )
            {
+                retval = new PDXObjectForm( xstream );
            }
            else
            {
                throw new IOException( "Unknown xobject subtype '" + subtype + "'" );
            }
        }
        else
        {
            throw new IOException( "Unknown xobject type:" + xobject.getClass().getName() );
        }

+        return retval;
    }