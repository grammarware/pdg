/**
     * Returns an image of the CCITT Fax, or null if TIFFs are not supported. (Requires additional JAI Image filters )
     *
     * {@inheritDoc}
     */
    public BufferedImage getRGBImage() throws IOException
    {
        BufferedImage retval = null;

+        InputStream tiff = new TiffWrapper(
+                getPDStream().getPartiallyFilteredStream( FAX_FILTERS ),
                getCOSStream());
        try
        {
+            retval = ImageIO.read(tiff);
        }
        catch (Exception e)
        {
            log.error(e, e);
        }
        finally
        {
            if (tiff != null)
            {
                tiff.close();
            }
        }
+        return retval;
    }