/**
     * This will set a flag telling if we are on a newline.
     *
     * @param newOnNewLine The new value for the onNewLine attribute.
     */
+    public void setOnNewLine(boolean newOnNewLine)
    {
+        onNewLine = newOnNewLine;
    }
/**
     * This will write a single byte to the stream.
     *
     * @param b The byte to write to the stream.
     *
     * @throws IOException If there is an error writing to the underlying stream.
     */
    @Override
    public void write(int b) throws IOException
    {
        checkPos();
+        setOnNewLine(false);
+        out.write(b);
+        pos++;
    }