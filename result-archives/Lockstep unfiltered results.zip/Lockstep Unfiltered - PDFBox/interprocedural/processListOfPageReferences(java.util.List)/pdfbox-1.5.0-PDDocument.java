/**
     * This will get the document CATALOG.  This is guaranteed to not return null.
     *
     * @return The documents /Root dictionary
     */
    public PDDocumentCatalog getDocumentCatalog()
    {
        if( documentCatalog == null )
        {
+            COSDictionary trailer = document.getTrailer();
+            COSBase dictionary = trailer.getDictionaryObject( COSName.ROOT );
            if (dictionary instanceof COSDictionary) {
+                documentCatalog =
                    new PDDocumentCatalog(this, (COSDictionary) dictionary);
            } else {
                documentCatalog = new PDDocumentCatalog(this);
            }

        }
        return documentCatalog;
    }
+/**
     * This will return the Map containing the mapping from object-ids to pagenumbers.
     * 
     * @return the pageMap
     */
    public final Map getPageMap() 
    {
        if (pageMap == null)
        {
            generatePageMap();
        }
+        return pageMap;
    }
/**
     * This will either add the page passed in, or, if it's a pointer to an array
     * of pages, it'll recursivly call itself and process everything in the list.
     */
    private void parseCatalogObject(COSObject thePageOrArrayObject) 
    {
+        COSBase arrayCountBase = thePageOrArrayObject.getItem(COSName.COUNT);
        int arrayCount = -1;
        if(arrayCountBase instanceof COSInteger)
        {
+            arrayCount = ((COSInteger)arrayCountBase).intValue();
        }
 
+        COSBase kidsBase = thePageOrArrayObject.getItem(COSName.KIDS);
        int kidsCount = -1;
        if(kidsBase instanceof COSArray)
        {
+            kidsCount = ((COSArray)kidsBase).size();
        }
     
        if(arrayCount == -1 || kidsCount == -1) 
        {
            // these cases occur when we have a page, not an array of pages
            String objStr = String.valueOf(thePageOrArrayObject.getObjectNumber().intValue());
            String genStr = String.valueOf(thePageOrArrayObject.getGenerationNumber().intValue());
            getPageMap().put(objStr+","+genStr, new Integer(getPageMap().size()+1));
        } 
        else 
        {
            // we either have an array of page pointers, or an array of arrays
            if(arrayCount == kidsCount) 
            {
                // process the kids... they're all references to pages
                COSArray kidsArray = ((COSArray)kidsBase);
                for(int i=0; i<kidsArray.size(); ++i) 
                {
+                    COSObject thisObject = (COSObject)kidsArray.get(i);
                    String objStr = String.valueOf(thisObject.getObjectNumber().intValue());
                    String genStr = String.valueOf(thisObject.getGenerationNumber().intValue());
+                    getPageMap().put(objStr+","+genStr, new Integer(getPageMap().size()+1));
                }
            } 
            else 
            {
                // this object is an array of references to other arrays
                COSArray list = null;
                if(kidsBase instanceof COSArray)
                {
+                    list = ((COSArray)kidsBase);
                }
                if(list != null) 
                {
                    for(int arrayCounter=0; arrayCounter < list.size(); ++arrayCounter) 
                    {
                        parseCatalogObject((COSObject)list.get(arrayCounter));
                    }
                }
            }
        }
    }