/**
     * This will set the current object number.
     *
     * @param newNumber The new object number.
     */
+    protected void setNumber(long newNumber)
    {
+        number = newNumber;
    }
/**
     * This will write a COS object.
     *
     * @param obj The object to write.
     *
     * @throws COSVisitorException If there is an error visiting objects.
     */
+    public void doWriteObject( COSBase obj ) throws COSVisitorException
    {
+        try
        {
+            writtenObjects.add( obj );
+            if(obj instanceof COSDictionary) 
            {
                COSDictionary dict = (COSDictionary)obj;
                COSName item = (COSName)dict.getItem(COSName.TYPE);
                if(COSName.SIG.equals(item)) {
                    reachedSignature = true;
                }
            }
            
+            // find the physical reference
+            currentObjectKey = getObjectKey( obj );
            // add a x ref entry
            addXRefEntry( new COSWriterXRefEntry(getStandardOutput().getPos(), obj, currentObjectKey));
            // write the object
            getStandardOutput().write(String.valueOf(currentObjectKey.getNumber()).getBytes("ISO-8859-1"));
            getStandardOutput().write(SPACE);
            getStandardOutput().write(String.valueOf(currentObjectKey.getGeneration()).getBytes("ISO-8859-1"));
            getStandardOutput().write(SPACE);
            getStandardOutput().write(OBJ);
            getStandardOutput().writeEOL();
+            obj.accept( this );
            getStandardOutput().writeEOL();
            getStandardOutput().write(ENDOBJ);
            getStandardOutput().writeEOL();
        }
+        catch (IOException e)
        {
+            throw new COSVisitorException(e);
        }
    }
+/**
     * This will get the object key for the object.
     *
     * @param obj The object to get the key for.
     *
     * @return The object key for the object.
     */
+    private COSObjectKey getObjectKey( COSBase obj )
    {
+        COSBase actual = obj;
+        if( actual instanceof COSObject )
        {
+            actual = ((COSObject)obj).getObject();
        }
+        COSObjectKey key = null;
+        if( actual != null )
        {
+            key = objectKeys.get(actual);
        }
+        if( key == null )
        {
+            key = objectKeys.get(obj);
        }
+        if (key == null)
        {
+            setNumber(getNumber()+1);
+            key = new COSObjectKey(getNumber(),0);
+            objectKeys.put(obj, key);
+            if( actual != null )
            {
+                objectKeys.put(actual, key);
            }
        }
+        return key;
    }
+/**
     * This will get the current object number.
     *
     * @return The current object number.
     */
    protected long getNumber()
    {
+        return number;
    }