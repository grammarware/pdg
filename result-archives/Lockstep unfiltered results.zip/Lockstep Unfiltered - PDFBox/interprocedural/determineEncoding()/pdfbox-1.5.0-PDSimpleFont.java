/**
     * {@inheritDoc}
     */
    protected void determineEncoding()
    {
+        String cmapName = null;
+        COSName encodingName = null;
+        COSBase encoding = getEncoding(); 
+        Encoding fontEncoding = null;
+        if (encoding != null) 
        {
+            if (encoding instanceof COSName) 
            {
+                if (cmap == null)
                {
+                    encodingName = (COSName)encoding;
+                    cmap = cmapObjects.get( encodingName.getName() );
+                    if (cmap == null) 
                    {
+                        cmapName = encodingName.getName();
                    }
                }
+                if (cmap == null && cmapName != null)
                {
+                    try 
                    {
+                        fontEncoding =
+                            EncodingManager.INSTANCE.getEncoding(encodingName);
                    }
+                    catch(IOException exception) 
                    {
+                        log.debug("Debug: Could not find encoding for " + encodingName );
                    }
                }
            }
+            else if (encoding instanceof COSDictionary) 
            {
+                try 
                {
+                    fontEncoding = new DictionaryEncoding((COSDictionary)encoding);
                }
+                catch(IOException exception) 
                {
+                    log.error("Error: Could not create the DictionaryEncoding" );
                }
            }
+            else if(encoding instanceof COSStream )
            {
+                if (cmap == null)
                {
+                    COSStream encodingStream = (COSStream)encoding;
+                    try 
                    {
+                        parseCmap( null, encodingStream.getUnfilteredStream(), null );
                    }
+                    catch(IOException exception) 
                    {
+                        log.error("Error: Could not parse the embedded CMAP" );
                    }
                }
            }
        }
+        setFontEncoding(fontEncoding);
+        extractToUnicodeEncoding();

+        if (cmap == null && cmapName != null) 
        {
+            String resourceName = resourceRootCMAP + cmapName;
+            try {
+                parseCmap( resourceRootCMAP, ResourceLoader.loadResource( resourceName ), encodingName );
+                if( cmap == null && encodingName == null)
                {
+                    log.error("Error: Could not parse predefined CMAP file for '" + cmapName + "'" );
                }
            }
            catch(IOException exception) 
            {
+                log.error("Error: Could not find predefined CMAP file for '" + cmapName + "'" );
            }
        }
    }
+/**
     * This will get the ToUnicode object.
     *
     * @return The ToUnicode object.
     */
    public COSBase getToUnicode()
    {
+        return font.getDictionaryObject( COSName.TO_UNICODE );
    }
private void extractToUnicodeEncoding()
    {
+        COSName encodingName = null;
+        String cmapName = null;
+        COSBase toUnicode = getToUnicode();
+        if( toUnicode != null )
        {
+            setHasToUnicode(true);
+            if ( toUnicode instanceof COSStream )
            {
+                try {
+                    parseCmap(null, ((COSStream)toUnicode).getUnfilteredStream(), null);
                }
+                catch(IOException exception) 
                {
+                    log.error("Error: Could not load embedded CMAP" );
                }
            }
+            else if ( toUnicode instanceof COSName)
            {
+                encodingName = (COSName)toUnicode;
+                cmap = cmapObjects.get( encodingName.getName() );
+                if (cmap == null) 
                {
+                    cmapName = encodingName.getName();
+                    String resourceName = resourceRootCMAP + cmapName;
+                    try {
+                        parseCmap( resourceRootCMAP, ResourceLoader.loadResource( resourceName ), encodingName );
                    }
+                    catch(IOException exception) 
                    {
+                        log.error("Error: Could not find predefined CMAP file for '" + cmapName + "'" );
                    }
+                    if( cmap == null)
                    {
+                        log.error("Error: Could not parse predefined CMAP file for '" + cmapName + "'" );
                    }
                }
            }
        }
    }