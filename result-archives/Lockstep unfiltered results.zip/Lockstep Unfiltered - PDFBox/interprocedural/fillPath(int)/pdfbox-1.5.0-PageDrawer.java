/**
     * Get the current line path to be drawn.
     *
     * @return The current line path to be drawn.
     */
    public GeneralPath getLinePath()
    {
+        return linePath;
    }
/**
     * Fill the path.
     *
     * @param windingRule The winding rule this path will use.
     * 
     * @throws IOException If there is an IO error while filling the path.
     */
    public void fillPath(int windingRule) throws IOException
    {
+        graphics.setColor( getGraphicsState().getNonStrokingColor().getJavaColor() );
+        getLinePath().setWindingRule(windingRule);
+        graphics.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF );
+        graphics.setClip(getGraphicsState().getCurrentClippingPath());
+        graphics.fill( getLinePath() );
+        getLinePath().reset();
    }