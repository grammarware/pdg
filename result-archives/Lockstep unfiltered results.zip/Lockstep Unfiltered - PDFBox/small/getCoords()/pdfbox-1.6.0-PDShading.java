/**
    * Returns the coordinate array used by several of the gradient types. Interpretation depends on the ShadingType.
    *
    * @return The coordinate array.
    */
    public COSArray getCoords()
    {
+        return (COSArray)(DictShading.getDictionaryObject(COSName.COORDS));
    }