/**
     * Set the metadata for this object.  This can be null.
     *
     * @param meta The meta data for this object.
     */
    public void setMetadata( PDMetadata meta )
    {
+        xobject.getStream().setItem( COSName.METADATA, meta );
    }