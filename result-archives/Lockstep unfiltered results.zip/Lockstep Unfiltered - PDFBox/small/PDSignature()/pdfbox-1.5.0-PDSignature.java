/**
     * Default constructor.
     */
    public PDSignature()
    {
+        sig = new COSDictionary();
    }