/**
   * Default constructor.
   */
  public PDSignature()
  {
+    dictionary = new COSDictionary();
    dictionary.setItem(COSName.TYPE, COSName.SIG);
  }