/**
    * This will return the ShadingType -- an integer between 1 and 7 that specifies the gradient type.
    * Required in all Shading Dictionaries.
    *
    * @return The Shading Type
    */
    public int getShadingType()
    {
+        return DictShading.getInt(COSName.SHADING_TYPE);
    }