/**
    * This will return a boolean flag indicating whether to antialias the shading pattern.
    *
    * @return The antialias flag, defaulting to False
    */
    public boolean getAntiAlias()
    {
+        return DictShading.getBoolean(COSName.ANTI_ALIAS,false);
    }