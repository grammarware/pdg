/**
    * Returns the Domain array used by several of the gradient types. Interpretation depends on the ShadingType.
    *
    * @return The Domain array.
    */
    public COSArray getDomain()
    {
        if (domain == null) 
        {
            domain = (COSArray)(DictShading.getDictionaryObject(COSName.DOMAIN));
            // use default values
            if (domain == null) 
            {
                domain = new COSArray();
                domain.add(new COSFloat(0.0f));
                domain.add(new COSFloat(1.0f));
            }
        }
+        return domain;
    }