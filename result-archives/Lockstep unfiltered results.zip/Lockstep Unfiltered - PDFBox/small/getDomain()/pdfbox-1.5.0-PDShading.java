/**
    * Returns the Domain array used by several of the gradient types. Interpretation depends on the ShadingType.
    *
    * @return The Domain array.
    */
    public COSArray getDomain()
    {
+        return (COSArray)(DictShading.getDictionaryObject("Domain"));
    }