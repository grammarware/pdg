/**
    * This will return the Color Space.
    * Required in all Shading Dictionaries.
    *
    * @return The Color Space of the shading dictionary
    */
    public PDColorSpace getColorSpace() throws IOException
    {
+        return PDColorSpaceFactory.createColorSpace(DictShading.getDictionaryObject("ColorSpace"));
    }