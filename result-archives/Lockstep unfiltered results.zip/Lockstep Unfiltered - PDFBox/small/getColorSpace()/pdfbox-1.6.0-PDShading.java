/**
    * This will return the Color Space.
    * Required in all Shading Dictionaries.
    *
    * @return The Color Space of the shading dictionary
    */
    public PDColorSpace getColorSpace() throws IOException
    {
        if (colorspace == null)
        {
            colorspace = PDColorSpaceFactory.createColorSpace(DictShading.getDictionaryObject(COSName.COLORSPACE));
        }
+        return colorspace;
    }