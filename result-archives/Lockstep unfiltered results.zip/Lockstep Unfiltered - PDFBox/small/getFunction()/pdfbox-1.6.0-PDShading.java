/**
    * Returns the function used by several of the gradient types. Interpretation depends on the ShadingType.
    *
    * @return The gradient function.
    */
    public PDFunction getFunction() throws IOException
    {
        if (function == null)
        {
            function = PDFunction.create(DictShading.getDictionaryObject(COSName.FUNCTION));
        }
+        return function;
    }