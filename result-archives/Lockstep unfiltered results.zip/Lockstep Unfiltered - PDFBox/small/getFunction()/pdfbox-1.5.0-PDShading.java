/**
    * Returns the function used by several of the gradient types. Interpretation depends on the ShadingType.
    *
    * @return The gradient function.
    */
    public PDFunction getFunction() throws IOException
    {
+        return PDFunction.create(DictShading.getDictionaryObject("Function"));
    }