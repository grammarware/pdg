/**
     * {@inheritDoc}
     */
    public void write(int b) throws IOException
    {
+        write(new byte[] {(byte) b}, 0, 1);
    }
/**
     * {@inheritDoc}
     */
+    public void write(byte[] b, int offset, int length) throws IOException
    {
+        if (pointer+length >= buffer.length)
        {
+            // expand buffer
            byte[] temp = new byte[buffer.length+length+EXTRA_SPACE];
            Arrays.fill(temp, (byte)0);
+            System.arraycopy(buffer, 0, temp, 0, (int) this.size);
+            buffer = temp;
        }
+        System.arraycopy(b, offset, buffer, (int)pointer, length);
        pointer += length;
+        if (pointer > this.size)
        {
+            this.size = pointer;
        }
    }