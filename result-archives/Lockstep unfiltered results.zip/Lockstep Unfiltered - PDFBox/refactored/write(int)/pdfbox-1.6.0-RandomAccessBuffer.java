/**
     * {@inheritDoc}
     */
    public void write(int b) throws IOException
    {
+        if (pointer >= buffer.length)
        {
+            if (pointer >= Integer.MAX_VALUE) 
            {
                throw new IOException("RandomAccessBuffer overflow");
            }
+            buffer = expandBuffer(buffer, (int)Math.min(2L * buffer.length, Integer.MAX_VALUE));
        }
        buffer[(int)pointer++] = (byte)b;
+        if (pointer > this.size)
        {
+            this.size = pointer;
        }
    }
+/**
     * expand the given buffer to the new size.
     * 
     * @param buffer the given buffer
     * @param newSize the new size
     * @return the expanded buffer
     * 
     */
+    private byte[] expandBuffer(byte[] buffer, int newSize) 
    {
+        byte[] expandedBuffer = new byte[newSize];
+        System.arraycopy(buffer, 0, expandedBuffer, 0, buffer.length);
+        return expandedBuffer;
    }