/**
     * write the x ref section for the pdf file
     *
     * currently, the pdf is reconstructed from the scratch, so we write a single section
     *
     * todo support for incremental writing?
     *
     * @param doc The document to write the xref from.
     *
     * @throws IOException If there is an error writing the data to the stream.
     */
    protected void doWriteXRef(COSDocument doc) throws IOException
    {
+        String offset;
+        String generation;

        // sort xref, needed only if object keys not regenerated
+        Collections.sort(getXRefEntries());
+        COSWriterXRefEntry lastEntry = (COSWriterXRefEntry)getXRefEntries().get( getXRefEntries().size()-1 );

        // remember the position where x ref is written
+        setStartxref(getStandardOutput().getPos());
        //
+        getStandardOutput().write(XREF);
+        getStandardOutput().writeEOL();
        // write start object number and object count for this x ref section
        // we assume starting from scratch
+        getStandardOutput().write(String.valueOf(0).getBytes("ISO-8859-1"));
+        getStandardOutput().write(SPACE);
+        getStandardOutput().write(String.valueOf(lastEntry.getKey().getNumber() + 1).getBytes("ISO-8859-1"));
+        getStandardOutput().writeEOL();
        // write initial start object with ref to first deleted object and magic generation number
        offset = formatXrefOffset.format(0);
        generation = formatXrefGeneration.format(65535);
+        getStandardOutput().write(offset.getBytes("ISO-8859-1"));
+        getStandardOutput().write(SPACE);
+        getStandardOutput().write(generation.getBytes("ISO-8859-1"));
+        getStandardOutput().write(SPACE);
+        getStandardOutput().write(XREF_FREE);
+        getStandardOutput().writeCRLF();
+        // write entry for every object
        long lastObjectNumber = 0;
+        for (Iterator i = getXRefEntries().iterator(); i.hasNext();)
        {
+            COSWriterXRefEntry entry = (COSWriterXRefEntry) i.next();
+            while( lastObjectNumber<entry.getKey().getNumber()-1 )
            {
                offset = formatXrefOffset.format(0);
                generation = formatXrefGeneration.format(65535);
+                getStandardOutput().write(offset.getBytes("ISO-8859-1"));
+                getStandardOutput().write(SPACE);
+                getStandardOutput().write(generation.getBytes("ISO-8859-1"));
+                getStandardOutput().write(SPACE);
+                getStandardOutput().write(XREF_FREE);
+                getStandardOutput().writeCRLF();
                lastObjectNumber++;
            }
+            lastObjectNumber = entry.getKey().getNumber();
            offset = formatXrefOffset.format(entry.getOffset());
            generation = formatXrefGeneration.format(entry.getKey().getGeneration());
+            getStandardOutput().write(offset.getBytes("ISO-8859-1"));
+            getStandardOutput().write(SPACE);
+            getStandardOutput().write(generation.getBytes("ISO-8859-1"));
+            getStandardOutput().write(SPACE);
+            getStandardOutput().write(entry.isFree() ? XREF_FREE : XREF_USED);
+            getStandardOutput().writeCRLF();
        }
    }
/**
     * This will get the standard output stream.
     *
     * @return The standard output stream.
     */
    protected COSStandardOutputStream getStandardOutput()
    {
+        return standardOutput;
    }
/**
     * This will set the start xref.
     *
     * @param newStartxref The new start xref attribute.
     */
+    protected void setStartxref(long newStartxref)
    {
+        startxref = newStartxref;
    }
/**
     * This will get the xref entries.
     *
     * @return All available xref entries.
     */
    protected java.util.List getXRefEntries()
    {
+        return xRefEntries;
    }