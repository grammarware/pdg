/**
     * expand the given buffer to the new size.
     * 
     * @param buffer the given buffer
     * @param newSize the new size
     * @return the expanded buffer
     * 
     */
    private byte[] expandBuffer(byte[] buffer, int newSize) 
    {
+        byte[] expandedBuffer = new byte[newSize];
+        System.arraycopy(buffer, 0, expandedBuffer, 0, buffer.length);
        return expandedBuffer;
    }
/**
     * {@inheritDoc}
     */
+    public void write(byte[] b, int offset, int length) throws IOException
    {
        long newSize = pointer+length;
+        if (newSize >= buffer.length)
        {
+            if (newSize > Integer.MAX_VALUE) 
            {
                throw new IOException("RandomAccessBuffer overflow");
            }
+            newSize = Math.min(Math.max(2L * buffer.length, newSize), Integer.MAX_VALUE);
+            buffer = expandBuffer(buffer, (int)newSize);
        }
+        System.arraycopy(b, offset, buffer, (int)pointer, length);
+        pointer += length;
+        if (pointer > this.size)
        {
+            this.size = pointer;
        }
    }