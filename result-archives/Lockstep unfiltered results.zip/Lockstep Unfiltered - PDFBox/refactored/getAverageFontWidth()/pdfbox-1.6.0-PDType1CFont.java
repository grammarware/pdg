/**
     * {@inheritDoc}
     */
    public float getAverageFontWidth() throws IOException
    {
+        if( this.avgWidth == null )
        {
+            this.avgWidth = Float.valueOf(getFontMetric().getAverageCharacterWidth());
        }

+        return this.avgWidth.floatValue();
    }
private FontMetric getFontMetric() 
    {
+        if (fontMetric == null)
        {
            try
            {
+                fontMetric = prepareFontMetric(cffFont);
            }
            catch (IOException exception)
            {
                log.error("An error occured while extracting the font metrics!", exception);
            }
        }
        return fontMetric;
    }