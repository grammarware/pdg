+/**
     * w in an appearance stream represents the lineWidth.
     * @return the linewidth
     */
    private float getLineWidth( List tokens )
    {

+        float retval = 1;
+        if( tokens != null )
        {
+            int btIndex = tokens.indexOf(PDFOperator.getOperator( "BT" ));
+            int wIndex = tokens.indexOf(PDFOperator.getOperator( "w" ));
+            //the w should only be used if it is before the first BT.
            if( (wIndex > 0) && (wIndex < btIndex) )
            {
+                retval = ((COSNumber)tokens.get(wIndex-1)).floatValue();
            }
        }
+        return retval;
    }
/**
     * My "not so great" method for calculating the fontsize.
     * It does not work superb, but it handles ok.
     * @return the calculated font-size
     *
     * @throws IOException If there is an error getting the font height.
     */
+    private float calculateFontSize( PDFont pdFont, PDRectangle boundingBox, List tokens, List daTokens )
        throws IOException
    {
+        float fontSize = 0;
+        if( daTokens != null )
        {
            //daString looks like   "BMC /Helv 3.4 Tf EMC"

+            int fontIndex = daTokens.indexOf( PDFOperator.getOperator( "Tf" ) );
+            if(fontIndex != -1 )
            {
+                fontSize = ((COSNumber)daTokens.get(fontIndex-1)).floatValue();
            }
        }
+        if( parent.doNotScroll() )
        {
+            //if we don't scroll then we will shrink the font to fit into the text area.
+            float widthAtFontSize1 = pdFont.getStringWidth( value );
+            float availableWidth = boundingBox.getWidth();
+            float perfectFitFontSize = availableWidth / widthAtFontSize1;
        }
+        else if( fontSize == 0 )
        {
+            float lineWidth = getLineWidth( tokens );
+            float stringWidth = pdFont.getStringWidth( value );
+            float height = 0;
+            if( pdFont instanceof PDSimpleFont )
            {
+                height = ((PDSimpleFont)pdFont).getFontDescriptor().getFontBoundingBox().getHeight();
            }
            else
            {
+                //now much we can do, so lets assume font is square and use width
                //as the height
+                height = pdFont.getAverageFontWidth();
            }
+            height = height/1000f;

+            float availHeight = getAvailableHeight( boundingBox, lineWidth );
+            fontSize =(availHeight/height);
        }
+        return fontSize;
    }
+/**
     * calculates the available height of the box.
     * @return the calculated available height of the box
     */
    private float getAvailableHeight( PDRectangle boundingBox, float lineWidth )
    {
+        return boundingBox.getHeight() - 2 * lineWidth;
    }