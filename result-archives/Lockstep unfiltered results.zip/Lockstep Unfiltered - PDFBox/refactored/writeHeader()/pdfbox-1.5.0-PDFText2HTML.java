/**
     * Write the header to the output document. Now also writes the tag defining
     * the character encoding.
     * 
     * @throws IOException
     *             If there is a problem writing out the header to the document.
     */
    protected void writeHeader() throws IOException 
    {
+        StringBuffer buf = new StringBuffer(INITIAL_PDF_TO_HTML_BYTES);
+        buf.append("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\"" + "\n" 
                + "\"http://www.w3.org/TR/html4/loose.dtd\">\n");
+        buf.append("<html><head>");
+        buf.append("<title>" + getTitle() + "</title>\n");
+        if(outputEncoding != null)
        {
+            buf.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=" 
                    + this.outputEncoding + "\">\n");
        }
+        buf.append("</head>\n");
+        buf.append("<body>\n");
+        super.writeString(buf.toString());
    }
+/**
     * This method will attempt to guess the title of the document using
     * either the document properties or the first lines of text.
     * 
     * @return returns the title.
     */
    protected String getTitle() 
    {
+        String titleGuess = document.getDocumentInformation().getTitle();
+        if(titleGuess != null && titleGuess.length() > 0)
        {
+            return titleGuess;
        }
        else 
        {
+            Iterator<List<TextPosition>> textIter = getCharactersByArticle().iterator();
+            float lastFontSize = -1.0f;

+            StringBuffer titleText = new StringBuffer();
+            while (textIter.hasNext()) 
            {
+                Iterator<TextPosition> textByArticle = textIter.next().iterator();
+                while (textByArticle.hasNext()) 
                {
+                    TextPosition position = textByArticle.next();

+                    float currentFontSize = position.getFontSize();
+                    //If we're past 64 chars we will assume that we're past the title
                    //64 is arbitrary 
                    if (currentFontSize != lastFontSize || titleText.length() > 64) 
                    {
+                        if (titleText.length() > 0) 
                        {
+                            return titleText.toString();
                        }
+                        lastFontSize = currentFontSize;
                    }
+                    if (currentFontSize > 13.0f) 
                    { // most body text is 12pt
+                        titleText.append(position.getCharacter());
                    }
                }
            }
        }
+        return "";
    }