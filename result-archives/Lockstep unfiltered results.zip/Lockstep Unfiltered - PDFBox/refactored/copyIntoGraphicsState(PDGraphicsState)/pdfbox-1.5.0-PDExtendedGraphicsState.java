/**
     * This will get the line width.  This will return null if there is no line width
     *
     * @return null or the LW value of the dictionary.
     */
    public Float getLineWidth()
    {
+        return getFloatItem( COSName.LW );
    }
/**
     * This will get the line join style.
     *
     * @return null or the LJ value in the dictionary.
     */
    public int getLineJoinStyle()
    {
+        return graphicsState.getInt( COSName.LJ );
    }
/**
     * This will implement the gs operator.
     *
     * @param gs The state to copy this dictionaries values into.
     *
     * @throws IOException If there is an error copying font information.
     */
+    public void copyIntoGraphicsState( PDGraphicsState gs ) throws IOException
    {
+        for( COSName key : graphicsState.keySet() )
        {
+            if( key.equals( COSName.LW ) )
            {
+                gs.setLineWidth( getLineWidth().doubleValue() );
            }
+            else if( key.equals( COSName.LC ) )
            {
+                gs.setLineCap( getLineCapStyle() );
            }
+            else if( key.equals( COSName.LJ ) )
            {
+                gs.setLineJoin( getLineJoinStyle() );
            }
+            else if( key.equals( COSName.ML ) )
            {
+                gs.setMiterLimit( getMiterLimit().doubleValue() );
            }
+            else if( key.equals( COSName.D ) )
            {
+                gs.setLineDashPattern( getLineDashPattern() );
            }
+            else if( key.equals( COSName.RI ) )
            {
+                gs.setRenderingIntent( getRenderingIntent() );
            }
+            else if( key.equals( COSName.OPM ) )
            {
+                gs.setOverprintMode( getOverprintMode().doubleValue() );
            }
+            else if( key.equals( COSName.FONT ) )
            {
+                PDFontSetting setting = getFontSetting();
+                gs.getTextState().setFont( setting.getFont() );
+                gs.getTextState().setFontSize( setting.getFontSize() );
            }
+            else if( key.equals( COSName.FL ) )
            {
+                gs.setFlatness( getFlatnessTolerance().floatValue() );
            }
+            else if( key.equals( COSName.SM ) )
            {
+                gs.setSmoothness( getSmoothnessTolerance().floatValue() );
            }
+            else if( key.equals( COSName.SA ) )
            {
+                gs.setStrokeAdjustment( getAutomaticStrokeAdjustment() );
            }
+            else if( key.equals( COSName.CA ) )
            {
+                gs.setAlphaConstants( getStrokingAlpaConstant().floatValue() );
            }/**
            else if( key.equals( CA_NS ) )
            {
            }**/
+            else if( key.equals( COSName.AIS ) )
            {
+                gs.setAlphaSource( getAlphaSourceFlag() );
            }
+            else if( key.equals( COSName.TK ) )
            {
+                gs.getTextState().setKnockoutFlag( getTextKnockoutFlag() );
            }
        }
    }
/**
     * This will get the flatness tolerance.
     *
     * @return The flatness tolerance or null if one has not been set.
     */
    public Float getFlatnessTolerance()
    {
+        return getFloatItem( COSName.FL );
    }
+/**
     * This will get the font setting of the graphics state.
     *
     * @return The font setting.
     */
    public PDFontSetting getFontSetting()
    {
+        PDFontSetting setting = null;
+        COSArray font = (COSArray)graphicsState.getDictionaryObject( COSName.FONT );
+        if( font != null )
        {
+            setting = new PDFontSetting( font );
        }
+        return setting;
    }
/**
     * This will get the alpha source flag.
     *
     * @return The alpha source flag.
     */
    public boolean getAlphaSourceFlag()
    {
+        return graphicsState.getBoolean( COSName.AIS, false );
    }
/**
     * This will get the dash pattern.
     *
     * @return null or the D value in the dictionary.
     */
    public PDLineDashPattern getLineDashPattern()
    {
+        PDLineDashPattern retval = null;
+        COSArray dp = (COSArray)graphicsState.getDictionaryObject( COSName.D );
+        if( dp != null )
        {
+            retval = new PDLineDashPattern( dp );
        }
+        return retval;
    }
/**
     * This will get the automatic stroke adjustment flag.
     *
     * @return The automatic stroke adjustment flag or null if one has not been set.
     */
    public boolean getAutomaticStrokeAdjustment()
    {
+        return graphicsState.getBoolean( COSName.SA,false );
    }
/**
     * This will get the text knockout flag.
     *
     * @return The text knockout flag.
     */
    public boolean getTextKnockoutFlag()
    {
+        return graphicsState.getBoolean( COSName.TK,true );
    }
/**
     * This will get the line cap style.
     *
     * @return null or the LC value of the dictionary.
     */
    public int getLineCapStyle()
    {
+        return graphicsState.getInt( COSName.LC );
    }
/**
     * This will get the stroking alpha constant.
     *
     * @return The stroking alpha constant or null if one has not been set.
     */
    public Float getStrokingAlpaConstant()
    {
+        return getFloatItem( COSName.CA );
    }
/**
     * This will get a float item from the dictionary.
     *
     * @param key The key to the item.
     *
     * @return The value for that item.
     */
    private Float getFloatItem( COSName key )
    {
+        Float retval = null;
+        COSNumber value = (COSNumber)graphicsState.getDictionaryObject( key );
+        if( value != null )
        {
+            retval = new Float( value.floatValue() );
        }
+        return retval;
    }
/**
     * This will get the miter limit.
     *
     * @return null or the ML value in the dictionary.
     */
    public Float getMiterLimit()
    {
+        return getFloatItem( COSName.ML );
    }
/**
     * This will get the overprint control mode.
     *
     * @return The overprint control mode or null if one has not been set.
     */
    public Float getOverprintMode()
    {
+        return getFloatItem( COSName.OPM );
    }
/**
     * This will get the rendering intent.
     *
     * @return null or the RI value in the dictionary.
     */
    public String getRenderingIntent()
    {
+        return graphicsState.getNameAsString( "RI" );
    }
/**
     * This will get the smothness tolerance.
     *
     * @return The smothness tolerance or null if one has not been set.
     */
    public Float getSmoothnessTolerance()
    {
+        return getFloatItem( COSName.SM );
    }