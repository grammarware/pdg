/**
     * This will write the body of the document.
     *
     * @param doc The document to write the body for.
     *
     * @throws IOException If there is an error writing the data.
     * @throws COSVisitorException If there is an error generating the data.
     */
    protected void doWriteBody(COSDocument doc) throws IOException, COSVisitorException
    {
+        COSDictionary trailer = doc.getTrailer();
+        COSDictionary root = (COSDictionary)trailer.getDictionaryObject( COSName.ROOT );
+        COSDictionary info = (COSDictionary)trailer.getDictionaryObject( COSName.INFO );
+        COSDictionary encrypt = (COSDictionary)trailer.getDictionaryObject( COSName.ENCRYPT );
+        if( root != null )
        {
+            addObjectToWrite( root );
        }
+        if( info != null )
        {
+            addObjectToWrite( info );
        }


+        while( objectsToWrite.size() > 0 )
        {
+            COSBase nextObject = (COSBase)objectsToWrite.removeFirst();
+            objectsToWriteSet.remove(nextObject);
+            doWriteObject( nextObject );
        }


+        willEncrypt = false;

+        if( encrypt != null )
        {
+            addObjectToWrite( encrypt );
        }

+        while( objectsToWrite.size() > 0 )
        {
+            COSBase nextObject = (COSBase)objectsToWrite.removeFirst();
+            objectsToWriteSet.remove(nextObject);
+            doWriteObject( nextObject );
        }

    }
/**
     * The visit from document method.
     *
     * @param doc The object that is being visited.
     *
     * @throws COSVisitorException If there is an exception while visiting this object.
     *
     * @return null
     */
    public Object visitFromDocument(COSDocument doc) throws COSVisitorException
    {
+        try
        {
+            doWriteHeader(doc);
+            doWriteBody(doc);
+            doWriteXRef(doc);
+            doWriteTrailer(doc);
+            return null;
        }
+        catch (IOException e)
        {
+            throw new COSVisitorException(e);
        }
    }
/**
     * write the x ref section for the pdf file
     *
     * currently, the pdf is reconstructed from the scratch, so we write a single section
     *
     * todo support for incremental writing?
     *
     * @param doc The document to write the xref from.
     *
     * @throws IOException If there is an error writing the data to the stream.
     */
    protected void doWriteXRef(COSDocument doc) throws IOException
    {
+        String offset;
+        String generation;

        // sort xref, needed only if object keys not regenerated
+        Collections.sort(getXRefEntries());
+        COSWriterXRefEntry lastEntry = (COSWriterXRefEntry)getXRefEntries().get( getXRefEntries().size()-1 );

        // remember the position where x ref is written
+        setStartxref(getStandardOutput().getPos());
        //
+        getStandardOutput().write(XREF);
+        getStandardOutput().writeEOL();
        // write start object number and object count for this x ref section
        // we assume starting from scratch
+        getStandardOutput().write(String.valueOf(0).getBytes("ISO-8859-1"));
+        getStandardOutput().write(SPACE);
+        getStandardOutput().write(String.valueOf(lastEntry.getKey().getNumber() + 1).getBytes("ISO-8859-1"));
+        getStandardOutput().writeEOL();
+        // write initial start object with ref to first deleted object and magic generation number
        offset = formatXrefOffset.format(0);
+        generation = formatXrefGeneration.format(65535);
+        getStandardOutput().write(offset.getBytes("ISO-8859-1"));
+        getStandardOutput().write(SPACE);
+        getStandardOutput().write(generation.getBytes("ISO-8859-1"));
+        getStandardOutput().write(SPACE);
+        getStandardOutput().write(XREF_FREE);
+        getStandardOutput().writeCRLF();
+        // write entry for every object
        long lastObjectNumber = 0;
+        for (Iterator i = getXRefEntries().iterator(); i.hasNext();)
        {
+            COSWriterXRefEntry entry = (COSWriterXRefEntry) i.next();
+            while( lastObjectNumber<entry.getKey().getNumber()-1 )
            {
+                offset = formatXrefOffset.format(0);
+                generation = formatXrefGeneration.format(65535);
+                getStandardOutput().write(offset.getBytes("ISO-8859-1"));
+                getStandardOutput().write(SPACE);
+                getStandardOutput().write(generation.getBytes("ISO-8859-1"));
+                getStandardOutput().write(SPACE);
+                getStandardOutput().write(XREF_FREE);
+                getStandardOutput().writeCRLF();
                lastObjectNumber++;
            }
+            lastObjectNumber = entry.getKey().getNumber();
+            offset = formatXrefOffset.format(entry.getOffset());
+            generation = formatXrefGeneration.format(entry.getKey().getGeneration());
+            getStandardOutput().write(offset.getBytes("ISO-8859-1"));
+            getStandardOutput().write(SPACE);
+            getStandardOutput().write(generation.getBytes("ISO-8859-1"));
+            getStandardOutput().write(SPACE);
+            getStandardOutput().write(entry.isFree() ? XREF_FREE : XREF_USED);
+            getStandardOutput().writeCRLF();
        }
    }
/**
     * This will write a COS object.
     *
     * @param obj The object to write.
     *
     * @throws COSVisitorException If there is an error visiting objects.
     */
+    public void doWriteObject( COSBase obj ) throws COSVisitorException
    {
+        try
        {
+            writtenObjects.add( obj );
+            // find the physical reference
+            currentObjectKey = getObjectKey( obj );
            // add a x ref entry
            addXRefEntry( new COSWriterXRefEntry(getStandardOutput().getPos(), obj, currentObjectKey));
            // write the object
            getStandardOutput().write(String.valueOf(currentObjectKey.getNumber()).getBytes("ISO-8859-1"));
            getStandardOutput().write(SPACE);
            getStandardOutput().write(String.valueOf(currentObjectKey.getGeneration()).getBytes("ISO-8859-1"));
            getStandardOutput().write(SPACE);
            getStandardOutput().write(OBJ);
            getStandardOutput().writeEOL();
+            obj.accept( this );
            getStandardOutput().writeEOL();
            getStandardOutput().write(ENDOBJ);
            getStandardOutput().writeEOL();
        }
+        catch (IOException e)
        {
+            throw new COSVisitorException(e);
        }
    }
/**
     * This will write the trailer to the PDF document.
     *
     * @param doc The document to create the trailer for.
     *
     * @throws IOException If there is an IOError while writing the document.
     * @throws COSVisitorException If there is an error while generating the data.
     */
    protected void doWriteTrailer(COSDocument doc) throws IOException, COSVisitorException
    {
+        getStandardOutput().write(TRAILER);
+        getStandardOutput().writeEOL();

+        COSDictionary trailer = doc.getTrailer();
        //sort xref, needed only if object keys not regenerated
+        Collections.sort(getXRefEntries());
+        COSWriterXRefEntry lastEntry = (COSWriterXRefEntry)getXRefEntries().get( getXRefEntries().size()-1);
+        trailer.setInt(COSName.SIZE, (int)lastEntry.getKey().getNumber()+1);
+        trailer.removeItem( COSName.PREV );
        /**
        COSObject catalog = doc.getCatalog();
        if (catalog != null)
        {
            trailer.setItem(COSName.getPDFName("Root"), catalog);
        }
        */
+        trailer.accept(this);

+        getStandardOutput().write(STARTXREF);
+        getStandardOutput().writeEOL();
+        getStandardOutput().write(String.valueOf(getStartxref()).getBytes("ISO-8859-1"));
+        getStandardOutput().writeEOL();
+        getStandardOutput().write(EOF);
    }
+private void addObjectToWrite( COSBase object )
    {
+        COSBase actual = object;
+        if( actual instanceof COSObject )
        {
+            actual = ((COSObject)actual).getObject();
        }

+        if( !writtenObjects.contains( object ) &&
            !objectsToWriteSet.contains( object ) &&
            !actualsAdded.contains( actual ) )
        {
+            objectsToWrite.add( object );
+            objectsToWriteSet.add( object );
+            if( actual != null )
            {
+                actualsAdded.add( actual );
            }
        }
    }
/**
     * This will write the header to the PDF document.
     *
     * @param doc The document to get the data from.
     *
     * @throws IOException If there is an error writing to the stream.
     */
    protected void doWriteHeader(COSDocument doc) throws IOException
    {
+        getStandardOutput().write( doc.getHeaderString().getBytes("ISO-8859-1") );
+        getStandardOutput().writeEOL();
+        getStandardOutput().write(COMMENT);
+        getStandardOutput().write(GARBAGE);
+        getStandardOutput().writeEOL();
    }
+/**
     * This will get the current object number.
     *
     * @return The current object number.
     */
    protected long getNumber()
    {
+        return number;
    }
/**
     * This will set the start xref.
     *
     * @param newStartxref The new start xref attribute.
     */
+    protected void setStartxref(long newStartxref)
    {
+        startxref = newStartxref;
    }
/**
     * This will get the xref entries.
     *
     * @return All available xref entries.
     */
    protected java.util.List getXRefEntries()
    {
+        return xRefEntries;
    }
/**
     * This will get the current start xref.
     *
     * @return The current start xref.
     */
    protected long getStartxref()
    {
+        return startxref;
    }
/**
     * This will set the current object number.
     *
     * @param newNumber The new object number.
     */
+    protected void setNumber(long newNumber)
    {
+        number = newNumber;
    }
+/**
     * This will get the standard output stream.
     *
     * @return The standard output stream.
     */
    protected COSStandardOutputStream getStandardOutput()
    {
+        return standardOutput;
    }
+/**
     * This will get the object key for the object.
     *
     * @param obj The object to get the key for.
     *
     * @return The object key for the object.
     */
+    private COSObjectKey getObjectKey( COSBase obj )
    {
+        COSBase actual = obj;
+        if( actual instanceof COSObject )
        {
+            actual = ((COSObject)obj).getObject();
        }
+        COSObjectKey key = null;
+        if( actual != null )
        {
+            key = (COSObjectKey)objectKeys.get(actual);
        }
+        if( key == null )
        {
+            key = (COSObjectKey)objectKeys.get(obj);
        }
+        if (key == null)
        {
+            setNumber(getNumber()+1);
+            key = new COSObjectKey(getNumber(),0);
+            objectKeys.put(obj, key);
+            if( actual != null )
            {
+                objectKeys.put(actual, key);
            }
        }
+        return key;
    }