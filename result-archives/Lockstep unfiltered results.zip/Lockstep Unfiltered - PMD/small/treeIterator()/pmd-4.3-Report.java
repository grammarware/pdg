public Iterator<IRuleViolation> treeIterator() {
+        return violationTree.iterator();
    }