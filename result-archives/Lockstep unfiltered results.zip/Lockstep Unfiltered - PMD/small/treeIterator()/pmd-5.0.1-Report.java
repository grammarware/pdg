public Iterator<RuleViolation> treeIterator() {
+        return violationTree.iterator();
    }