public Scope getScope() {
+			if (node instanceof JavaNode) {
+				return ((JavaNode) node).getScope();
			}
+			return null;
		}