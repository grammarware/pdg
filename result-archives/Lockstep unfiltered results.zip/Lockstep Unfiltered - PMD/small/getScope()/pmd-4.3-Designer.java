public Scope getScope() {
+    		if (node instanceof SimpleNode)
+    			return ((SimpleNode)node).getScope();
+    		return null;
    	}