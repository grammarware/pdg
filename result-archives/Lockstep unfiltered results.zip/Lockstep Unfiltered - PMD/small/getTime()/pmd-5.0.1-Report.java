public String getTime() {
+            return DateTimeUtil.asHoursMinutesSeconds(duration);
        }