public int getChildCount() {
+			return node.jjtGetNumChildren();
		}