public void addIncludePattern(String aPattern) {
		
+		if (includePatterns.contains(aPattern)) return;
		
+		includePatterns.add(aPattern);
		patternsChanged();
	}