/**
     * @see javax.swing.tree.TreeModel
     */
    public Object getChild(Object parent, int index) {
+        return ((Node) parent).jjtGetChild(index);
    }