public DFAGraphRule() {
+	super.setUsesDFA();
    }