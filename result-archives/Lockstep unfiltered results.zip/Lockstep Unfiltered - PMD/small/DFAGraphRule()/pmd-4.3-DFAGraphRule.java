public DFAGraphRule() {
+        super.setUsesDFA();
    }