public boolean treeIsEmpty() {
+        return !violationTree.iterator().hasNext();
    }