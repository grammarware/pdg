public int treeSize() {
+        return violationTree.size();
    }