public boolean isLeaf() {
+			return node.jjtGetNumChildren() == 0;
		}