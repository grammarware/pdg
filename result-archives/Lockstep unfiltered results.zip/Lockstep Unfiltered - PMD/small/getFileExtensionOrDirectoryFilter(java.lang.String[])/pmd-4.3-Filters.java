/**
	 * Get a File Filter for files with the given extensions, ignoring case.
	 * @param extensions The extensions to filter.
	 * @return A File Filter.
	 */
	public static Filter<File> getFileExtensionFilter(String... extensions) {
+		return new FileExtensionFilter(extensions);
	}
/**
	 * Get a File Filter for directories or for files with the given extensions, ignoring case.
	 * @param extensions The extensions to filter.
	 * @return A File Filter.
	 */
	public static Filter<File> getFileExtensionOrDirectoryFilter(String... extensions) {
+		return new OrFilter<File>(getFileExtensionFilter(extensions), getDirectoryFilter());
	}
/**
	 * Get a File Filter for directories.
	 * @return A File Filter.
	 */
	public static Filter<File> getDirectoryFilter() {
+		return DirectoryFilter.INSTANCE;
	}