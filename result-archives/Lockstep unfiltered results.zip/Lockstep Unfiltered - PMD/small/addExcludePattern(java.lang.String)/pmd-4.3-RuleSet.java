public void addExcludePattern(String excludePattern) {
+        this.excludePatterns.add(excludePattern);
    }