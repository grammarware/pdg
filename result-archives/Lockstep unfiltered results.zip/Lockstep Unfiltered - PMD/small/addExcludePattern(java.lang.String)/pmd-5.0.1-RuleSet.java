public void addExcludePattern(String aPattern) {

+		if (excludePatterns.contains(aPattern)) return;
		
+		excludePatterns.add(aPattern);
		patternsChanged();
	}