public static void main(String[] args) {
        MatchesFunction.registerSelfInSimpleContext();
        TypeOfFunction.registerSelfInSimpleContext();
+        new MainFrame();
    }