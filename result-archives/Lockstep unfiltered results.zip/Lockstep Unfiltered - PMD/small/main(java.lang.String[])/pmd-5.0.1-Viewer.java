public static void main(String[] args) {
	Initializer.initialize();
+        new MainFrame();
    }