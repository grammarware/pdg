/**
     * @see javax.swing.tree.TreeModel#getChildCount(java.lang.Object)
     */
    public int getChildCount(Object parent) {
+        return ((SimpleNode) parent).jjtGetNumChildren();
    }