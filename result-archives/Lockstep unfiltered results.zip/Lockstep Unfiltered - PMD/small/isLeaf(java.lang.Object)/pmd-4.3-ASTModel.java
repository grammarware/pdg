/**
     * @see javax.swing.tree.TreeModel#isLeaf(java.lang.Object)
     */
    public boolean isLeaf(Object node) {
+        return ((SimpleNode) node).jjtGetNumChildren() == 0;
    }