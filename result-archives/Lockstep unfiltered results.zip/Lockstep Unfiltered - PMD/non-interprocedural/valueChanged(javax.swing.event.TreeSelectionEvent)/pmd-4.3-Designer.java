public void valueChanged(TreeSelectionEvent e) {
    		if (e.getNewLeadSelectionPath() != null) {
    			ASTTreeNode astTreeNode = (ASTTreeNode)e.getNewLeadSelectionPath().getLastPathComponent();

    			DefaultMutableTreeNode symbolTableTreeNode = new DefaultMutableTreeNode();
    			DefaultMutableTreeNode selectedAstTreeNode = new DefaultMutableTreeNode("AST Node: " + astTreeNode.label());
    			symbolTableTreeNode.add(selectedAstTreeNode);

	    		List<Scope> scopes = new ArrayList<Scope>();
	    		Scope scope = astTreeNode.getScope();
	    		while (scope != null)
	    		{
	    			scopes.add(scope);
	    			scope = scope.getParent();
	    		}
	    		Collections.reverse(scopes);
	    		for (int i = 0; i < scopes.size(); i++) {
	    			scope = scopes.get(i);
	    			DefaultMutableTreeNode scopeTreeNode =  new DefaultMutableTreeNode("Scope: " + scope.getClass().getSimpleName());
	    			selectedAstTreeNode.add(scopeTreeNode);
	    			if (!(scope instanceof MethodScope || scope instanceof LocalScope)) {
	    				if (!scope.getClassDeclarations().isEmpty()) {
				    		for (ClassNameDeclaration classNameDeclaration: scope.getClassDeclarations().keySet()) {
				    			DefaultMutableTreeNode classNameDeclarationTreeNode = new DefaultMutableTreeNode("Class name declaration: " + classNameDeclaration);
				    			scopeTreeNode.add(classNameDeclarationTreeNode);
				    			for (NameOccurrence nameOccurrence: scope.getClassDeclarations().get(classNameDeclaration)) {
					    			DefaultMutableTreeNode nameOccurenceTreeNode = new DefaultMutableTreeNode("Name occurrence: " + nameOccurrence);
					    			classNameDeclarationTreeNode.add(nameOccurenceTreeNode);
				    			}
				    		}
	    				}
	    			}
	    			if (scope instanceof ClassScope) {
	    				ClassScope classScope = (ClassScope)scope;
	    				if (!classScope.getMethodDeclarations().isEmpty()) {
				    		for (MethodNameDeclaration methodNameDeclaration: classScope.getMethodDeclarations().keySet()) {
				    			DefaultMutableTreeNode methodNameDeclarationTreeNode = new DefaultMutableTreeNode("Method name declaration: " + methodNameDeclaration);
				    			scopeTreeNode.add(methodNameDeclarationTreeNode);
				    			for (NameOccurrence nameOccurrence: classScope.getMethodDeclarations().get(methodNameDeclaration)) {
					    			DefaultMutableTreeNode nameOccurenceTreeNode = new DefaultMutableTreeNode("Name occurrence: " + nameOccurrence);
					    			methodNameDeclarationTreeNode.add(nameOccurenceTreeNode);
				    			}
				    		}
	    				}
	    			}
	    			if (!(scope instanceof SourceFileScope)) {
	    				if (!scope.getVariableDeclarations().isEmpty()) {
				    		for (VariableNameDeclaration variableNameDeclaration: scope.getVariableDeclarations().keySet()) {
				    			DefaultMutableTreeNode variableNameDeclarationTreeNode = new DefaultMutableTreeNode("Variable name declaration: " + variableNameDeclaration);
				    			scopeTreeNode.add(variableNameDeclarationTreeNode);
				    			for (NameOccurrence nameOccurrence: scope.getVariableDeclarations().get(variableNameDeclaration)) {
					    			DefaultMutableTreeNode nameOccurenceTreeNode = new DefaultMutableTreeNode("Name occurrence: " + nameOccurrence);
					    			variableNameDeclarationTreeNode.add(nameOccurenceTreeNode);
				    			}
				    		}
	    				}
	    			}
	    		}
	    		loadSymbolTableTreeData(symbolTableTreeNode);
    		}
        }