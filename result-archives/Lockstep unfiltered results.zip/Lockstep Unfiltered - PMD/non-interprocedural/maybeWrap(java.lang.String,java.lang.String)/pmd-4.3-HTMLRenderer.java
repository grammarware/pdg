private String maybeWrap(String filename, String line) {
+        if (linkPrefix == null) {
+            return filename;
        }
+        String newFileName = filename.substring(0, filename.lastIndexOf('.')).replace('\\', '/');
+        return "<a href=\"" + linkPrefix + newFileName + ".html#" + line + "\">" + newFileName + "</a>";
    }