+public void renderFileViolations(Iterator<IRuleViolation> violations) throws IOException {
+        Writer writer = getWriter();
        StringBuffer buf = new StringBuffer();

        empty = !violations.hasNext();
+        while (violations.hasNext()) {
+            buf.setLength(0);
            IRuleViolation rv = violations.next();
+            buf.append(PMD.EOL).append(rv.getFilename());
+            buf.append(':').append(Integer.toString(rv.getBeginLine()));
+            buf.append('\t').append(rv.getDescription());
+            writer.write(buf.toString());
        }
    }