private void logRulesUsed(RuleSets rules) {
+		log("Using these rulesets: " + configuration.getRuleSets(), Project.MSG_VERBOSE);

+		RuleSet[] ruleSets = rules.getAllRuleSets();
+		for (RuleSet ruleSet : ruleSets) {
+			for (Rule rule : ruleSet.getRules()) {
+				log("Using rule " + rule.getName(), Project.MSG_VERBOSE);
			}
		}
	}