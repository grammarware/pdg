private void logRulesUsed(RuleSets rules) {
+        log("Using these rulesets: " + ruleSetFiles, Project.MSG_VERBOSE);

+        RuleSet[] ruleSets = rules.getAllRuleSets();
+        for (int j = 0; j < ruleSets.length; j++) {
            RuleSet ruleSet = ruleSets[j];

+            for (Rule rule: ruleSet.getRules()) {
+                log("Using rule " + rule.getName(), Project.MSG_VERBOSE);
            }
        }
    }