public void go() {
+        TokenEntry.clearImages();
+        matchAlgorithm = new MatchAlgorithm(
        		source, tokens, 
        		configuration.minimumTileSize(), 
        		listener
        		);
+        matchAlgorithm.findMatches();
    }