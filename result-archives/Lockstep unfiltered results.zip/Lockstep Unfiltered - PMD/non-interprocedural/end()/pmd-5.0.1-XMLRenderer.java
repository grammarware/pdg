/**
     * {@inheritDoc}
     */
    @Override
    public void end() throws IOException {
+		Writer writer = getWriter();
		StringBuilder buf = new StringBuilder(500);
+		// errors
		for (Report.ProcessingError pe : errors) {
+		    buf.setLength(0);
+		    buf.append("<error ").append("filename=\"");
+		    StringUtil.appendXmlEscaped(buf, pe.getFile());
+		    buf.append("\" msg=\"");
+		    StringUtil.appendXmlEscaped(buf, pe.getMsg());
+		    buf.append("\"/>").append(PMD.EOL);
+		    writer.write(buf.toString());
		}
	
+		// suppressed violations
		if (showSuppressedViolations) {
+		    for (Report.SuppressedViolation s : suppressed) {
+			buf.setLength(0);
+			buf.append("<suppressedviolation ").append("filename=\"");
+			StringUtil.appendXmlEscaped(buf, s.getRuleViolation().getFilename());
+			buf.append("\" suppressiontype=\"");
+			StringUtil.appendXmlEscaped(buf, s.suppressedByNOPMD() ? "nopmd" : "annotation");
+			buf.append("\" msg=\"");
+			StringUtil.appendXmlEscaped(buf, s.getRuleViolation().getDescription());
+			buf.append("\" usermsg=\"");
+			StringUtil.appendXmlEscaped(buf, s.getUserMessage() == null ? "" : s.getUserMessage());
+			buf.append("\"/>").append(PMD.EOL);
+			writer.write(buf.toString());
		    }
		}
	
+		writer.write("</pmd>" + PMD.EOL);
    }