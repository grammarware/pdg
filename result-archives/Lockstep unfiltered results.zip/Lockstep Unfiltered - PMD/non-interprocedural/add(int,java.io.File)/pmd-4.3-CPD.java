+private void add(int fileCount, File file) throws IOException {

+        if (skipDuplicates) {
+            // TODO refactor this thing into a separate class
            String signature = file.getName() + '_' + file.length();
+            if (current.contains(signature)) {
+                System.err.println("Skipping " + file.getAbsolutePath() + " since it appears to be a duplicate file and --skip-duplicate-files is set");
+                return;
            }
+            current.add(signature);
        }

+        if (!file.getCanonicalPath().equals(new File(file.getAbsolutePath()).getCanonicalPath())) {
+            System.err.println("Skipping " + file + " since it appears to be a symlink");
+            return;
        }

+        listener.addedFile(fileCount, file);
+        SourceCode sourceCode = new SourceCode(new SourceCode.FileCodeLoader(file, encoding));
+        language.getTokenizer().tokenize(sourceCode, tokens);
+        source.put(sourceCode.getFileName(), sourceCode);
    }