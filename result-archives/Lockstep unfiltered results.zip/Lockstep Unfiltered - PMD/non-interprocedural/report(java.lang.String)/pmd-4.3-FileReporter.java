public void report(String content) throws ReportException {
+        try {
+            Writer writer = null;
+            try {
+            	OutputStream outputStream;
+            	if (reportFile == null) {
+            		outputStream = System.out;
            	} else {
+            		outputStream = new FileOutputStream(reportFile);
            	}
+                writer = new BufferedWriter(new OutputStreamWriter(outputStream, encoding));
+                writer.write(content);
            } finally {
                if (writer != null) writer.close();
            }
+        } catch (IOException ioe) {
+            throw new ReportException(ioe);
        }
    }