+public String getLine(int number) {
	String[] lines= getLines();
+	if (number < lines.length) {
+	    return lines[number];
	}
+        throw new RuntimeException("Line number " + number + " not found");
    }