/**
	 * Return the length of the shortest string in the array.
	 * If any one of them is null then it returns 0.
	 *
	 * @param strings String[]
	 * @return int
	 */
+	public static int lengthOfShortestIn(String[] strings) {

+		int minLength = Integer.MAX_VALUE;

+		for (int i=0; i<strings.length; i++) {
+			if (strings[i] == null) return 0;
+			minLength = Math.min(minLength, strings[i].length());
		}

+		return minLength;
	}