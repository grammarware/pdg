public void valueChanged(ListSelectionEvent e) {
+            ListSelectionModel lsm = (ListSelectionModel)e.getSource();
+            if (!lsm.isSelectionEmpty()) {
+                Object o = xpathResults.get(lsm.getMinSelectionIndex());
+                if (o instanceof SimpleNode) {
+                    codeEditorPane.select((SimpleNode) o);
                }
            }
        }