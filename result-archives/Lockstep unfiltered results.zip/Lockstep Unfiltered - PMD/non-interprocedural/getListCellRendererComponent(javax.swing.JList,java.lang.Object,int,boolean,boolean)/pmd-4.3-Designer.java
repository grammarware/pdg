public Component getListCellRendererComponent(
                JList list,
                Object value,
                int index,
                boolean isSelected,
                boolean cellHasFocus) {

+            if (isSelected) {
+                setBackground(list.getSelectionBackground());
+                setForeground(list.getSelectionForeground());
            } else {
+                setBackground(list.getBackground());
+                setForeground(list.getForeground());
            }

+            String text;
+            if (value instanceof SimpleNode) {
                SimpleNode node = (SimpleNode) value;
+                StringBuffer sb = new StringBuffer();
+                String name = node.getClass().getName().substring(node.getClass().getName().lastIndexOf('.') + 1);
+                sb.append(name)
                    .append(" at line ").append(node.getBeginLine())
                    .append(" column ").append(node.getBeginColumn())
                    .append(PMD.EOL);
+                text = sb.toString();
            } else {
+                text = value.toString();
            }
+            setText(text);
+            return this;
        }