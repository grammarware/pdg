/**
     * checks the children and creates them if neccessary
     */
    private void checkChildren() {
+        if (children == null) {
+            children = new ArrayList<TreeNode>(node.jjtGetNumChildren());
+            for (int i = 0; i < node.jjtGetNumChildren(); i++) {
+                children.add(new SimpleNodeTreeNodeAdapter(this, (SimpleNode) node.jjtGetChild(i)));
            }
        }
    }