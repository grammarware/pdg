public TreeNode getChildAt(int childIndex) {

+			if (kids == null) {
+				kids = new ASTTreeNode[node.jjtGetNumChildren()];
+				for (int i = 0; i < kids.length; i++) {
+					kids[i] = new ASTTreeNode(this.parent, node.jjtGetChild(i));
				}
			}
+			return kids[childIndex];
		}