/**
     * Add a new rule by reference to this ruleset.
     *
     * @param ruleSetFileName the ruleset which contains the rule
     * @param rule the rule to be added
     */
    public void addRuleByReference(String ruleSetFileName, Rule rule) {
+        if (ruleSetFileName == null) {
+            throw new RuntimeException("Adding a rule by reference is not allowed with a null rule set file name.");
        }
+        if (rule == null) {
+            throw new RuntimeException("Null Rule reference added to a RuleSet; that's a bug somewhere in PMD");
        }
+        if (!(rule instanceof RuleReference)) {
+        	RuleSetReference ruleSetReference = new RuleSetReference();
+        	ruleSetReference.setRuleSetFileName(ruleSetFileName);
+	        RuleReference ruleReference = new RuleReference();
+	        ruleReference.setRule(rule);
+	        ruleReference.setRuleSetReference(ruleSetReference);
+	        rule = ruleReference;
        }
+        rules.add(rule);
    }