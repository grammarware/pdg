/**
     * @return a Map summarizing the Report: String (rule name) ->Integer (count of violations)
     */
    public Map<String, Integer> getSummary() {
+        Map<String, Integer> summary = new HashMap<String, Integer>();
+        for (RuleViolation rv: violations) {
+            String name = rv.getRule().getName();
+            if (!summary.containsKey(name)) {
+                summary.put(name, NumericConstants.ZERO);
            }
+            Integer count = summary.get(name);
+            summary.put(name, count + 1);
        }
+        return summary;
    }