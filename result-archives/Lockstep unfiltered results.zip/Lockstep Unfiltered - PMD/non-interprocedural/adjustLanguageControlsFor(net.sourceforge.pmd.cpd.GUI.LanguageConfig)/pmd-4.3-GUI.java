private void adjustLanguageControlsFor(LanguageConfig current) {
+    	 ignoreLiteralsCheckbox.setEnabled(current.ignoreLiteralsByDefault());
+         extensionField.setText(current.extensions()[0]);
+         boolean enableExtension = current.extensions()[0].length() == 0;
+         extensionField.setEnabled(enableExtension);
+         extensionLabel.setEnabled(enableExtension);
    }