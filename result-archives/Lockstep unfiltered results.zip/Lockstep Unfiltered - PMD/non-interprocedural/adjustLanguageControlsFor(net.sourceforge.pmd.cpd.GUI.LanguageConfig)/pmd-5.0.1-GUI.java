private void adjustLanguageControlsFor(LanguageConfig current) {
+         ignoreIdentifiersCheckbox.setEnabled(current.canIgnoreIdentifiers());
+         ignoreLiteralsCheckbox.setEnabled(current.canIgnoreLiterals());
+         ignoreAnnotationsCheckbox.setEnabled(current.canIgnoreAnnotations());
+         extensionField.setText(current.extensions()[0]);
+         boolean enableExtension = current.extensions()[0].length() == 0;
+         extensionField.setEnabled(enableExtension);
+         extensionLabel.setEnabled(enableExtension);
    }