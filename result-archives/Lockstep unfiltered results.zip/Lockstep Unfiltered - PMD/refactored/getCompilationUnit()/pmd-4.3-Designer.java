private SimpleNode getCompilationUnit() {
+    	SourceTypeHandler handler = SourceTypeHandlerBroker.getVisitorsFactoryForSourceType(getSourceType());
+    	Parser parser = handler.getParser();
    	parser.setExcludeMarker(PMD.EXCLUDE_MARKER);
    	SimpleNode simpleNode = (SimpleNode)parser.parse(new StringReader(codeEditorPane.getText()));
+    	handler.getSymbolFacade().start(simpleNode);
+    	handler.getTypeResolutionFacade(null).start(simpleNode);
    	return simpleNode;
    }
private int selectedSourceTypeIndex() {
+    	for (int i=0; i<sourceTypeMenuItems.length; i++) {
+    		if (sourceTypeMenuItems[i].isSelected()) return i;
    	}
+    	throw new RuntimeException("Initial default source type not specified");
    }
private SourceType getSourceType() {

+    	return (SourceType)sourceTypeSets[selectedSourceTypeIndex()][1];
    }