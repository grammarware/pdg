private void setupClassLoader() {

+		if (classpath == null) {
+			log("Using the normal ClassLoader", Project.MSG_VERBOSE);
		} else {
+			log("Using the AntClassLoader", Project.MSG_VERBOSE);
			configuration.setClassLoader(new AntClassLoader(getProject(), classpath));
		}
+		try {
			/*
			 * 'basedir' is added to the path to make sure that relative paths
			 * such as "<ruleset>resources/custom_ruleset.xml</ruleset>" still
			 * work when ant is invoked from a different directory using "-f"
			 */
			configuration.prependClasspath(getProject().getBaseDir().toString());
			if (auxClasspath != null) {
				log("Using auxclasspath: " + auxClasspath, Project.MSG_VERBOSE);
				configuration.prependClasspath(auxClasspath.toString());
			}
+		} catch (IOException ioe) {
+			throw new BuildException(ioe.getMessage(), ioe);
		}
	}
private void doTask() {
+		setupClassLoader();

+		// Setup RuleSetFactory and validate RuleSets
		RuleSetFactory ruleSetFactory = new RuleSetFactory();
		ruleSetFactory.setClassLoader(configuration.getClassLoader());
+		try {
			// This is just used to validate and display rules. Each thread will create its own ruleset
+			ruleSetFactory.setMinimumPriority(configuration.getMinimumPriority());
			ruleSetFactory.setWarnDeprecated(true);
			String ruleSets = configuration.getRuleSets();
			if (StringUtil.isNotEmpty(ruleSets)) {
				// Substitute env variables/properties
				configuration.setRuleSets(getProject().replaceProperties(ruleSets));
			}
			RuleSets rules = ruleSetFactory.createRuleSets(configuration.getRuleSets());
			ruleSetFactory.setWarnDeprecated(false);
			logRulesUsed(rules);
+		} catch (RuleSetNotFoundException e) {
+			throw new BuildException(e.getMessage(), e);
		}

		if (configuration.getSuppressMarker() != null) {
			log("Setting suppress marker to be " + configuration.getSuppressMarker(), Project.MSG_VERBOSE);
		}

+		// Start the Formatters
		for (Formatter formatter : formatters) {
			log("Sending a report to " + formatter, Project.MSG_VERBOSE);
+			formatter.start(getProject().getBaseDir().toString());
		}

		//log("Setting Language Version " + languageVersion.getShortName(), Project.MSG_VERBOSE);

		// TODO Do we really need all this in a loop over each FileSet?  Seems like a lot of redundancy
		RuleContext ctx = new RuleContext();
+		Report errorReport = new Report();
		final AtomicInteger reportSize = new AtomicInteger();
		final String separator = System.getProperty("file.separator");

		for (FileSet fs : filesets) {
+			List<DataSource> files = new LinkedList<DataSource>();
			DirectoryScanner ds = fs.getDirectoryScanner(getProject());
+			String[] srcFiles = ds.getIncludedFiles();
+			for (String srcFile : srcFiles) {
+				File file = new File(ds.getBasedir() + separator + srcFile);
+				files.add(new FileDataSource(file));
			}

			final String inputPaths = ds.getBasedir().getPath();
			configuration.setInputPaths(inputPaths);

			Renderer logRenderer = new AbstractRenderer("log", "Logging renderer") {
				public void start() {
					// Nothing to do
				}

				public void startFileAnalysis(DataSource dataSource) {
					log("Processing file " + dataSource.getNiceFileName(false, inputPaths), Project.MSG_VERBOSE);
				}

				public void renderFileReport(Report r) {
					int size = r.size();
					if (size > 0) {
						reportSize.addAndGet(size);
					}
				}

				public void end() {
					// Nothing to do
				}

				public String defaultFileExtension() { return null;	}	// not relevant
			};
+			List<Renderer> renderers = new LinkedList<Renderer>();
+			renderers.add(logRenderer);
			for (Formatter formatter : formatters) {
+				renderers.add(formatter.getRenderer());
			}
			try {
				PMD.processFiles(configuration, ruleSetFactory, files, ctx, renderers);
+			} catch (RuntimeException pmde) {
+				handleError(ctx, errorReport, pmde);
			}
		}

+		int problemCount = reportSize.get();
		log(problemCount + " problems found", Project.MSG_VERBOSE);

+		for (Formatter formatter : formatters) {
+			formatter.end(errorReport);
		}

		if (failuresPropertyName != null && problemCount > 0) {
			getProject().setProperty(failuresPropertyName, String.valueOf(problemCount));
			log("Setting property " + failuresPropertyName + " to " + problemCount, Project.MSG_VERBOSE);
		}

		if (failOnRuleViolation && problemCount > maxRuleViolations) {
+			throw new BuildException("Stopping build since PMD found " + problemCount + " rule violations in the code");
		}
	}
private String getNestedRuleSetFiles() {
		final StringBuilder sb = new StringBuilder();
+		for (Iterator<RuleSetWrapper> it = nestedRules.iterator(); it.hasNext();) {
+			RuleSetWrapper rs = it.next();
+			sb.append(rs.getFile());
+			if (it.hasNext()) {
+				sb.append(',');
			}
		}
+		return sb.toString();
	}
private void validate() throws BuildException {
+		if (formatters.isEmpty()) {
			Formatter defaultFormatter = new Formatter();
			defaultFormatter.setType("text");
			defaultFormatter.setToConsole(true);
			formatters.add(defaultFormatter);
		} else {
+			for (Formatter f : formatters) {
+				if (f.isNoOutputSupplied()) {
+					throw new BuildException("toFile or toConsole needs to be specified in Formatter");
				}
			}
		}

+		if (configuration.getRuleSets() == null) {
+			if (nestedRules.isEmpty()) {
+				throw new BuildException("No rulesets specified");
			}
+			configuration.setRuleSets(getNestedRuleSetFiles());
		}
	}
+private void handleError(RuleContext ctx, Report errorReport, RuntimeException pmde) {
		
+		pmde.printStackTrace();
		log(pmde.toString(), Project.MSG_VERBOSE);
		
		Throwable cause = pmde.getCause();
		
		if (cause != null) {
+			StringWriter strWriter = new StringWriter();
+			PrintWriter printWriter = new PrintWriter(strWriter);
			cause.printStackTrace(printWriter);
			log(strWriter.toString(), Project.MSG_VERBOSE);
			IOUtil.closeQuietly(printWriter);
			
			if (StringUtil.isNotEmpty(cause.getMessage())) {
				log(cause.getMessage(), Project.MSG_VERBOSE);
			}
		}
		
		if (failOnError) {
+			throw new BuildException(pmde);
		}
+		errorReport.addError(new Report.ProcessingError(pmde.getMessage(), ctx.getSourceCodeFilename()));
	}
@Override
	public void execute() throws BuildException {
+		validate();
+		final Handler antLogHandler = new AntLogHandler(this);
+		final ScopedLogHandlersManager logManager = new ScopedLogHandlersManager(Level.FINEST, antLogHandler);
+		try {
+			doTask();
		} finally {
+			logManager.close();
		}
	}
private void logRulesUsed(RuleSets rules) {
		log("Using these rulesets: " + configuration.getRuleSets(), Project.MSG_VERBOSE);

+		RuleSet[] ruleSets = rules.getAllRuleSets();
		for (RuleSet ruleSet : ruleSets) {
			for (Rule rule : ruleSet.getRules()) {
				log("Using rule " + rule.getName(), Project.MSG_VERBOSE);
			}
		}
	}