/**
     * Add all Rules from the given RuleSet which want to participate in the
     * RuleChain.
     * 
     * @param ruleSet
     *            The RuleSet to add Rules from.
     */
+    public void add(RuleSet ruleSet) {
        Language language = ruleSet.getLanguage();
+        for (Rule r: ruleSet.getRules()) {
+            add(ruleSet, r, language);
        }
    }
/**
     * Add the given Rule if it wants to participate in the RuleChain.
     * 
     * @param ruleSet
     *            The RuleSet to which the rule belongs.
     * @param rule
     *            The Rule to add.
     * @param language
     *            The Language used by the Rule.
     */
    private void add(RuleSet ruleSet, Rule rule, Language language) {
+        RuleChainVisitor visitor = getRuleChainVisitor(language);
+        if (visitor != null) {
+            visitor.add(ruleSet, rule);
        }
    }
+// Get the RuleChainVisitor for the appropriate Language.
    private RuleChainVisitor getRuleChainVisitor(Language language) {
        if (language == null) {
            language = Language.JAVA;
        }
+        RuleChainVisitor visitor = languageToRuleChainVisitor.get(language);
+        if (visitor == null) {
+            if (Language.JAVA.equals(language)) {
                visitor = new JavaRuleChainVisitor();
+            } else if (Language.JSP.equals(language)) {
                visitor = new JspRuleChainVisitor();
            } else {
+                throw new IllegalArgumentException("Unknown language: "
                        + language);
            }
+            languageToRuleChainVisitor.put(language, visitor);
        }
+        return visitor;
    }