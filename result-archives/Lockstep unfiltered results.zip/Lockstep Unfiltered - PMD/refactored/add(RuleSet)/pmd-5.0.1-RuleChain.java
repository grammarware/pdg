+// Get the RuleChainVisitor for the appropriate Language.
    private RuleChainVisitor getRuleChainVisitor(Language language) {
+	RuleChainVisitor visitor = languageToRuleChainVisitor.get(language);
+	if (visitor == null) {
+	    if (language.getRuleChainVisitorClass() != null) {
		try {
		    visitor = (RuleChainVisitor) language.getRuleChainVisitorClass().newInstance();
		} catch (InstantiationException e) {
		    throw new IllegalStateException("Failure to created RuleChainVisitor: "
			    + language.getRuleChainVisitorClass(), e);
		} catch (IllegalAccessException e) {
		    throw new IllegalStateException("Failure to created RuleChainVisitor: "
			    + language.getRuleChainVisitorClass(), e);
		}
+		languageToRuleChainVisitor.put(language, visitor);
	    } else {
+		throw new IllegalArgumentException("Language does not have a RuleChainVisitor: " + language);
	    }
	}
+	return visitor;
    }
/**
     * Add all Rules from the given RuleSet which want to participate in the
     * RuleChain.
     * 
     * @param ruleSet
     *            The RuleSet to add Rules from.
     */
+    public void add(RuleSet ruleSet) {
+	for (Rule r : ruleSet.getRules()) {
+            add(ruleSet, r);
	}
    }
/**
     * Add the given Rule if it wants to participate in the RuleChain.
     * 
     * @param ruleSet
     *            The RuleSet to which the rule belongs.
     * @param rule
     *            The Rule to add.
     */
    private void add(RuleSet ruleSet, Rule rule) {
+	RuleChainVisitor visitor = getRuleChainVisitor(rule.getLanguage());
+	if (visitor != null) {
+            visitor.add(ruleSet, rule);
	}
    }