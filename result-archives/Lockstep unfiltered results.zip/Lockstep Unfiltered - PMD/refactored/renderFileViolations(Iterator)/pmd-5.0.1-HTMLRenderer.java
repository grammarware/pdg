+private void glomRuleViolations(Writer writer, Iterator<RuleViolation> violations) throws IOException {
	    
    	StringBuilder buf = new StringBuilder(500);
	    
+		while (violations.hasNext()) {
		    RuleViolation rv = violations.next();
+		    buf.setLength(0);
+		    buf.append("<tr");
+		    if (colorize) {
+		    	buf.append(" bgcolor=\"lightgrey\"");
		    }
+		    colorize = !colorize;
+		    buf.append("> " + PMD.EOL);
+		    buf.append("<td align=\"center\">" + violationCount + "</td>" + PMD.EOL);
+		    buf.append("<td width=\"*%\">"
+			    + maybeWrap(rv.getFilename(), linePrefix == null ? "" : linePrefix
				    + Integer.toString(rv.getBeginLine())) + "</td>" + PMD.EOL);
+		    buf.append("<td align=\"center\" width=\"5%\">" + Integer.toString(rv.getBeginLine()) + "</td>" + PMD.EOL);
	
+		    String d = StringUtil.htmlEncode(rv.getDescription());
	
+		    String infoUrl = rv.getRule().getExternalInfoUrl();
+		    if (StringUtil.isNotEmpty(infoUrl)) {
+				d = "<a href=\"" + infoUrl + "\">" + d + "</a>";
			    }
+		    buf.append("<td width=\"*\">" + d + "</td>" + PMD.EOL);
+		    buf.append("</tr>" + PMD.EOL);
+		    writer.write(buf.toString());
+		    violationCount++;
			}
    }
+private String maybeWrap(String filename, String line) {
+		if (StringUtil.isEmpty(linkPrefix)) {
+		    return filename;
		}
+		String newFileName = filename;
		int index = filename.lastIndexOf('.');
+		if (index >= 0) {
+		    newFileName = filename.substring(0, index).replace('\\', '/');
		}
+		return "<a href=\"" + linkPrefix + newFileName + ".html#" + line + "\">" + newFileName + "</a>";
    }
/**
     * {@inheritDoc}
     */
    @Override
+    public void renderFileViolations(Iterator<RuleViolation> violations) throws IOException {
+		Writer writer = getWriter();
+		glomRuleViolations(writer, violations);
    }