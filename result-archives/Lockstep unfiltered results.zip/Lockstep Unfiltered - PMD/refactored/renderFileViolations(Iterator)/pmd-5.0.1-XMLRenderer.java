/**
     * {@inheritDoc}
     */
    @Override
+    public void renderFileViolations(Iterator<RuleViolation> violations) throws IOException {
+		Writer writer = getWriter();
		StringBuilder buf = new StringBuilder(500);
+		String filename = null;
	
+		// rule violations
+		while (violations.hasNext()) {
+		    buf.setLength(0);
		    RuleViolation rv = violations.next();
+		    if (!rv.getFilename().equals(filename)) { // New File
+			if (filename != null) {// Not first file ?
+			    buf.append("</file>").append(PMD.EOL);
			}
+			filename = rv.getFilename();
+			buf.append("<file name=\"");
+			StringUtil.appendXmlEscaped(buf, filename);
+			buf.append("\">").append(PMD.EOL);
		    }
	
+		    buf.append("<violation beginline=\"").append(rv.getBeginLine());
+		    buf.append("\" endline=\"").append(rv.getEndLine());
+		    buf.append("\" begincolumn=\"").append(rv.getBeginColumn());
+		    buf.append("\" endcolumn=\"").append(rv.getEndColumn());
+		    buf.append("\" rule=\"");
+		    StringUtil.appendXmlEscaped(buf, rv.getRule().getName());
+		    buf.append("\" ruleset=\"");
+		    StringUtil.appendXmlEscaped(buf, rv.getRule().getRuleSetName());
+		    buf.append('"');
+		    maybeAdd("package", rv.getPackageName(), buf);
		    maybeAdd("class", rv.getClassName(), buf);
		    maybeAdd("method", rv.getMethodName(), buf);
		    maybeAdd("variable", rv.getVariableName(), buf);
+		    maybeAdd("externalInfoUrl", rv.getRule().getExternalInfoUrl(), buf);
+		    buf.append(" priority=\"");
+		    buf.append(rv.getRule().getPriority().getPriority());
+		    buf.append("\">").append(PMD.EOL);
+		    StringUtil.appendXmlEscaped(buf, rv.getDescription());
	
+		    buf.append(PMD.EOL);
+		    buf.append("</violation>");
+		    buf.append(PMD.EOL);
+		    writer.write(buf.toString());
		}
+		if (filename != null) { // Not first file ?
+		    writer.write("</file>");
+		    writer.write(PMD.EOL);
		}
    }
private void maybeAdd(String attr, String value, StringBuilder buf) {
+		if (value != null && value.length() > 0) {
+		    buf.append(' ').append(attr).append("=\"");
+		    StringUtil.appendXmlEscaped(buf, value);
+		    buf.append('"');
		}
    }