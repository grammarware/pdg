+private void glomIRuleViolations(Writer writer, Iterator<IRuleViolation> violations) throws IOException {
        StringBuffer buf = new StringBuffer(500);
+        while (violations.hasNext()) {
            IRuleViolation rv = violations.next();
+            buf.setLength(0);
+            buf.append("<tr");
+            if (colorize) {
+                buf.append(" bgcolor=\"lightgrey\"");
            }
+            colorize = !colorize;
+            buf.append("> " + PMD.EOL);
+            buf.append("<td align=\"center\">" + violationCount + "</td>" + PMD.EOL);
+            buf.append("<td width=\"*%\">" + maybeWrap(rv.getFilename(),linePrefix==null?"":linePrefix + Integer.toString(rv.getBeginLine())) + "</td>" + PMD.EOL);
+            buf.append("<td align=\"center\" width=\"5%\">" + Integer.toString(rv.getBeginLine()) + "</td>" + PMD.EOL);

+            String d = StringUtil.htmlEncode(rv.getDescription());
            
+            if (rv.getRule().getExternalInfoUrl() != null && rv.getRule().getExternalInfoUrl().length() != 0) {
+                d = "<a href=\"" + rv.getRule().getExternalInfoUrl() + "\">" + d + "</a>";
            }
+            buf.append("<td width=\"*\">" + d + "</td>" + PMD.EOL);
+            buf.append("</tr>" + PMD.EOL);
+            writer.write(buf.toString());
+            violationCount++;
        }
    }
private String maybeWrap(String filename, String line) {
+        if (linkPrefix == null) {
+            return filename;
        }
+        String newFileName = filename.substring(0, filename.lastIndexOf('.')).replace('\\', '/');
+        return "<a href=\"" + linkPrefix + newFileName + ".html#" + line + "\">" + newFileName + "</a>";
    }
+public void renderFileViolations(Iterator<IRuleViolation> violations) throws IOException {
+        Writer writer = getWriter();
+        glomIRuleViolations(writer, violations);
    }