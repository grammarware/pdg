+private void transform(Document doc) {
+	DOMSource source = new DOMSource(doc);
+	this.setWriter(new StringWriter());
+	StreamResult result = new StreamResult(this.outputWriter);
+	try {
+	    transformer.transform(source, result);
+	} catch (TransformerException e) {
+	    e.printStackTrace();
	}
    }
/**
     * {@inheritDoc}
     */
    @Override
    public void end() throws IOException {
	// First we finish the XML report
+	super.end();
+	// Now we transform it using XSLT
+	Writer writer = super.getWriter();
+	if (writer instanceof StringWriter) {
+	    StringWriter w = (StringWriter) writer;
+	    StringBuffer buffer = w.getBuffer();
+	    Document doc = this.getDocument(buffer.toString());
+	    this.transform(doc);
	} else {
	    // Should not happen !
	    throw new RuntimeException("Wrong writer");
	}

    }
+private Document getDocument(String xml) {
+	try {
+	    DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
+	    return parser.parse(new InputSource(new StringReader(xml)));
+	} catch (ParserConfigurationException e) {
+	    e.printStackTrace();
+	} catch (SAXException e) {
+	    e.printStackTrace();
+	} catch (IOException e) {
+	    e.printStackTrace();
	}
+	return null;
    }