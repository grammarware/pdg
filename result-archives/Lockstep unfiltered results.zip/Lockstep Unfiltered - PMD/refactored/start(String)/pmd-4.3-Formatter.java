private Renderer fromClassname(String rendererClassname) {
        try {
+            return (Renderer) Class.forName(rendererClassname).newInstance();
        } catch (Exception e) {
            throw new BuildException(unknownRendererMessage(rendererClassname));
        }
    }
+// FIXME - hm, what about this consoleRenderer thing... need a test for this
    private Renderer getRenderer(boolean consoleRenderer) {
+        if ("".equals(type)) {
+            throw new BuildException(unknownRendererMessage("<unspecified>"));
        }
        RendererBuilder builder = renderersByCode.get(type);
+        Renderer renderer = builder == null ? fromClassname(type) : builder.build(new String[]{linkPrefix, linePrefix});
        renderer.showSuppressedViolations(showSuppressed);
+        return renderer;
    }
+private Writer getToFileWriter(String baseDir) throws IOException {
+        if (!toFile.isAbsolute()) {
+            return new BufferedWriter(new FileWriter(new File(baseDir + System.getProperty("file.separator") + toFile.getPath())));
        }
+        return new BufferedWriter(new FileWriter(toFile));
    }
public void start(String baseDir) {
+        try {
+            if (toConsole) {
+                writer = new BufferedWriter(new OutputStreamWriter(System.out));
            }
+            if (toFile != null) {
+                writer = getToFileWriter(baseDir);
            }
+            renderer = getRenderer(toConsole);
+            renderer.setWriter(writer);
+            renderer.start();
+        } catch (IOException ioe) {
+            throw new BuildException(ioe.getMessage());
        }
    }