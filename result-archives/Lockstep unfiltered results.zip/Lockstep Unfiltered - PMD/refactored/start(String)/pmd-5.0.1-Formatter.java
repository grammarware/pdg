private Properties createProperties() {
	Properties properties = new Properties();
	for (Parameter parameter : parameters) {
	    properties.put(parameter.getName(), parameter.getValue());
	}
+	return properties;
    }
+private Writer getToFileWriter(String baseDir) throws IOException {
+        if (!toFile.isAbsolute()) {
+            return new BufferedWriter(new FileWriter(new File(baseDir + System.getProperty("file.separator") + toFile.getPath())));
        }
+        return new BufferedWriter(new FileWriter(toFile));
    }
public void start(String baseDir) {
+        try {
+            if (toConsole) {
+                writer = new BufferedWriter(new OutputStreamWriter(System.out));
            }
+            if (toFile != null) {
+                writer = getToFileWriter(baseDir);
            }
+            renderer = createRenderer();
+            renderer.setWriter(writer);
+            renderer.start();
+        } catch (IOException ioe) {
+            throw new BuildException(ioe.getMessage(), ioe);
        }
    }
+// FIXME - hm, what about this consoleRenderer thing... need a test for this
    private Renderer createRenderer() {
+        if (StringUtil.isEmpty(type)) {
+            throw new BuildException(unknownRendererMessage("<unspecified>"));
        }

+        Properties properties = createProperties();
+        Renderer renderer = RendererFactory.createRenderer(type, properties);
        renderer.setShowSuppressedViolations(showSuppressed);
+        return renderer;
    }