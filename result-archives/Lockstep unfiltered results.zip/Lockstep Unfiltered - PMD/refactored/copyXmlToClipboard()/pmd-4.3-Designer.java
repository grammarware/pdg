private SimpleNode getCompilationUnit() {
+    	SourceTypeHandler handler = SourceTypeHandlerBroker.getVisitorsFactoryForSourceType(getSourceType());
+    	Parser parser = handler.getParser();
    	parser.setExcludeMarker(PMD.EXCLUDE_MARKER);
    	SimpleNode simpleNode = (SimpleNode)parser.parse(new StringReader(codeEditorPane.getText()));
+    	handler.getSymbolFacade().start(simpleNode);
+    	handler.getTypeResolutionFacade(null).start(simpleNode);
+    	return simpleNode;
    }
private final void copyXmlToClipboard() {
+        if (codeEditorPane.getText() != null && codeEditorPane.getText().trim().length() > 0) {
+            String xml = "";
+            SimpleNode cu = getCompilationUnit();
+            if (cu != null) {
+                try {
+                    xml = getXmlString(cu);
+                } catch (TransformerException e) {
+                    e.printStackTrace();
+                    xml = "Error trying to construct XML representation";
                }
            }
+            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(xml), this);
        }
    }
private SourceType getSourceType() {

+    	return (SourceType)sourceTypeSets[selectedSourceTypeIndex()][1];
    }
private int selectedSourceTypeIndex() {
+    	for (int i=0; i<sourceTypeMenuItems.length; i++) {
+    		if (sourceTypeMenuItems[i].isSelected()) return i;
    	}
+    	throw new RuntimeException("Initial default source type not specified");
    }
+/**
     * Returns an unformatted xml string (without the declaration)
     *
     * @throws TransformerException if the XML cannot be converted to a string
     */
    private String getXmlString(SimpleNode node) throws TransformerException {
+        StringWriter writer = new StringWriter();

+        Source source = new DOMSource(node.asXml());
+        Result result = new StreamResult(writer);
+        TransformerFactory transformerFactory = TransformerFactory.newInstance();
+        try {
+            transformerFactory.setAttribute("indent-number", 4);   //For java 5
        } catch (IllegalArgumentException e) {
            //Running on Java 1.4 which does not support this attribute
        }
+        Transformer xformer = transformerFactory.newTransformer();
+        xformer.setOutputProperty(OutputKeys.INDENT, "yes");
+        xformer.setOutputProperty("{http://xml.apache.org/xalan}indent-amount", "4");   //For java 1.4
+        xformer.transform(source, result);

+        return writer.toString();
    }