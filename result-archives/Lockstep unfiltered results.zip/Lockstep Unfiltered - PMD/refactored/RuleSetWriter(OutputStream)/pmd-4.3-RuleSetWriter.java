+public RuleSetWriter(OutputStream outputStream) {
+		this(outputStream, true);
	}
+public RuleSetWriter(OutputStream outputStream, boolean outputNamespace) {
+		this.outputStream = outputStream;
		this.outputNamespace = outputNamespace;
	}