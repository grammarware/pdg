private void createTimestampAttr(StringBuffer buffer) {
+        buffer.append(" timestamp=\"").append(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(new Date())).append('"');
    }
private void createVersionAttr(StringBuffer buffer) {
+        buffer.append("<pmd version=\"").append(PMD.VERSION).append('"');
    }
public void start() throws IOException {
+        Writer writer = getWriter();
        StringBuffer buf = new StringBuffer();
+        buf.append("<?xml version=\"1.0\" encoding=\"" + this.encoding + "\"?>").append(PMD.EOL);
+        createVersionAttr(buf);
+        createTimestampAttr(buf);
        // FIXME: elapsed time not available until the end of the processing
        //buf.append(createTimeElapsedAttr(report));
+        buf.append('>').append(PMD.EOL);
+        writer.write(buf.toString());
    }