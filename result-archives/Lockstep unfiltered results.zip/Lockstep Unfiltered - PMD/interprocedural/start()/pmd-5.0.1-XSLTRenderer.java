/**
     * Prepare the transformer, doing the proper "building"...
     *
     * @param xslt The stylesheet provided as an InputStream
     */
+    private void prepareTransformer(InputStream xslt) {
+	if (xslt != null) {
+	    try {
+		//Get a TransformerFactory object
+		TransformerFactory factory = TransformerFactory.newInstance();
+		StreamSource src = new StreamSource(xslt);
+		//Get an XSL Transformer object
+		this.transformer = factory.newTransformer(src);
+	    } catch (TransformerConfigurationException e) {
+		e.printStackTrace();
	    }
	}
    }
/**
     * {@inheritDoc}
     */
    @Override
    public void start() throws IOException {
	String xsltFilename = getProperty(XSLT_FILENAME);
+	if (xsltFilename != null) {
+	    File file = new File(xsltFilename);
+	    if (file.exists() && file.canRead()) {
+		this.xsltFilename = xsltFilename;
	    }
	}

+	// We keep the inital writer to put the final html output
+	this.outputWriter = getWriter();
+	// We use a new one to store the XML...
	Writer w = new StringWriter();
+	setWriter(w);
+	// If don't find the xsl no need to bother doing the all report,
	// so we check this here...
	InputStream xslt = null;
+	File file = new File(this.xsltFilename);
+	if (file.exists() && file.canRead()) {
+	    xslt = new FileInputStream(file);
	} else {
+	    xslt = this.getClass().getResourceAsStream(xsltFilename);
	}
+	if (xslt == null) {
+	    throw new FileNotFoundException("Can't file XSLT sheet :" + xsltFilename);
	}
+	this.prepareTransformer(xslt);
	// Now we build the XML file
+	super.start();
    }