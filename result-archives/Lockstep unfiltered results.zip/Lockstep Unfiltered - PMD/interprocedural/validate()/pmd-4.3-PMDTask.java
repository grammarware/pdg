private String getNestedRuleSetFiles() {
        final StringBuffer sb = new StringBuffer();
+        for (Iterator<RuleSetWrapper> it = nestedRules.iterator(); it.hasNext();) {
+            RuleSetWrapper rs = it.next();
+            sb.append(rs.getFile());
+            if (it.hasNext()) {
+                sb.append(',');
            }
        }
+        return sb.toString();
    }
private void validate() throws BuildException {
+        // TODO - check for empty Formatters List here?
        for (Formatter f: formatters) {
+            if (f.isNoOutputSupplied()) {
+                throw new BuildException("toFile or toConsole needs to be specified in Formatter");
            }
        }

+        if (ruleSetFiles == null) {
+            if (nestedRules.isEmpty()) {
+                throw new BuildException("No rulesets specified");
            }
+            ruleSetFiles = getNestedRuleSetFiles();
        }

+        if (!targetJDK.equals("1.3") && !targetJDK.equals("1.4") && !targetJDK.equals("1.5") && !targetJDK.equals("1.6") && !targetJDK.equals("1.7") && !targetJDK.equals("jsp")) {
+            throw new BuildException("The targetjdk attribute, if used, must be set to either '1.3', '1.4', '1.5', '1.6', '1.7' or 'jsp'");
        }
    }