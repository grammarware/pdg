private String getNestedRuleSetFiles() {
		final StringBuilder sb = new StringBuilder();
+		for (Iterator<RuleSetWrapper> it = nestedRules.iterator(); it.hasNext();) {
+			RuleSetWrapper rs = it.next();
+			sb.append(rs.getFile());
+			if (it.hasNext()) {
+				sb.append(',');
			}
		}
+		return sb.toString();
	}
private void validate() throws BuildException {
+		if (formatters.isEmpty()) {
			Formatter defaultFormatter = new Formatter();
			defaultFormatter.setType("text");
			defaultFormatter.setToConsole(true);
			formatters.add(defaultFormatter);
		} else {
+			for (Formatter f : formatters) {
+				if (f.isNoOutputSupplied()) {
+					throw new BuildException("toFile or toConsole needs to be specified in Formatter");
				}
			}
		}

+		if (configuration.getRuleSets() == null) {
+			if (nestedRules.isEmpty()) {
+				throw new BuildException("No rulesets specified");
			}
+			configuration.setRuleSets(getNestedRuleSetFiles());
		}
	}