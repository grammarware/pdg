public Object visit(MethodNode methodNode, Object data) {
+		if (methodNode.getUsers().isEmpty()) {
+			boolean log = true;
+			if (options.isIgnoreMethodAllOverride()) {
+				if (ClassLoaderUtil.isOverridenMethod(methodNode.getClassNode().getClass(), methodNode.getMember(),
						false)) {
+					ignore("method all override", methodNode);
+					log = false;
				}
+			} else if (options.isIgnoreMethodJavaLangObjectOverride()) {
+				if (ClassLoaderUtil.isOverridenMethod(java.lang.Object.class, methodNode.getMember(), true)) {
					ignore("method java.lang.Object override", methodNode);
+					log = false;
				}
			}
+			if (options.isIgnoreMethodMain()) {
+				if (isMainMethod(methodNode)) {
					ignore("method public static void main(String[])", methodNode);
+					log = false;
				}
			}
+			if (log) {
+				System.out.println("\t" + methodNode.toStringLong());
			}
		}
+		return super.visit(methodNode, data);
	}
private void ignore(String description, MemberNode memberNode) {
+		System.out.println("Ignoring " + description + ": " + memberNode.toStringLong());
	}