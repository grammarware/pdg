public static String prePaddedOctalString(long val, int width) {
+            return StringUtil.toPaddedString(Long.toOctalString(val), width,
                                             '0', false);
        }
protected void writeField(TarHeaderField field, long newValue)
                throws TarMalformatException {
+            TarEntrySupplicant.writeField(field, newValue, rawHeader);
        }
/*
         * Internal constructor that validates the entry's path.
         */
+        protected TarEntrySupplicant(String path, char typeFlag,
+                                     TarFileOutputStream tarStream)
                                     throws TarMalformatException {

+            if (path == null) {
+                throw new IllegalArgumentException(
                    RB.missing_supp_path.getString());
            }

+            this.path = (swapOutDelim == null) ? path
                                               : path.replace(
                                                   swapOutDelim.charValue(),
                                                   '/');
+            this.tarStream = tarStream;

+            writeField(TarHeaderField.typeflag, typeFlag);

+            if (typeFlag == '\0' || typeFlag == ' ') {
+                writeField(TarHeaderField.uname,
                           System.getProperty("user.name"), HEADER_TEMPLATE);
+                writeField(TarHeaderField.gname, "root", HEADER_TEMPLATE);

                // Setting UNAME and GNAME at the instance level instead of the
                // static template, because record types 'x' and 'g' do not set
                // these fields.
                // POSIX UStar compliance requires that we set "gname" field.
                // It's impossible for use to determine the correct value from
                // Java.  We punt with "root" because (a) it's the only group
                // name
                // we know should exist on every UNIX system, and (b) every tar
                // client gracefully handles it when extractor user does not
                // have privs for the specified group.
            }
        }
/**
         * After instantiating a TarEntrySupplicant, the user must either invoke
         * write() or close(), to release system resources on the input
         * File/Stream.
         */
+        public TarEntrySupplicant(String path, File file,
+                                  TarFileOutputStream tarStream)
                                  throws FileNotFoundException,
                                         TarMalformatException {

            // Must use an expression-embedded ternary here to satisfy compiler
            // that this() call be first statement in constructor.
+            this(((path == null) ? file.getPath()
+                                 : path), '0', tarStream);

+            // Difficult call for '0'.  binary 0 and character '0' both mean
            // regular file.  Binary 0 pre-UStar is probably more portable,
            // but we are writing a valid UStar header, and I doubt anybody's
            // tar implementation would choke on this since there is no
            // outcry of UStar archives failing to work with older tars.
            if (!file.isFile()) {
+                throw new IllegalArgumentException(
                        RB.nonfile_entry.getString());
            }

+            if (!file.canRead()) {
+                throw new IllegalArgumentException(
                    RB.read_denied.getString(file.getAbsolutePath()));
            }

+            modTime     = file.lastModified() / 1000L;
+            fileMode    = TarEntrySupplicant.getLameMode(file);
+            dataSize    = file.length();
            inputStream = new InputStreamWrapper(new FileInputStream(file));
        }
static protected void writeField(TarHeaderField field, long newValue,
+                                         byte[] target)
                                         throws TarMalformatException {

+            TarEntrySupplicant.writeField(
                field,
                TarEntrySupplicant.prePaddedOctalString(
+                    newValue, field.getStop() - field.getStart()), target);
        }
+/**
         * This method is so-named because it only sets the owner privileges,
         * not any "group" or "other" privileges.
         * <P>
         * This is because of Java limitation.
         * Incredibly, with Java 1.6, the API gives you the power to set
         * privileges for "other" (last nibble in file Mode), but no ability
         * to detect the same.
         * </P>
         */
+        static protected String getLameMode(File file) {

+            int umod = 0;

+//#ifdef JAVA6
+            if (file.canExecute()) {
+                umod = 1;
            }

+//#endif
+            if (file.canWrite()) {
+                umod += 2;
            }

+            if (file.canRead()) {
+                umod += 4;
            }

+            return "0" + umod + "00";

            // Conservative since Java gives us no way to determine group or
            // other privileges on a file, and this file may contain passwords.
        }
static protected void writeField(TarHeaderField field, String newValue,
+                                         byte[] target)
                                         throws TarMalformatException {

+            int    start = field.getStart();
+            int    stop  = field.getStop();
+            byte[] ba;

+            try {
+                ba = newValue.getBytes("ISO-8859-1");
+            } catch (UnsupportedEncodingException e) {
+                throw new RuntimeException(e);
            }

+            if (ba.length > stop - start) {
+                throw new TarMalformatException(
                    RB.tar_field_toobig.getString(field.toString(), newValue));
            }

+            for (int i = 0; i < ba.length; i++) {
+                target[start + i] = ba[i];
            }
        }