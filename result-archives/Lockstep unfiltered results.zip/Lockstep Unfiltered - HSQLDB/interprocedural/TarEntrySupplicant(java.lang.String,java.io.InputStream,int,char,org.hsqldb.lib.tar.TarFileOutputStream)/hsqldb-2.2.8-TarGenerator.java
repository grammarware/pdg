public void close() throws IOException {
+            if (inputStream == null) {
+                return;
            }

+            try {
                inputStream.close();
            } finally {
                inputStream = null;  // Encourage buffer GC
            }
        }
public static String prePaddedOctalString(long val, int width) {
+            return StringUtil.toPaddedString(Long.toOctalString(val), width,
                                             '0', false);
        }
/**
         * After instantiating a TarEntrySupplicant, the user must either invoke
         * write() or close(), to release system resources on the input
         * File/Stream.
         * <P>
         * <B>WARNING:</B>
         * Do not use this method unless the quantity of available RAM is
         * sufficient to accommodate the specified maxBytes all at one time.
         * This constructor loads all input from the specified InputStream into
         * RAM before anything is written to disk.
         * </P>
         *
         * @param maxBytes This method will fail if more than maxBytes bytes
         *                 are supplied on the specified InputStream.
         *                 As the type of this parameter enforces, the max
         *                 size you can request is 2GB.
         */
        public TarEntrySupplicant(String path, InputStream origStream,
                                  int maxBytes, char typeFlag,
+                                  TarFileOutputStream tarStream)
                                  throws IOException, TarMalformatException {

            /*
             * If you modify this, make sure to not intermix reading/writing of
             * the PipedInputStream and the PipedOutputStream, or you could
             * cause dead-lock.  Everything is safe if you close the
             * PipedOutputStream before reading the PipedInputStream.
             */
+            this(path, typeFlag, tarStream);

+            if (maxBytes < 1) {
+                throw new IllegalArgumentException(RB.read_lt_1.getString());
            }

+            int               i;
+            PipedOutputStream outPipe = new PipedOutputStream();

+            /* This constructor not available until Java 1.6:
            inputStream = new PipedInputStream(outPipe, maxBytes);
            */
            try {
                inputStream = new InputStreamWrapper(new PipedInputStream(outPipe));
                while ((i =
                        origStream
                            .read(tarStream.writeBuffer, 0, tarStream
                                .writeBuffer.length)) > 0) {
+                    outPipe.write(tarStream.writeBuffer, 0, i);
                }

+                outPipe.flush();    // Do any good on a pipe?

                dataSize = inputStream.available();

                if (TarFileOutputStream.debug) {
                    System.out.println(
                        RB.stream_buffer_report.getString(
                                Long.toString(dataSize)));
                }
+            } catch (IOException ioe) {
                close();

+                throw ioe;
            } finally {
                try {
+                    outPipe.close();
                } finally {
                    outPipe = null;  // Encourage buffer GC
                }
            }

            modTime = new java.util.Date().getTime() / 1000L;
        }
protected void writeField(TarHeaderField field, long newValue)
                throws TarMalformatException {
+            TarEntrySupplicant.writeField(field, newValue, rawHeader);
        }
/*
         * Internal constructor that validates the entry's path.
         */
        protected TarEntrySupplicant(String path, char typeFlag,
+                                     TarFileOutputStream tarStream)
                                     throws TarMalformatException {

+            if (path == null) {
+                throw new IllegalArgumentException(
                    RB.missing_supp_path.getString());
            }

+            this.path = (swapOutDelim == null) ? path
                                               : path.replace(
                                                   swapOutDelim.charValue(),
                                                   '/');
+            this.tarStream = tarStream;

+            writeField(TarHeaderField.typeflag, typeFlag);

+            if (typeFlag == '\0' || typeFlag == ' ') {
+                writeField(TarHeaderField.uname,
                           System.getProperty("user.name"), HEADER_TEMPLATE);
+                writeField(TarHeaderField.gname, "root", HEADER_TEMPLATE);

                // Setting UNAME and GNAME at the instance level instead of the
                // static template, because record types 'x' and 'g' do not set
                // these fields.
                // POSIX UStar compliance requires that we set "gname" field.
                // It's impossible for use to determine the correct value from
                // Java.  We punt with "root" because (a) it's the only group
                // name
                // we know should exist on every UNIX system, and (b) every tar
                // client gracefully handles it when extractor user does not
                // have privs for the specified group.
            }
        }
static protected void writeField(TarHeaderField field, long newValue,
+                                         byte[] target)
                                         throws TarMalformatException {

+            TarEntrySupplicant.writeField(
                field,
                TarEntrySupplicant.prePaddedOctalString(
+                    newValue, field.getStop() - field.getStart()), target);
        }
static protected void writeField(TarHeaderField field, String newValue,
+                                         byte[] target)
                                         throws TarMalformatException {

+            int    start = field.getStart();
+            int    stop  = field.getStop();
+            byte[] ba;

+            try {
+                ba = newValue.getBytes("ISO-8859-1");
+            } catch (UnsupportedEncodingException e) {
+                throw new RuntimeException(e);
            }

+            if (ba.length > stop - start) {
+                throw new TarMalformatException(
                    RB.tar_field_toobig.getString(field.toString(), newValue));
            }

+            for (int i = 0; i < ba.length; i++) {
+                target[start + i] = ba[i];
            }
        }