+void setClobParameter(int i, Object o,
+                          long streamLength) throws SQLException {

+        if (o instanceof JDBCClobClient) {
+            JDBCClobClient clob = (JDBCClobClient) o;

+            if (!clob.session.getDatabaseUniqueName().equals(
                    session.getDatabaseUniqueName())) {
+                streamLength = clob.length();

+                Reader is = clob.getCharacterStream();

+                parameterValues[i - 1] = is;
+                streamLengths[i - 1]   = streamLength;
+                parameterSet[i - 1]    = Boolean.FALSE;

+                return;
            }
+            parameterValues[i - 1] = o;
+            parameterSet[i - 1]    = Boolean.TRUE;

+            return;
+        } else if (o instanceof Clob) {
+            parameterValues[i - 1] = o;
+            parameterSet[i - 1]    = Boolean.TRUE;

+            return;
+        } else if (o instanceof ClobInputStream) {
+            ClobInputStream is = (ClobInputStream) o;

+            if (is.session.getDatabaseUniqueName().equals(
                    session.getDatabaseUniqueName())) {
+                throw Util.sqlException(ErrorCode.JDBC_INVALID_ARGUMENT,
                                        "invalid Reader");
            }
+            parameterValues[i - 1] = o;
+            streamLengths[i - 1]   = streamLength;
+            parameterSet[i - 1]    = Boolean.FALSE;

+            return;
+        } else if (o instanceof Reader) {
+            parameterValues[i - 1] = o;
+            streamLengths[i - 1]   = streamLength;
+            parameterSet[i - 1]    = Boolean.FALSE;

+            return;
+        } else if (o instanceof String) {
+            JDBCClob clob = new JDBCClob((String) o);

+            parameterValues[i - 1] = clob;
+            parameterSet[i - 1]    = false;

+            return;
        }

+        throw Util.invalidArgument();
    }
+void setBlobParameter(int i, Object o,
+                          long streamLength) throws SQLException {

+        if (o instanceof JDBCBlobClient) {
+            JDBCBlobClient blob = (JDBCBlobClient) o;

+            if (!blob.session.getDatabaseUniqueName().equals(
                    session.getDatabaseUniqueName())) {
+                streamLength = blob.length();

+                InputStream is = blob.getBinaryStream();

+                parameterValues[i - 1] = is;
+                streamLengths[i - 1]   = streamLength;
+                parameterSet[i - 1]    = Boolean.FALSE;

+                return;
            }

+            // in the same database
            parameterValues[i - 1] = o;
+            parameterSet[i - 1]    = Boolean.TRUE;

+            return;
+        } else if (o instanceof Blob) {
+            parameterValues[i - 1] = o;
+            parameterSet[i - 1]    = Boolean.FALSE;

+            return;
+        } else if (o instanceof BlobInputStream) {
+            BlobInputStream is = (BlobInputStream) o;

+            if (is.session.getDatabaseUniqueName().equals(
                    session.getDatabaseUniqueName())) {
+                throw Util.sqlException(ErrorCode.JDBC_INVALID_ARGUMENT,
                                        "invalid Reader");
            }

+            // in the same database ? see if it blocks in
            parameterValues[i - 1] = o;
+            streamLengths[i - 1]   = streamLength;
+            parameterSet[i - 1]    = Boolean.FALSE;

+            return;
+        } else if (o instanceof InputStream) {
+            parameterValues[i - 1] = o;
+            streamLengths[i - 1]   = streamLength;
+            parameterSet[i - 1]    = Boolean.FALSE;

+            return;
+        } else if (o instanceof byte[]) {
+            JDBCBlob blob = new JDBCBlob((byte[]) o);

+            parameterValues[i - 1] = blob;
+            parameterSet[i - 1]    = Boolean.TRUE;

+            return;
        }

+        throw Util.invalidArgument();
    }
/**
     * <!-- start generic documentation -->
     * Sets the designated parameter to the given <code>java.sql.Array</code> object.
     * The driver converts this to an SQL <code>ARRAY</code> value when it
     * sends it to the database.
     * <!-- end generic documentation -->
     *
     * <!-- start release-specific documentation -->
     * <div class="ReleaseSpecificDocumentation">
     * <h3>HSQLDB-Specific Information:</h3> <p>
     *
     * From version 2.0, HSQLDB supports the SQL ARRAY type.
     *
     * </div>
     * <!-- end release-specific documentation -->
     *
     * @param parameterIndex the first parameter is 1, the second is 2, ...
     * @param x an <code>Array</code> object that maps an SQL <code>ARRAY</code> value
     * @exception SQLException if a database access error occurs or
     * this method is called on a closed <code>PreparedStatement</code>
     * @throws SQLFeatureNotSupportedException  if the JDBC driver does not support this method
     * @since JDK 1.2 (JDK 1.1.x developers: read the overview for
     *   JDBCParameterMetaData)
     */
+    public synchronized void setArray(int parameterIndex,
+                                      Array x) throws SQLException {

+        checkParameterIndex(parameterIndex);

+        Type type = this.parameterMetaData.columnTypes[parameterIndex - 1];

+        if (!type.isArrayType()) {
+            throw Util.sqlException(ErrorCode.X_42561);
        }

+        if (x == null) {
+            setParameter(parameterIndex, null);

+            return;
        }

+        Object[] data = null;

+        if (x instanceof JDBCArray) {
+            data = (Object[]) ((JDBCArray) x).getArrayInternal();
        } else {
+            Object object = x.getArray();

+            if (object instanceof Object[]) {
+                Type     baseType = type.collectionBaseType();
+                Object[] array    = (Object[]) object;

+                data = new Object[array.length];

+                for (int i = 0; i < data.length; i++) {
+                    data[i] = baseType.convertJavaToSQL(session, array[i]);
                }
            } else {

+                // if foreign data is not Object[]
                throw Util.notSupported();
            }
        }
+        parameterValues[parameterIndex - 1] = data;
+        parameterSet[parameterIndex - 1]    = Boolean.TRUE;

+        return;
    }
+private void setBinStream(int parameterIndex, java.io.InputStream x,
+                              long length) throws SQLException {

        if (isClosed || connection.isClosed) {
            checkClosed();
        }

+        if (parameterTypes[parameterIndex - 1].typeCode == Types.SQL_BLOB) {
+            setBlobParameter(parameterIndex, x, length);

+            return;
        }

+        if (length > Integer.MAX_VALUE) {
+            String msg = "Maximum Blob input length exceeded: " + length;

+            throw Util.sqlException(ErrorCode.JDBC_INPUTSTREAM_ERROR, msg);
        }

+        try {
+            HsqlByteArrayOutputStream output;

+            if (length < 0) {
+                output = new HsqlByteArrayOutputStream(x);
            } else {
+                output = new HsqlByteArrayOutputStream(x, (int) length);
            }
+            setParameter(parameterIndex, output.toByteArray());
+        } catch (Throwable e) {
+            throw Util.sqlException(ErrorCode.JDBC_INPUTSTREAM_ERROR,
                                    e.toString(), e);
        }
    }
+protected void checkParameterIndex(int i) throws SQLException {

+        if (isClosed || connection.isClosed) {
+            checkClosed();
        }

+        if (i < 1 || i > parameterValues.length) {
+            String msg = "parameter index out of range: " + i;

+            throw Util.outOfRangeArgument(msg);
        }
    }
/**
     * The internal parameter value setter always converts the parameter to
     * the Java type required for data transmission.
     *
     * @param i parameter index
     * @param o object
     * @throws SQLException if either argument is not acceptable.
     */
+    void setParameter(int i, Object o) throws SQLException {

+        checkSetParameterIndex(i);

+        i--;

+        if (o == null) {
+            parameterValues[i] = null;
+            parameterSet[i]    = Boolean.TRUE;

+            return;
        }

+        Type outType = parameterTypes[i];

+        switch (outType.typeCode) {

+            case Types.OTHER :
+                try {
+                    if (o instanceof Serializable) {
+                        o = new JavaObjectData((Serializable) o);

                        break;
                    }
                } catch (HsqlException e) {
                    Util.throwError(e);
                }
                Util.throwError(Error.error(ErrorCode.X_42563));
            case Types.SQL_BIT :
            case Types.SQL_BIT_VARYING :
                try {
                    if (o instanceof Boolean) {
+                        o = outType.convertToDefaultType(session, o);

                        break;
                    }

                    if (o instanceof Integer) {
+                        o = outType.convertToDefaultType(session, o);

                        break;
                    }

                    if (o instanceof byte[]) {
+                        o = outType.convertToDefaultType(session, o);

                        break;
                    }

                    if (o instanceof String) {
+                        o = outType.convertToDefaultType(session, o);

                        break;
                    }
                } catch (HsqlException e) {
                    Util.throwError(e);
                }
                Util.throwError(Error.error(ErrorCode.X_42563));

            // fall through
            case Types.SQL_BINARY :
            case Types.SQL_VARBINARY :
                if (o instanceof byte[]) {
+                    o = new BinaryData((byte[]) o, !connection.isNetConn);

                    break;
                }

                try {
                    if (o instanceof String) {
+                        o = outType.convertToDefaultType(session, o);

                        break;
                    }
                } catch (HsqlException e) {
                    Util.throwError(e);
                }
                Util.throwError(Error.error(ErrorCode.X_42563));

                break;
+            case Types.SQL_ARRAY :
+                if (o instanceof Array) {
+                    setArray(i + 1, (Array) o);

+                    return;
                }

+                if (o instanceof ArrayList) {
+                    o = ((ArrayList) o).toArray();
                }

+                if (o instanceof Object[]) {
+                    Type     baseType = outType.collectionBaseType();
+                    Object[] array    = (Object[]) o;
+                    Object[] data     = new Object[array.length];

+                    for (int j = 0; j < data.length; j++) {
+                        data[j] = baseType.convertJavaToSQL(session, array[j]);
                    }
+                    o = data;

+                    break;
                }
+                Util.throwError(Error.error(ErrorCode.X_42563));
+            case Types.SQL_BLOB :
+                setBlobParameter(i + 1, o);

+                return;
+            case Types.SQL_CLOB :
+                setClobParameter(i + 1, o);

+                return;
+            case Types.SQL_DATE :
+            case Types.SQL_TIME_WITH_TIME_ZONE :
+            case Types.SQL_TIMESTAMP_WITH_TIME_ZONE :
+            case Types.SQL_TIME :
+            case Types.SQL_TIMESTAMP : {
+                try {
+                    if (o instanceof String) {
+                        o = outType.convertToType(session, o,
                                Type.SQL_VARCHAR);

                        break;
                    }
+                    o = outType.convertJavaToSQL(session, o);

                    break;
                } catch (HsqlException e) {
                    Util.throwError(e);
                }
            }
            case Types.TINYINT :
            case Types.SQL_SMALLINT :
            case Types.SQL_INTEGER :
            case Types.SQL_BIGINT :
            case Types.SQL_REAL :
            case Types.SQL_FLOAT :
            case Types.SQL_DOUBLE :
            case Types.SQL_NUMERIC :
            case Types.SQL_DECIMAL :
                try {
                    if (o instanceof String) {
+                        o = outType.convertToType(session, o,
                                Type.SQL_VARCHAR);

                        break;
                    } else if (o instanceof Boolean) {
+                        boolean value = ((Boolean) o).booleanValue();

+                        o = value ? Integer.valueOf(1)
                                  : Integer.valueOf(0);
                    }
+                    o = outType.convertToDefaultType(session, o);

                    break;
                } catch (HsqlException e) {
                    Util.throwError(e);
                }
            case Types.SQL_VARCHAR : {
                if (o instanceof String) {
                    break;
                } else {
+                    o = outType.convertToDefaultType(session, o);

                    break;
                }
            }
+            case Types.SQL_CHAR :
+                if (outType.precision == 1) {
+                    if (o instanceof Character) {
+                        o = new String(new char[] {
                            ((Character) o).charValue() });

+                        break;
+                    } else if (o instanceof Boolean) {
+                        o = ((Boolean) o).booleanValue() ? "1"
                                : "0";

+                        break;
                    }
                }

+            // fall through
            default :
+                try {
+                    o = outType.convertToDefaultType(session, o);

                    break;
                } catch (HsqlException e) {
                    Util.throwError(e);
                }
        }
+        parameterValues[i] = o;
+        parameterSet[i]    = Boolean.TRUE;
    }
/**
     * setParameterForBlob
     *
     * @param i int
     * @param o Object
     */
+    void setBlobParameter(int i, Object o) throws SQLException {
+        setBlobParameter(i, o, 0);
    }
/**
     * setParameterForClob
     *
     * @param i int
     * @param o Object
     * @throws SQLException
     */
+    void setClobParameter(int i, Object o) throws SQLException {
+        setClobParameter(i, o, 0);
    }
/**
     * Checks if the specified parameter index value is valid in terms of
     * setting an IN or IN OUT parameter value. <p>
     *
     * @param i The parameter index to check
     * @throws SQLException if the specified parameter index is invalid
     */
+    protected void checkSetParameterIndex(int i) throws SQLException {

+        if (isClosed || connection.isClosed) {
+            checkClosed();
        }

+        if (i < 1 || i > parameterValues.length) {
+            String msg = "parameter index out of range: " + i;

+            throw Util.outOfRangeArgument(msg);
        }

+        if (parameterModes[i - 1] == SchemaObject.ParameterModes.PARAM_OUT) {
+            String msg = "Not IN or INOUT mode for parameter: " + i;

+            throw Util.invalidArgument(msg);
        }
    }