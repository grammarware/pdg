/**
     *  Checkpoints the database. <p>
     *
     *  The most important effect of calling this method is to cause the
     *  log file to be rewritten in the most efficient form to
     *  reflect the current state of the database, i.e. only the DDL and
     *  insert DML required to recreate the database in its present state.
     *  Other house-keeping duties are performed w.r.t. other database
     *  files, in order to ensure as much as possible the ACID properites
     *  of the database.
     *
     * @throws  HsqlException if there is a problem checkpointing the
     *      database
     */
    public synchronized void checkpoint(boolean mode) {

+        if (logsStatements) {
+            database.logger.logInfoEvent("Checkpoint start");
+            log.checkpoint(mode);
+            database.sessionManager.resetLoggedSchemas();
+            database.logger.logInfoEvent("Checkpoint end");
+        } else if (!isFileDatabase()) {
+            if (!database.txManager.isMVCC()) {
+                database.lobManager.deleteUnusedLobs();
            }
        }

+        checkpointRequired = false;
+        checkpointDue      = false;
    }
/**
     * All usage of FrameworkLogger should call this method before using an
     * instance.
     *
     * It ensures and requires that no logging should take place before a new
     * database unique name has been created for a new database or read from the
     * .script file for an old database.<p>
     *
     * An instance is returned when:
     * - database unique name has been created
     * - FrameworkLogger would use log4j
     *
     * Otherwise null is returned.
     *
     * This tactic avoids usage of file-based jdk logging for the time being.
     *
     */
    private void getEventLogger() {

+        if (fwLogger != null) {
+            return;
        }

+        String name = database.getUniqueName();

+        if (name == null) {

+            // The database unique name is set up at different times
            // depending on upgraded / exiting / new databases.
            // Therefore FrameworkLogger is not used until the unique
            // name is known.
            return;
        }

+        fwLogger = FrameworkLogger.getLog(SimpleLog.logTypeNameEngine,
                                          "hsqldb.db."
                                          + database.getUniqueName());
        /*
        sqlLogger = FrameworkLogger.getLog(SimpleLog.logTypeNameEngine,
                                           "hsqldb.sql."
                                           + database.getUniqueName());
        */
    }
public boolean isFileDatabase() {
+        return propIsFileDatabase;
    }
public void logInfoEvent(String message) {

+        getEventLogger();

+        if (fwLogger != null) {
+            fwLogger.info(message);
        }

+        appLog.logContext(SimpleLog.LOG_NORMAL, message);
    }