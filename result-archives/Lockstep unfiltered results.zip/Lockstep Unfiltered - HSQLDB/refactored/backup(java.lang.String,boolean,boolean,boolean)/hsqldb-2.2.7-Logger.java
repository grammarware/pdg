+public synchronized void backup(String destPath, boolean script,
+                                    boolean blocking, boolean compressed) {

+        String dbPath = database.getPath();

+        /* If want to add db Id also, will need to pass either Database
         * instead of dbPath, or pass dbPath + Id from CommandStatement.
         */
        if (runtimeFileDelim == null) {
+            runtimeFileDelim =
                new Character(System.getProperty("file.separator").charAt(0));
        }

+        String instanceName = new File(dbPath).getName();

+        if (destPath == null || destPath.length() < 1) {
+            throw Error.error(ErrorCode.X_2200F, "0-length destination path");
        }

+        char lastChar = destPath.charAt(destPath.length() - 1);
+        boolean generateName = (lastChar == '/'
                                || lastChar == runtimeFileDelim.charValue());
+        String defaultCompressionSuffix = compressed ? ".tar.gz"
                                                     : ".tar";
+        File archiveFile =
            generateName
            ? (new File(destPath.substring(0, destPath.length() - 1),
                        instanceName + '-'
                        + backupFileFormat.format(new java.util.Date())
                        + defaultCompressionSuffix))
            : (new File(destPath));
+        boolean nameImpliesCompress =
            archiveFile.getName().endsWith(".tar.gz")
            || archiveFile.getName().endsWith(".tgz");

+        if ((!nameImpliesCompress)
                && !archiveFile.getName().endsWith(".tar")) {
+            throw Error.error(null, ErrorCode.UNSUPPORTED_FILENAME_SUFFIX, 0,
                              new String[] {
                archiveFile.getName(), ".tar, .tar.gz, .tgz"
            });
        }

+        if (compressed != nameImpliesCompress) {
+            throw Error.error(null, ErrorCode.COMPRESSION_SUFFIX_MISMATCH, 0,
                              new Object[] {
                new Boolean(compressed), archiveFile.getName()
            });
        }

+        log.checkpointClose();

+        try {
+            database.logger.logInfoEvent("Initiating backup of instance '"
                                         + instanceName + "'");

            // By default, DbBackup will throw if archiveFile (or
            // corresponding work file) already exist.  That's just what we
            // want here.
            DbBackup backup = new DbBackup(archiveFile, dbPath);

            backup.setAbortUponModify(false);
            backup.write();
            database.logger.logInfoEvent("Successfully backed up instance '"
                                         + instanceName + "' to '" + destPath
                                         + "'");

            // RENAME tempPath to destPath
        } catch (IllegalArgumentException iae) {
            throw Error.error(ErrorCode.X_HV00A, iae.toString());
        } catch (IOException ioe) {
            throw Error.error(ErrorCode.FILE_IO_ERROR, ioe.toString());
        } catch (TarMalformatException tme) {
            throw Error.error(ErrorCode.FILE_IO_ERROR, tme.toString());
        } finally {
+            log.checkpointReopen();
        }
    }
/**
     * All usage of FrameworkLogger should call this method before using an
     * instance.
     *
     * It ensures and requires that no logging should take place before a new
     * database unique name has been created for a new database or read from the
     * .script file for an old database.<p>
     *
     * An instance is returned when:
     * - database unique name has been created
     * - FrameworkLogger would use log4j
     *
     * Otherwise null is returned.
     *
     * This tactic avoids usage of file-based jdk logging for the time being.
     *
     */
    private void getEventLogger() {

+        if (fwLogger != null) {
+            return;
        }

+        String name = database.getUniqueName();

+        if (name == null) {

+            // The database unique name is set up at different times
            // depending on upgraded / exiting / new databases.
            // Therefore FrameworkLogger is not used until the unique
            // name is known.
            return;
        }

+        fwLogger = FrameworkLogger.getLog(SimpleLog.logTypeNameEngine,
                                          "hsqldb.db."
                                          + database.getUniqueName());
        /*
        sqlLogger = FrameworkLogger.getLog(SimpleLog.logTypeNameEngine,
                                           "hsqldb.sql."
                                           + database.getUniqueName());
        */
    }
public void logInfoEvent(String message) {

+        getEventLogger();

+        if (fwLogger != null) {
+            fwLogger.info(message);
        }

+        appLog.logContext(SimpleLog.LOG_NORMAL, message);
    }