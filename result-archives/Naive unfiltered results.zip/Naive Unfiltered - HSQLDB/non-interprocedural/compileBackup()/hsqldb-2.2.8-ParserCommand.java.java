private Statement compileBackup() {

        String  path;
+        Boolean blockingMode = null;    // Defaults to blocking
+        Boolean scriptMode   = null;    // Defaults to non-script
+        Boolean compression  = null;    // Defaults to compressed

        read();
        readThis(Tokens.DATABASE);
        readThis(Tokens.TO);

        path = readQuotedString();
+        path = path.trim();

+        if (path.length() == 0) {
+            throw unexpectedToken(path);
        }

+        outerLoop:
        while (true) {
            switch (token.tokenType) {

                case Tokens.BLOCKING :
                    if (blockingMode != null) {
                        throw unexpectedToken();
                    }

                    blockingMode = Boolean.TRUE;

                    read();
                    break;

                case Tokens.SCRIPT :
                    if (scriptMode != null) {
                        throw unexpectedToken();
                    }

                    scriptMode = Boolean.TRUE;

                    read();
                    break;

                case Tokens.COMPRESSED :
                    if (compression != null) {
                        throw unexpectedToken();
                    }

                    compression = Boolean.TRUE;

                    read();
                    break;

                case Tokens.NOT :
                    read();

                    if (token.tokenType == Tokens.COMPRESSED) {
                        if (compression != null) {
                            throw unexpectedToken();
                        }

                        compression = Boolean.FALSE;

                        read();
                    } else if (token.tokenType == Tokens.BLOCKING) {
                        if (blockingMode != null) {
                            throw unexpectedToken();
                        }

                        blockingMode = Boolean.FALSE;

                        read();
                    } else {
                        throw unexpectedToken();
                    }
                    break;

                default :
                    break outerLoop;
            }
        }

+        if (scriptMode == null) {
+            scriptMode = Boolean.FALSE;
        }

+        if (blockingMode == null) {
+            blockingMode = Boolean.TRUE;
        }

+        if (compression == null) {
+            compression = Boolean.TRUE;
        }

+        if (scriptMode) {
+            if (!blockingMode) {
+                throw unexpectedToken(Tokens.T_NOT);
            }
        }

+        HsqlName[] names =
            blockingMode ? database.schemaManager.getCatalogAndBaseTableNames()
                         : HsqlName.emptyArray;
+        Object[] args = new Object[] {
            path, blockingMode, scriptMode, compression
        };
+        Statement cs = new StatementCommand(StatementTypes.DATABASE_BACKUP,
                                            args, null, names);

+        return cs;
    }