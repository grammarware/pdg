/**
         * After instantiating a TarEntrySupplicant, the user must either invoke
         * write() or close(), to release system resources on the input
         * File/Stream.
         */
        public TarEntrySupplicant(String path, File file,
                                  TarFileOutputStream tarStream)
                                  throws FileNotFoundException,
                                         TarMalformatException {

            // Must use an expression-embedded ternary here to satisfy compiler
            // that this() call be first statement in constructor.
            this(((path == null) ? file.getPath()
                                 : path), '0', tarStream);

+            // Difficult call for '0'.  binary 0 and character '0' both mean
            // regular file.  Binary 0 pre-UStar is probably more portable,
            // but we are writing a valid UStar header, and I doubt anybody's
            // tar implementation would choke on this since there is no
            // outcry of UStar archives failing to work with older tars.
            if (!file.isFile()) {
+                throw new IllegalArgumentException(
                        RB.nonfile_entry.getString());
            }

+            if (!file.canRead()) {
+                throw new IllegalArgumentException(
                    RB.read_denied.getString(file.getAbsolutePath()));
            }

+            modTime     = file.lastModified() / 1000L;
+            fileMode    = TarEntrySupplicant.getLameMode(file);
+            dataSize    = file.length();
+            inputStream = new InputStreamWrapper(new FileInputStream(file));
        }
+/**
         * This method is so-named because it only sets the owner privileges,
         * not any "group" or "other" privileges.
         * <P>
         * This is because of Java limitation.
         * Incredibly, with Java 1.6, the API gives you the power to set
         * privileges for "other" (last nibble in file Mode), but no ability
         * to detect the same.
         * </P>
         */
        static protected String getLameMode(File file) {

+            int umod = 0;

+//#ifdef JAVA6
            if (file.canExecute()) {
+                umod = 1;
            }

+//#endif
            if (file.canWrite()) {
+                umod += 2;
            }

+            if (file.canRead()) {
+                umod += 4;
            }

+            return "0" + umod + "00";

            // Conservative since Java gives us no way to determine group or
            // other privileges on a file, and this file may contain passwords.
        }