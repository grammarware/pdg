public void close() throws IOException {
+            if (inputStream == null) {
+                return;
            }

+            try {
+                inputStream.close();
            } finally {
+                inputStream = null;  // Encourage buffer GC
            }
        }
protected void writeField(TarHeaderField field, long newValue)
                throws TarMalformatException {
+            TarEntrySupplicant.writeField(field, newValue, rawHeader);
        }
protected long headerChecksum() {

+            long sum = 0;

+            for (int i = 0; i < rawHeader.length; i++) {
+                boolean isInRange =
                    (i >= TarHeaderField.checksum.getStart()
                     && i < TarHeaderField.checksum.getStop());

+                sum += isInRange ? 32
                                 : (255 & rawHeader[i]);

                // We ignore current contents of the checksum field so that
                // this method will continue to work right, even if we later
                // recycle the header or RE-calculate a header.
            }

            return sum;
        }
static protected void writeField(TarHeaderField field, long newValue,
+                                         byte[] target)
                                         throws TarMalformatException {

            TarEntrySupplicant.writeField(
                field,
                TarEntrySupplicant.prePaddedOctalString(
+                    newValue, field.getStop() - field.getStart()), target);
        }
protected void writeField(TarHeaderField field, String newValue)
                throws TarMalformatException {
+            TarEntrySupplicant.writeField(field, newValue, rawHeader);
        }
static protected void writeField(TarHeaderField field, String newValue,
+                                         byte[] target)
                                         throws TarMalformatException {

+            int    start = field.getStart();
            int    stop  = field.getStop();
            byte[] ba;

            try {
+                ba = newValue.getBytes("ISO-8859-1");
+            } catch (UnsupportedEncodingException e) {
+                throw new RuntimeException(e);
            }

+            if (ba.length > stop - start) {
+                throw new TarMalformatException(
                    RB.tar_field_toobig.getString(field.toString(), newValue));
            }

+            for (int i = 0; i < ba.length; i++) {
+                target[start + i] = ba[i];
            }
        }
/**
         * Writes entire entry to this object's tarStream.
         *
         * This method is guaranteed to close the supplicant's input stream.
         */
        public void write() throws IOException, TarMalformatException {

            int i;

            try {

                // normal file streams will return -1 as size limit
                // getSizeLimit() is called just before writing the entry
                long sizeLimit = inputStream.getSizeLimit();

+                // special stream with explicit zero limit is not written
                if (sizeLimit == 0) {
+                    return;
                }

                // special stream
                if (sizeLimit > 0) {
                    dataSize = sizeLimit;
                }

+                writeField(TarHeaderField.name, path);

                // TODO:  If path.length() > 99, then write a PIF entry with
                // the file path.
                // Don't waste time using the PREFIX header field.
+                writeField(TarHeaderField.mode, fileMode);

+                if (!paxSized) {
+                    writeField(TarHeaderField.size, dataSize);
                }

+                writeField(TarHeaderField.mtime, modTime);
+                writeField(
                    TarHeaderField.checksum,
                    TarEntrySupplicant.prePaddedOctalString(
                        headerChecksum(), 6) + "\0 ");

                // Silly, but that's what the base header spec calls for.
+                tarStream.writeBlock(rawHeader);

+                long dataStart = tarStream.getBytesWritten();
+                while ((i = inputStream.read(tarStream.writeBuffer)) > 0) {
+                    tarStream.write(i);
                }

+                if (dataStart + dataSize != tarStream.getBytesWritten()) {
+                    throw new IOException(
                            RB.data_changed.getString(Long.toString(dataSize),
                            Long.toString(
                            tarStream.getBytesWritten() - dataStart)));
                }

+                tarStream.padCurrentBlock();
            } finally {
+                close();
            }
        }