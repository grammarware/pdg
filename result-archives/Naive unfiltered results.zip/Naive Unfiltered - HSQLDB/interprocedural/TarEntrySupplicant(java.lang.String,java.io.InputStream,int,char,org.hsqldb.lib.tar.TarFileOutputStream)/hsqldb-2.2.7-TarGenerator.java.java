public void close() throws IOException {
+            if (inputStream == null) {
+                return;
            }

+            try {
+                inputStream.close();
            } finally {
+                inputStream = null;  // Encourage buffer GC
            }
        }
/**
         * After instantiating a TarEntrySupplicant, the user must either invoke
         * write() or close(), to release system resources on the input
         * File/Stream.
         * <P>
         * <B>WARNING:</B>
         * Do not use this method unless the quantity of available RAM is
         * sufficient to accommodate the specified maxBytes all at one time.
         * This constructor loads all input from the specified InputStream into
         * RAM before anything is written to disk.
         * </P>
         *
         * @param maxBytes This method will fail if more than maxBytes bytes
         *                 are supplied on the specified InputStream.
         *                 As the type of this parameter enforces, the max
         *                 size you can request is 2GB.
         */
        public TarEntrySupplicant(String path, InputStream origStream,
                                  int maxBytes, char typeFlag,
                                  TarFileOutputStream tarStream)
                                  throws IOException, TarMalformatException {

            /*
             * If you modify this, make sure to not intermix reading/writing of
             * the PipedInputStream and the PipedOutputStream, or you could
             * cause dead-lock.  Everything is safe if you close the
             * PipedOutputStream before reading the PipedInputStream.
             */
            this(path, typeFlag, tarStream);

+            if (maxBytes < 1) {
+                throw new IllegalArgumentException(RB.read_lt_1.getString());
            }

+            int               i;
+            PipedOutputStream outPipe = new PipedOutputStream();

+            /* This constructor not available until Java 1.6:
            inputStream = new PipedInputStream(outPipe, maxBytes);
            */
            try {
+                inputStream = new PipedInputStream(outPipe);
+                while ((i =
+                        origStream
                            .read(tarStream.writeBuffer, 0, tarStream
                                .writeBuffer.length)) > 0) {
+                    outPipe.write(tarStream.writeBuffer, 0, i);
                }

+                outPipe.flush();    // Do any good on a pipe?

+                dataSize = inputStream.available();

+                if (TarFileOutputStream.debug) {
+                    System.out.println(
                        RB.stream_buffer_report.getString(
                                Long.toString(dataSize)));
                }
+            } catch (IOException ioe) {
+                close();

+                throw ioe;
            } finally {
+                try {
+                    outPipe.close();
                } finally {
+                    outPipe = null;  // Encourage buffer GC
                }
            }

+            modTime = new java.util.Date().getTime() / 1000L;
        }