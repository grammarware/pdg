/**
     * This will get an AFM object if one exists.
     *
     * @return The afm object from the name.
     *
     */
    protected FontMetric getAFM()
    {
+        if(afm==null){
+            COSBase baseFont = font.getDictionaryObject( COSName.BASE_FONT );
+            String name = null;
+            if( baseFont instanceof COSName )
            {
+                name = ((COSName)baseFont).getName();
+                if (name.indexOf("+") > -1)
                {
+                    name = name.substring(name.indexOf("+")+1);
                }

            }
+            else if( baseFont instanceof COSString )
            {
+                COSString string = (COSString)baseFont;
+                name = string.getString();
            }
+            if( name != null )
            {
+                afm = afmObjects.get( name );
            }
        }
        return afm;
    }