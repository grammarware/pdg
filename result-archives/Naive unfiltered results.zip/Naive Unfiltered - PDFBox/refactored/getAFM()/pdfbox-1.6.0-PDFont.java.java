/**
     * This will get an AFM object if one exists.
     *
     * @return The afm object from the name.
     *
     */
    protected FontMetric getAFM()
    {
+        if(isType1Font() && afm==null){
+            COSBase baseFont = font.getDictionaryObject( COSName.BASE_FONT );
+            String name = null;
+            if( baseFont instanceof COSName )
            {
+                name = ((COSName)baseFont).getName();
+                if (name.indexOf("+") > -1)
                {
+                    name = name.substring(name.indexOf("+")+1);
                }

            }
+            else if( baseFont instanceof COSString )
            {
+                COSString string = (COSString)baseFont;
+                name = string.getString();
            }
+            if( name != null )
            {
+                afm = afmObjects.get( name );
            }
        }
        return afm;
    }
/**
     * This will get the subtype of font, Type1, Type3, ...
     *
     * @return The type of font that this is.
     */
    public String getSubType()
    {
+        if (subtype == null) {
+            subtype = font.getNameAsString( COSName.SUBTYPE );
            type1Font = "Type1".equals(subtype);
            trueTypeFont = "TrueType".equals(subtype);
            typeFont = type1Font || "Type0".equals(subtype) || trueTypeFont;
        }
        return subtype;
    }