/**
     * You should override this method if you want to perform an action when a
     * text is being processed.
     *
     * @param text The text to process
     */
    protected void processTextPosition( TextPosition text )
    {
        try
        {
+            switch(this.getGraphicsState().getTextState().getRenderingMode()) {
+                case PDTextState.RENDERING_MODE_FILL_TEXT:
+                    graphics.setComposite( this.getGraphicsState().getNonStrokeJavaComposite() );
+                    graphics.setColor( this.getGraphicsState().getNonStrokingColor().getJavaColor() );
+                    break;
+                case PDTextState.RENDERING_MODE_STROKE_TEXT:
+                    graphics.setComposite( this.getGraphicsState().getStrokeJavaComposite() );
+                    graphics.setColor( this.getGraphicsState().getStrokingColor().getJavaColor() );
+                    break;
+                case PDTextState.RENDERING_MODE_NEITHER_FILL_NOR_STROKE_TEXT:
+                    //basic support for text rendering mode "invisible"
+                    Color nsc = this.getGraphicsState().getStrokingColor().getJavaColor();
+                    float[] components = {Color.black.getRed(),Color.black.getGreen(),Color.black.getBlue()};
+                    Color  c = new Color(nsc.getColorSpace(),components,0f);
+                    graphics.setComposite( this.getGraphicsState().getStrokeJavaComposite() );
+                    graphics.setColor(c);
+                    break;
+                default:
                    // TODO : need to implement....
+                    log.debug("Unsupported RenderingMode "
+                            + this.getGraphicsState().getTextState().getRenderingMode()
                            + " in PageDrawer.processTextPosition()."
                            + " Using RenderingMode "
                            + PDTextState.RENDERING_MODE_FILL_TEXT
                            + " instead");
+                    graphics.setComposite( this.getGraphicsState().getNonStrokeJavaComposite() );
+                    graphics.setColor( this.getGraphicsState().getNonStrokingColor().getJavaColor() );
            }

+            PDFont font = text.getFont();
+            Matrix textPos = text.getTextPos().copy();
+            float x = textPos.getXPosition();
+            // the 0,0-reference has to be moved from the lower left (PDF) to the upper left (AWT-graphics)
+            float y = pageSize.height - textPos.getYPosition();
            // Set translation to 0,0. We only need the scaling and shearing
+            textPos.setValue(2, 0, 0);
+            textPos.setValue(2, 1, 0);
            // because of the moved 0,0-reference, we have to shear in the opposite direction
+            textPos.setValue(0, 1, (-1)*textPos.getValue(0, 1));
+            textPos.setValue(1, 0, (-1)*textPos.getValue(1, 0));
+            AffineTransform at = textPos.createAffineTransform();
+            PDMatrix fontMatrix = font.getFontMatrix();
+            at.scale(fontMatrix.getValue(0, 0) * 1000f, fontMatrix.getValue(1, 1) * 1000f);
+            graphics.setClip(getGraphicsState().getCurrentClippingPath());
            // the fontSize is no longer needed as it is already part of the transformation
            // we should remove it from the parameter list in the long run
+            font.drawString( text.getCharacter(), graphics, 1, at, x, y );
        }
+        catch( IOException io )
        {
+            io.printStackTrace();
        }
    }