/**
     * Fill the path.
     *
     * @param windingRule The winding rule this path will use.
     * 
     * @throws IOException If there is an IO error while filling the path.
     */
    public void fillPath(int windingRule) throws IOException
    {
+        graphics.setComposite(getGraphicsState().getNonStrokeJavaComposite());
+        graphics.setColor( getGraphicsState().getNonStrokingColor().getJavaColor() );
        getLinePath().setWindingRule(windingRule);
+        graphics.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF );
+        graphics.setClip(getGraphicsState().getCurrentClippingPath());
+        graphics.fill( getLinePath() );
        getLinePath().reset();
    }