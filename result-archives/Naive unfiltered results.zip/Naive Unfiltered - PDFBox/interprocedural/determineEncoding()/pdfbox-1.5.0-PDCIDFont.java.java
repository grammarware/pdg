@Override
    protected void determineEncoding()
    {
+        String cidSystemInfo = getCIDSystemInfo();
+        if (cidSystemInfo != null) 
        {
+            if (cidSystemInfo.contains("Identity"))
            {
+                cidSystemInfo = "Identity-H";
            }
            else
            {
+                cidSystemInfo = cidSystemInfo.substring(0,cidSystemInfo.lastIndexOf("-"))+"-UCS2";
            }
+            cmap = cmapObjects.get( cidSystemInfo );
+            if (cmap == null)
            {
+                String resourceName = resourceRootCMAP + cidSystemInfo;
+                try {
+                    parseCmap( resourceRootCMAP, ResourceLoader.loadResource( resourceName ), null );
+                    if( cmap == null)
                    {
+                        log.error("Error: Could not parse predefined CMAP file for '" + cidSystemInfo + "'" );
                    }
                }
+                catch(IOException exception) 
                {
+                    log.error("Error: Could not find predefined CMAP file for '" + cidSystemInfo + "'" );
                }
            }
        }
        else
        {
+            super.determineEncoding();
        }
    }
+/**
     * Extract the CIDSystemInfo.
     * @return the CIDSystemInfo as String
     */
    private String getCIDSystemInfo()
    {
+        String cidSystemInfo = null; 
        COSDictionary cidsysteminfo = (COSDictionary)font.getDictionaryObject(COSName.CIDSYSTEMINFO);
+        if (cidsysteminfo != null) 
        {
+            String ordering = cidsysteminfo.getString(COSName.ORDERING);
+            String registry = cidsysteminfo.getString(COSName.REGISTRY);
+            int supplement = cidsysteminfo.getInt(COSName.SUPPLEMENT);
+            cidSystemInfo = registry + "-" + ordering+ "-" + supplement;
        }
+        return cidSystemInfo;
    }