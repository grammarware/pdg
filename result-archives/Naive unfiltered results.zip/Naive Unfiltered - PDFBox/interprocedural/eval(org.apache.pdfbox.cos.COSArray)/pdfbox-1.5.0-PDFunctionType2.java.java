+/**
     * Returns the C0 values of the function, 0 if empty.
     * @return a COSArray with the C0 values
     */
    public COSArray getC0()
    {
+        if(C0 == null)
        {
+            C0 = (COSArray)getDictionary().getDictionaryObject( COSName.C0 );
+            if ( C0 == null )
            {
+                // C0 is optional, default = 0
                C0 = new COSArray();
+                C0.add( new COSFloat( 0 ) );
            }
        }
+        return C0;
    }
+/**
     * Returns the C1 values of the function, 1 if empty.
     * @return a COSArray with the C1 values
     */
    public COSArray getC1()
    {
+        if(C1 == null)
        {
+            C1 = (COSArray)getDictionary().getDictionaryObject( COSName.C1 );
+            if( C1 == null )
            {
+                // C1 is optional, default = 1
                C1 = new COSArray();
+                C1.add( new COSFloat( 1 ) );
            }      
        }            
+        return C1;
    }
/**
    * {@inheritDoc}
    */
    public COSArray eval(COSArray input) throws IOException
    {
        //This function performs exponential interpolation.
        //It uses only a single value as its input, but may produce a multi-valued output.
        //See PDF Reference section 3.9.2.
                
        double inputValue = input.toFloatArray()[0];
        double exponent = getN();
+        COSArray c0 = getC0();
+        COSArray c1 = getC1();
+        COSArray functionResult = new COSArray();
        int c0Size = c0.size();
+        for (int j=0;j<c0Size;j++)
        {
+            //y[j] = C0[j] + x^N*(C1[j] - C0[j])
            float result = ((COSFloat)c0.get(j)).floatValue() + (float)Math.pow(inputValue,exponent)*(((COSFloat)c1.get(j)).floatValue() - ((COSFloat)c0.get(j)).floatValue());
+            functionResult.add( new COSFloat( result));
        }
        // clip to range if available
        return clipToRange(functionResult);
    }