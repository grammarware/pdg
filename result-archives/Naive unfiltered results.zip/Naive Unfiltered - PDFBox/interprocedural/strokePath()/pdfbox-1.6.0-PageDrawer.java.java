+/**
     * Get the current line path to be drawn.
     *
     * @return The current line path to be drawn.
     */
    public GeneralPath getLinePath()
    {
+        return linePath;
    }
/**
     * Stroke the path.
     *
     * @throws IOException If there is an IO error while stroking the path.
     */
    public void strokePath() throws IOException
    {
+        graphics.setComposite(getGraphicsState().getStrokeJavaComposite());
+        graphics.setColor( getGraphicsState().getStrokingColor().getJavaColor() );
+        graphics.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF );
+        graphics.setClip(getGraphicsState().getCurrentClippingPath());
+        GeneralPath path = getLinePath();
+        graphics.draw( path );
+        path.reset();
    }