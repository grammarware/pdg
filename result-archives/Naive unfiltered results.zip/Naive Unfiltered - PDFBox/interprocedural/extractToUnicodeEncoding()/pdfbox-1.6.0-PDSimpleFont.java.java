private void extractToUnicodeEncoding()
    {
        COSName encodingName = null;
        String cmapName = null;
+        COSBase toUnicode = getToUnicode();
+        if( toUnicode != null )
        {
+            setHasToUnicode(true);
+            if ( toUnicode instanceof COSStream )
            {
+                try {
+                    parseCmap(null, ((COSStream)toUnicode).getUnfilteredStream());
                }
+                catch(IOException exception) 
                {
+                    log.error("Error: Could not load embedded CMAP" );
                }
            }
+            else if ( toUnicode instanceof COSName)
            {
+                encodingName = (COSName)toUnicode;
+                cmap = cmapObjects.get( encodingName.getName() );
+                if (cmap == null) 
                {
+                    cmapName = encodingName.getName();
+                    String resourceName = resourceRootCMAP + cmapName;
+                    try {
+                        parseCmap( resourceRootCMAP, ResourceLoader.loadResource( resourceName ));
                    }
+                    catch(IOException exception) 
                    {
+                        log.error("Error: Could not find predefined CMAP file for '" + cmapName + "'" );
                    }
+                    if( cmap == null)
                    {
+                        log.error("Error: Could not parse predefined CMAP file for '" + cmapName + "'" );
                    }
                }
            }
        }
    }