public COSBase getCOSObject()
    {
+        COSDictionary dict = new COSDictionary();
+        COSArray arr = new COSArray();
+        for (Entry<Integer, PDPageLabelRange> i : labels.entrySet())
        {
+            arr.add(COSInteger.get(i.getKey()));
+            arr.add(i.getValue());
        }
+        dict.setItem("Nums", arr);
        return dict;
    }