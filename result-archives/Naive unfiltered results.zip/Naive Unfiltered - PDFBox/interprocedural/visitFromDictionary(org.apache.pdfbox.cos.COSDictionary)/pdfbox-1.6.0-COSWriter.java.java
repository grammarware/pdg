/**
     * This will set the current object number.
     *
     * @param newNumber The new object number.
     */
+    protected void setNumber(long newNumber)
    {
+        number = newNumber;
    }
/**
     * visitFromObjRef method comment.
     *
     * @param obj The object that is being visited.
     *
     * @throws COSVisitorException If there is an exception while visiting this object.
     */
+    public void writeReference(COSBase obj) throws COSVisitorException
    {
+        try
        {
+            COSObjectKey  key = getObjectKey(obj);
+            getStandardOutput().write(String.valueOf(key.getNumber()).getBytes("ISO-8859-1"));
+            getStandardOutput().write(SPACE);
+            getStandardOutput().write(String.valueOf(key.getGeneration()).getBytes("ISO-8859-1"));
+            getStandardOutput().write(SPACE);
+            getStandardOutput().write(REFERENCE);
        }
+        catch (IOException e)
        {
+            throw new COSVisitorException(e);
        }
    }
/**
     * visitFromDictionary method comment.
     *
     * @param obj The object that is being visited.
     *
     * @throws COSVisitorException If there is an exception while visiting this object.
     *
     * @return null
     */
+    public Object visitFromDictionary(COSDictionary obj) throws COSVisitorException
    {
+        try
        {
+            getStandardOutput().write(DICT_OPEN);
+            getStandardOutput().writeEOL();
+            for (Map.Entry<COSName, COSBase> entry : obj.entrySet())
            {
+                COSBase value = entry.getValue();
+                if (value != null)
                {
+                    entry.getKey().accept(this);
+                    getStandardOutput().write(SPACE);
+                    if( value instanceof COSDictionary )
                    {
+                        COSDictionary dict = (COSDictionary)value;
                        
+                        // write all XObjects as direct objects, this will save some size
+                        COSBase item = dict.getItem(COSName.XOBJECT);
+                        if(item!=null)
                        {
+                            item.setDirect(true);
                        }
+                        item = dict.getItem(COSName.RESOURCES);
+                        if(item!=null)
                        {
+                            item.setDirect(true);
                        }

+                        if(dict.isDirect()) 
                        {
                            // If the object should be written direct, we need
                            // to pass the dictionary to the visitor again.
+                            visitFromDictionary(dict);
                        }
                        else 
                        {
+                            addObjectToWrite( dict );
+                            writeReference( dict );
                        }
                    }
+                    else if( value instanceof COSObject )
                    {
+                        COSBase subValue = ((COSObject)value).getObject();
+                        if( subValue instanceof COSDictionary || subValue == null )
                        {
+                            addObjectToWrite( value );
+                            writeReference( value );
                        }
                        else
                        {
+                            subValue.accept( this );
                        }
                    }
                    else
                    {
+                        // If we reach the pdf signature, we need to determinate the position of the
                        // content and byterange
+                        if(reachedSignature && COSName.CONTENTS.equals(entry.getKey()))
                        {
                            signaturePosition = new int[2];
                            signaturePosition[0] = (int)getStandardOutput().getPos();
+                            value.accept(this);
                            signaturePosition[1] = (int)getStandardOutput().getPos();
                        }
+                        else if(reachedSignature && COSName.BYTERANGE.equals(entry.getKey()))
                        {
                            byterangePosition = new int[2];
                            byterangePosition[0] = (int)getStandardOutput().getPos()+1;
+                            value.accept(this);
                            byterangePosition[1] = (int)getStandardOutput().getPos()-1;
                            reachedSignature = false;
                        }
                        else
                        {
+                            value.accept(this);
                        }
                    }
+                    getStandardOutput().writeEOL();

                }
                else
                {
                    //then we won't write anything, there are a couple cases
                    //were the value of an entry in the COSDictionary will
                    //be a dangling reference that points to nothing
                    //so we will just not write out the entry if that is the case
                }
            }
+            getStandardOutput().write(DICT_CLOSE);
+            getStandardOutput().writeEOL();
+            return null;
        }
+        catch( IOException e )
        {
+            throw new COSVisitorException(e);
        }
    }
+private void addObjectToWrite( COSBase object )
    {
+        COSBase actual = object;
+        if( actual instanceof COSObject )
        {
+            actual = ((COSObject)actual).getObject();
        }

+        if( !writtenObjects.contains( object ) &&
            !objectsToWriteSet.contains( object ) &&
            !actualsAdded.contains( actual ) )
        {
+            COSBase cosBase=null;
+            COSObjectKey cosObjectKey = null;
+            if(actual != null)
+                cosObjectKey= objectKeys.get(actual);
          
+            if(cosObjectKey!=null)
+                cosBase = keyObject.get(cosObjectKey);
          
+            if(actual != null && objectKeys.containsKey(actual) &&
                    !object.isNeedToBeUpdate() && (cosBase!= null &&
                    !cosBase.isNeedToBeUpdate()))
            {
                return;
            }
          
+            objectsToWrite.add( object );
+            objectsToWriteSet.add( object );
+            if( actual != null )
            {
+                actualsAdded.add( actual );
            }
        }
    }
+/**
     * This will get the current object number.
     *
     * @return The current object number.
     */
    protected long getNumber()
    {
+        return number;
    }
+/**
     * This will get the standard output stream.
     *
     * @return The standard output stream.
     */
    protected COSStandardOutputStream getStandardOutput()
    {
+        return standardOutput;
    }
+/**
     * This will get the object key for the object.
     *
     * @param obj The object to get the key for.
     *
     * @return The object key for the object.
     */
+    private COSObjectKey getObjectKey( COSBase obj )
    {
+        COSBase actual = obj;
+        if( actual instanceof COSObject )
        {
+            actual = ((COSObject)obj).getObject();
        }
+        COSObjectKey key = null;
+        if( actual != null )
        {
+            key = objectKeys.get(actual);
        }
+        if( key == null )
        {
+            key = objectKeys.get(obj);
        }
+        if (key == null)
        {
+            setNumber(getNumber()+1);
+            key = new COSObjectKey(getNumber(),0);
+            objectKeys.put(obj, key);
+            if( actual != null )
            {
+                objectKeys.put(actual, key);
            }
        }
+        return key;
    }