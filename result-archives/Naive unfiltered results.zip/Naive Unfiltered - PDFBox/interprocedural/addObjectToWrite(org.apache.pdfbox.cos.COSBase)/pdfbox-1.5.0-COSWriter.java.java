private void addObjectToWrite( COSBase object )
    {
+        COSBase actual = object;
+        if( actual instanceof COSObject )
        {
+            actual = ((COSObject)actual).getObject();
        }

+        if( !writtenObjects.contains( object ) &&
            !objectsToWriteSet.contains( object ) &&
            !actualsAdded.contains( actual ) )
        {
+            objectsToWrite.add( object );
+            objectsToWriteSet.add( object );
+            if( actual != null )
            {
+                actualsAdded.add( actual );
            }
        }
    }