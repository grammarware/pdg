/**
     * Draw the AWT image. Called by Invoke.
     * Moved into PageDrawer so that Invoke doesn't have to reach in here for Graphics as that breaks extensibility.
     *
     * @param awtImage The image to draw.
     * @param at The transformation to use when drawing.
     * 
     */
    public void drawImage(Image awtImage, AffineTransform at){
+        graphics.setComposite(getGraphicsState().getStrokeJavaComposite());
+        graphics.setClip(getGraphicsState().getCurrentClippingPath());
+        graphics.drawImage( awtImage, at, null );
    }