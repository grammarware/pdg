/**
     * {@inheritDoc}
     */
    public PDRectangle getFontBoundingBox() throws IOException
    {
+        if( this.fontBBox == null )
        {
+            this.fontBBox = new PDRectangle(getFontMetric().getFontBBox());
        }

        return this.fontBBox;
    }