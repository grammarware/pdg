+/**
     * Returns the default apperance of a textbox. If the textbox
     * does not have one, then it will be taken from the AcroForm.
     * @return The DA element
     */
    private COSString getDefaultAppearance()
    {

+        COSString dap = parent.getDefaultAppearance();
+        if (dap == null)
        {
+            COSArray kids = (COSArray)parent.getDictionary().getDictionaryObject( "Kids" );
+            if( kids != null && kids.size() > 0 )
            {
+                COSDictionary firstKid = (COSDictionary)kids.getObject( 0 );
+                dap = (COSString)firstKid.getDictionaryObject( "DA" );
            }
+            if( dap == null )
            {
+                dap = (COSString) acroForm.getDictionary().getDictionaryObject(COSName.getPDFName("DA"));
            }
        }
+        return dap;
    }