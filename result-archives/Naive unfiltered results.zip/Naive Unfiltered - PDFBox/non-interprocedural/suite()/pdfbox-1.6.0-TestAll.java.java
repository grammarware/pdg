/**
     * This will get the suite of test that this class holds.
     *
     * @return All of the tests that this class holds.
     */
    public static Test suite()
    {
+        TestSuite suite = new TestSuite();
+        suite.addTest( TestDateUtil.suite() );
+        suite.addTest( TestMatrix.suite() );
+        suite.addTestSuite( TestFilters.class );
+        suite.addTest( TestFDF.suite() );
+        suite.addTest( TestFields.suite() );
+        suite.addTest( TestCOSString.suite() );
+        suite.addTest( TestCOSInteger.suite() );
+        suite.addTest( TestCOSFloat.suite() );
+        suite.addTestSuite( TestPDDocumentCatalog.class );
+        suite.addTestSuite( TestPDDocumentInformation.class );
+        suite.addTestSuite( org.apache.pdfbox.pdmodel.graphics.optionalcontent.TestOptionalContentGroups.class );
+        suite.addTestSuite( org.apache.pdfbox.util.TestLayerUtility.class );
+        suite.addTestSuite( org.apache.pdfbox.TestTextToPdf.class );
        return suite;
    }