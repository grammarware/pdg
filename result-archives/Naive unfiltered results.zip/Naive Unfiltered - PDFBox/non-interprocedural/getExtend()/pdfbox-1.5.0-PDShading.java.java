/**
    * Returns the Extend array used by several of the gradient types. Interpretation depends on the ShadingType.
    * Default is {false, false}.
    *
    * @return The Extend array.
    */
    public COSArray getExtend()
    {
        COSArray arExtend=(COSArray)(DictShading.getDictionaryObject("Extend"));
+        if (arExtend == null)
        {
+            arExtend = new COSArray();
+            arExtend.add(COSBoolean.FALSE);
+            arExtend.add(COSBoolean.FALSE);
        }
        
        return arExtend;
    }