/**
    * Returns the Extend array used by several of the gradient types. Interpretation depends on the ShadingType.
    * Default is {false, false}.
    *
    * @return The Extend array.
    */
    public COSArray getExtend()
    {
+        if (extend == null)
        {
+            extend = (COSArray)(DictShading.getDictionaryObject(COSName.EXTEND));
+            // use default values
            if (extend == null)
            {
+                extend = new COSArray();
+                extend.add(COSBoolean.FALSE);
+                extend.add(COSBoolean.FALSE);
            }
        }
        return extend;
    }