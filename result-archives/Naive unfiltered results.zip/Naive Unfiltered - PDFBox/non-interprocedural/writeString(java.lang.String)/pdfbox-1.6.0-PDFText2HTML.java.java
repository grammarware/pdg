/**
     * Escape some HTML characters.
     *
     * @param chars String to be escaped
     * @return returns escaped String.
     */
    private String escape(String chars)
    {
    	StringBuilder builder = new StringBuilder(chars.length());
+        for (int i = 0; i < chars.length(); i++) 
        {
+            char c = chars.charAt(i);
+            // write non-ASCII as named entities
            if ((c < 32) || (c > 126)) 
            {
+                int charAsInt = c;
                builder.append("&#").append(charAsInt).append(";");
            } 
            else 
            {
+                switch (c) 
                {
+                case 34:
                    builder.append("&quot;");
+                    break;
+                case 38:
                    builder.append("&amp;");
+                    break;
+                case 60:
                    builder.append("&lt;");
+                    break;
+                case 62:
                    builder.append("&gt;");
+                    break;
+                default:
                    builder.append(String.valueOf(c));
                }
            }
        }
        return builder.toString();
    }