/**
     * Write a string to the output stream and escape some HTML characters.
     *
     * @param chars String to be written to the stream
     * @throws IOException
     *             If there is an error writing to the stream.
     */
    protected void writeString(String chars) throws IOException 
    {
+        for (int i = 0; i < chars.length(); i++) 
        {
+            char c = chars.charAt(i);
+            // write non-ASCII as named entities
            if ((c < 32) || (c > 126)) 
            {
+                int charAsInt = c;
                super.writeString("&#" + charAsInt + ";");
            } 
            else 
            {
+                switch (c) 
                {
+                case 34:
                    super.writeString("&quot;");
+                    break;
+                case 38:
                    super.writeString("&amp;");
+                    break;
+                case 60:
                    super.writeString("&lt;");
+                    break;
+                case 62:
                    super.writeString("&gt;");
+                    break;
+                default:
                    super.writeString(String.valueOf(c));
                }
            }
        }
    }