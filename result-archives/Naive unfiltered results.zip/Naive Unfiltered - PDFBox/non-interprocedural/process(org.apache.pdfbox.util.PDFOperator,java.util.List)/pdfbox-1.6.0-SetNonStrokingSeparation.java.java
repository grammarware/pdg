/**
     * scn Set color space for non stroking operations.
     * @param operator The operator that is being executed.
     * @param arguments List
     * @throws IOException If an error occurs while processing the font.
     */
    public void process(PDFOperator operator, List<COSBase> arguments) throws IOException
    {
+        PDColorState colorInstance = context.getGraphicsState().getNonStrokingColor();
+        PDColorSpace colorSpace = colorInstance.getColorSpace();
        
+        if (colorSpace != null) 
        {
+            PDSeparation sep = (PDSeparation) colorSpace;
+            colorSpace = sep.getAlternateColorSpace();
+            COSArray values = sep.calculateColorValues(arguments.get(0));
+            colorInstance.setColorSpaceValue(values.toFloatArray());
        }
    }