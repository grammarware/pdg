private void addDictionaryAndSubDictionary( Set<COSDictionary> set, COSDictionary dic )
    {
+        set.add( dic );
+        COSArray kids = (COSArray)dic.getDictionaryObject( COSName.KIDS );
+        for( int i=0; kids != null && i<kids.size(); i++ )
        {
+            addDictionaryAndSubDictionary( set, (COSDictionary)kids.getObject( i ) );
        }
+        COSBase value = dic.getDictionaryObject( COSName.V );
+        if( value instanceof COSDictionary )
        {
+            addDictionaryAndSubDictionary( set, (COSDictionary)value );
        }
    }