/**
     * This will write the trailer to the PDF document.
     *
     * @param doc The document to create the trailer for.
     *
     * @throws IOException If there is an IOError while writing the document.
     * @throws COSVisitorException If there is an error while generating the data.
     */
    protected void doWriteTrailer(COSDocument doc) throws IOException, COSVisitorException
    {
        getStandardOutput().write(TRAILER);
        getStandardOutput().writeEOL();

+        COSDictionary trailer = doc.getTrailer();
        //sort xref, needed only if object keys not regenerated
        Collections.sort(getXRefEntries());
        COSWriterXRefEntry lastEntry = (COSWriterXRefEntry)getXRefEntries().get( getXRefEntries().size()-1);
+        trailer.setInt(COSName.SIZE, (int)lastEntry.getKey().getNumber()+1);
+        trailer.removeItem( COSName.PREV );
        /**
        COSObject catalog = doc.getCatalog();
        if (catalog != null)
        {
            trailer.setItem(COSName.getPDFName("Root"), catalog);
        }
        */
+        trailer.accept(this);

        getStandardOutput().write(STARTXREF);
        getStandardOutput().writeEOL();
        getStandardOutput().write(String.valueOf(getStartxref()).getBytes("ISO-8859-1"));
        getStandardOutput().writeEOL();
        getStandardOutput().write(EOF);
    }