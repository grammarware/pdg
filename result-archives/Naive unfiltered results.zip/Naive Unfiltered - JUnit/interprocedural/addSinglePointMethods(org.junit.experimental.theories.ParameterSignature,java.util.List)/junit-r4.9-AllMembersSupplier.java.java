private void addSinglePointMethods(ParameterSignature sig,
			List<PotentialAssignment> list) {
+		for (FrameworkMethod dataPointMethod : fClass
				.getAnnotatedMethods(DataPoint.class)) {
+			Class<?> type= sig.getType();
+			if ((dataPointMethod.producesType(type)))
+				list.add(new MethodParameterValue(dataPointMethod));
		}
	}