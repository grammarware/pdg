+/**
	 * @return the location of this temporary folder.
	 */
	public File getRoot() {
		if (folder == null) {
			throw new IllegalStateException("the temporary folder has not yet been created");
		}
+		return folder;
	}
/**
	 * Returns a new fresh file with the given name under the temporary folder.
	 */
	public File newFile(String fileName) throws IOException {
+		File file= new File(getRoot(), fileName);
+		file.createNewFile();
		return file;
	}