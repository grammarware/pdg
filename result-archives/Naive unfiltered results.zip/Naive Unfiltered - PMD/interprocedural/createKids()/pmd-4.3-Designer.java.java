// each line in the error message becomes a separate tree node
    	private void createKids() {

+    		String message = ((ParseException)item).getMessage();
+            String[] lines = StringUtil.substringsOf(message, PMD.EOL);

+			kids = new ExceptionNode[lines.length];
+			for (int i=0; i<lines.length; i++) {
+				kids[i] = new ExceptionNode(lines[i]);
			}
    	}