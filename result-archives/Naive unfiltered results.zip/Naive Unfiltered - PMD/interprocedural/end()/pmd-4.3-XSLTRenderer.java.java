private Document getDocument(InputStream xml) {
+		try {
+			DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
+			return parser.parse(xml);
+		} catch (ParserConfigurationException e) {
+			e.printStackTrace();
+		} catch (SAXException e) {
+			e.printStackTrace();
+		} catch (IOException e) {
+			e.printStackTrace();
		}
+		return null;
	}
+private void transform(Document doc) {
+		DOMSource source = new DOMSource(doc);
+		this.setWriter(new StringWriter());
+		StreamResult result = new StreamResult(this.outputWriter);
+		try {
+			transformer.transform(source, result);
+		} catch (TransformerException e) {
+			e.printStackTrace();
		}
	}
@Override
	public void end() throws IOException {
		// First we finish the XML report
		super.end();
+		// Now we transform it using XSLT
		Writer writer = super.getWriter();
+		if ( writer instanceof StringWriter ) {
+			StringWriter w = (StringWriter)writer;
+			StringBuffer buffer = w.getBuffer();
+			// FIXME: If we change the encoding in XMLRenderer, we should change this too !
			InputStream xml =  new ByteArrayInputStream(buffer.toString().getBytes(this.encoding));
+			Document doc = this.getDocument(xml);
+			this.transform(doc);
		}
		else {
			// Should not happen !
			new RuntimeException("Wrong writer").printStackTrace();
		}

	}