/**
     * Add all rules by reference from one RuleSet to this RuleSet.  The rules
     * can be added as individual references, or collectively as an all rule
     * reference.
     *
     * @param ruleSet the RuleSet to add
     * @param allRules 
     */
    public void addRuleSetByReference(RuleSet ruleSet, boolean allRules) {
+    	if (ruleSet.getFileName() == null) {
+            throw new RuntimeException("Adding a rule by reference is not allowed with a null rule set file name.");
    	}
+    	RuleSetReference ruleSetReference = new RuleSetReference();
+    	ruleSetReference.setRuleSetFileName(ruleSet.getFileName());
+    	ruleSetReference.setAllRules(allRules);
+    	for(Rule rule: ruleSet.getRules()) {
+    		RuleReference ruleReference = new RuleReference();
+    		ruleReference.setRule(rule);
+    		ruleReference.setRuleSetReference(ruleSetReference);
+    		rules.add(ruleReference);
    	}
    }
public String getFileName() {
+		return fileName;
	}
/**
     * Returns the actual Collection of rules in this ruleset
     *
     * @return a Collection with the rules. All objects are of type {@link Rule}
     */
    public Collection<Rule> getRules() {
+        return rules;
    }