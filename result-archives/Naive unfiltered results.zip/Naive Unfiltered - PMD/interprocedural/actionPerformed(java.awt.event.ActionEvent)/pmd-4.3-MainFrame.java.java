private TargetJDKVersion createJDKVersion() {
+        if (jdk14MenuItem.isSelected()) {
            return new TargetJDK1_4();
+        } else if (jdk13MenuItem.isSelected()) {
            return new TargetJDK1_3();
+        } else if (jdk16MenuItem.isSelected()) {
            return new TargetJDK1_6();
+        } else if (jdk17MenuItem.isSelected()) {
            return new TargetJDK1_7();
        }
        return new TargetJDK1_5();
    }
/**
     * Sets the status bar message
     *
     * @param string the new status, the empty string will be set if the value is <code>null</code>
     */
    private void setStatus(String string) {
+        statusLbl.setText(string == null ? "" : string);
    }
/**
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        long t0, t1;
+        if (command.equals(COMPILE_ACTION)) {
+            try {
+                t0 = System.currentTimeMillis();
+                model.commitSource(sourcePanel.getSourceCode(), createJDKVersion());
+                t1 = System.currentTimeMillis();
+                setStatus(NLS.nls("MAIN.FRAME.COMPILATION.TOOK") + " " + (t1 - t0) + " ms");
+            } catch (ParseException exc) {
+                setStatus(NLS.nls("MAIN.FRAME.COMPILATION.PROBLEM") + " " + exc.toString());
+                new ParseExceptionHandler(this, exc);
            }
+        } else if (command.equals(EVALUATE_ACTION)) {
+            try {
+                t0 = System.currentTimeMillis();
+                model.evaluateXPathExpression(xPathPanel.getXPathExpression(), this);
+                t1 = System.currentTimeMillis();
+                setStatus(NLS.nls("MAIN.FRAME.EVALUATION.TOOK") + " " + (t1 - t0) + " ms");
+            } catch (Exception exc) {
+                setStatus(NLS.nls("MAIN.FRAME.EVALUATION.PROBLEM") + " " + exc.toString());
+                new ParseExceptionHandler(this, exc);
            }
        }
    }