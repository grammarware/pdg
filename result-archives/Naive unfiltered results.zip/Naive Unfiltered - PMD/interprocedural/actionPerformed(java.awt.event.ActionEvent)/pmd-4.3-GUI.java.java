+private void error(String message, Exception e) {
+            if (e != null) {
+                e.printStackTrace();
            }
            JOptionPane.showMessageDialog(GUI.this.frame, message);
        }
public void actionPerformed(ActionEvent e) {
            	adjustLanguageControlsFor(
            			languageConfigFor((String)languageBox.getSelectedItem())
            			);
            }