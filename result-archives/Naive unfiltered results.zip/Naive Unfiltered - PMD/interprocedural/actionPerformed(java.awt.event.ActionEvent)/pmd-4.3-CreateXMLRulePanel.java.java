/**
     * We let our class implement the ActionListener interface
     * and use it to generate the xml code when the user presses
     * the "Create rule XML" button.
     *
     */
    public void actionPerformed(ActionEvent exception) {
        StringBuffer buffer = new StringBuffer(200);
+        appendLn(buffer, "<rule  name=\"" + rulenameField.getText() + '\"');
+        appendLn(buffer, "  message=\"" + rulemsgField.getText() + '\"');
+        appendLn(buffer, "  class=\"" + (xpathQueryArea.getText().length() == 0 ? "" : "net.sourceforge.pmd.rules.XPathRule") + "\">");
+        appendLn(buffer, "  <description>");
+        appendLn(buffer, "  " + ruledescField.getText());
+        appendLn(buffer, "  </description>");
+        if (xpathQueryArea.getText().length() != 0) {
+            appendLn(buffer, "  <properties>");
+            appendLn(buffer, "    <property name=\"xpath\">");
+            appendLn(buffer, "    <value>");
+            appendLn(buffer, "<![CDATA[");
+            appendLn(buffer, xpathQueryArea.getText());
+            appendLn(buffer, "]]>");
+            appendLn(buffer, "    </value>");
+            appendLn(buffer, "    </property>");
+            appendLn(buffer, "  </properties>");
        }
+        appendLn(buffer, "  <priority>3</priority>");
+        appendLn(buffer, "  <example>");
+        appendLn(buffer, "<![CDATA[");
+        appendLn(buffer, codeEditorPane.getText());
+        appendLn(buffer, "]]>");
+        appendLn(buffer, "  </example>");
+        appendLn(buffer, "</rule>");

+        ruleXMLArea.setText(buffer.toString());
        repaint();
    }
private void appendLn(StringBuffer sb, String text) {
+        sb.append(text).append(PMD.EOL);
    }