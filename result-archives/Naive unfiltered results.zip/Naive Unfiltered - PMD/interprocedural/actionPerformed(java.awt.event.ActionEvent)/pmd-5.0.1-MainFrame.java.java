private LanguageVersion getLanguageVersion() {
+        if (jdk14MenuItem.isSelected()) {
            return LanguageVersion.JAVA_14;
+        } else if (jdk13MenuItem.isSelected()) {
            return LanguageVersion.JAVA_13;
+        } else if (jdk16MenuItem.isSelected()) {
            return LanguageVersion.JAVA_16;
+        } else if (jdk17MenuItem.isSelected()) {
            return LanguageVersion.JAVA_16;
        }
        return LanguageVersion.JAVA_15;
    }
/**
     * Sets the status bar message
     *
     * @param string the new status, the empty string will be set if the value is <code>null</code>
     */
    private void setStatus(String string) {
+        statusLbl.setText(string == null ? "" : string);
    }
/**
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        long t0;
        long t1;
+        if (ActionCommands.COMPILE_ACTION.equals(command)) {
+            try {
+                t0 = System.currentTimeMillis();
+                model.commitSource(sourcePanel.getSourceCode(), getLanguageVersion());
+                t1 = System.currentTimeMillis();
+                setStatus(NLS.nls("MAIN.FRAME.COMPILATION.TOOK") + " " + (t1 - t0) + " ms");
+            } catch (ParseException exc) {
+                setStatus(NLS.nls("MAIN.FRAME.COMPILATION.PROBLEM") + " " + exc.toString());
+                new ParseExceptionHandler(this, exc);
            }
+        } else if (ActionCommands.EVALUATE_ACTION.equals(command)) {
+            try {
+                t0 = System.currentTimeMillis();
+                model.evaluateXPathExpression(xPathPanel.getXPathExpression(), this);
+                t1 = System.currentTimeMillis();
+                setStatus(NLS.nls("MAIN.FRAME.EVALUATION.TOOK") + " " + (t1 - t0) + " ms");
+            } catch (Exception exc) {
+                setStatus(NLS.nls("MAIN.FRAME.EVALUATION.PROBLEM") + " " + exc.toString());
+                new ParseExceptionHandler(this, exc);
            }
        }
    }