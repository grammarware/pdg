/**
     * @see ViewerModelListener#viewerModelChanged(ViewerModelEvent)
     */
    public void viewerModelChanged(ViewerModelEvent e) {
+        switch (e.getReason()) {
+            case ViewerModelEvent.CODE_RECOMPILED:
+                tree.setModel(new ASTModel(model.getRootNode()));
+                break;
+            case ViewerModelEvent.NODE_SELECTED:
+                if (e.getSource() != this) {
+                    LinkedList<Node> list = new LinkedList<Node>();
+                    for (Node n = (Node) e.getParameter(); n != null; n = n.jjtGetParent()) {
+                        list.addFirst(n);
                    }
+                    TreePath path = new TreePath(list.toArray());
+                    tree.setSelectionPath(path);
+                    tree.scrollPathToVisible(path);
                }
+                break;
        }
    }