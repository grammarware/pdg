public void mouseReleased(MouseEvent e) {
+                if (e.isPopupTrigger()) {
+                    TreePath path = tree.getClosestPathForLocation(e.getX(), e.getY());
+                    tree.setSelectionPath(path);
+                    JPopupMenu menu = new ASTNodePopupMenu(model, (SimpleNode) path.getLastPathComponent());
+                    menu.show(tree, e.getX(), e.getY());
                }
            }