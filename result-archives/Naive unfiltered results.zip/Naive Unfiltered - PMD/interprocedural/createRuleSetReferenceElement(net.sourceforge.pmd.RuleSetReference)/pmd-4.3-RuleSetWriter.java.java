+private Element createTextElement(String name, String value) {
+		Element element = document.createElement(name);
+		Text text = document.createTextNode(value);
+		element.appendChild(text);
+		return element;
	}
private Element createRuleSetReferenceElement(RuleSetReference ruleSetReference) {
+		Element ruleSetReferenceElement = document.createElement("rule");
+		ruleSetReferenceElement.setAttribute("ref", ruleSetReference.getRuleSetFileName());
+		for (String exclude : ruleSetReference.getExcludes()) {
+			Element excludeElement = createExcludeElement(exclude);
+			ruleSetReferenceElement.appendChild(excludeElement);
		}
		return ruleSetReferenceElement;
	}
+private Element createExcludeElement(String exclude) {
+		return createTextElement("exclude", exclude);
	}