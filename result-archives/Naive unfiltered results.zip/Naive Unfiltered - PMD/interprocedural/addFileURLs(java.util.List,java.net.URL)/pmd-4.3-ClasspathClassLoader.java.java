+private static URL createURLFromPath(String path) throws MalformedURLException {
+		File file = new File(path);
+		return file.getAbsoluteFile().toURI().toURL();
	}
private static void addFileURLs(List<URL> urls, URL fileURL) throws IOException {
		BufferedReader in = null;
		try {
			in = new BufferedReader(new InputStreamReader(fileURL.openStream()));
			String line;
+			while ((line = in.readLine()) != null) {
+				LOG.log(Level.FINE, "Read classpath entry line: <{0}>", line);
+				line = line.trim();
+				if (line.length() > 0) {
+					LOG.log(Level.FINE, "Adding classpath entry: <{0}>", line);
+					urls.add(createURLFromPath(line));
				}
			}
			in.close();
		} finally {
+			if (in != null) {
				try {
+					in.close();
				} catch (IOException e) {
+					LOG.log(Level.SEVERE, "IOException while closing InputStream", e);
				}
			}
		}
	}