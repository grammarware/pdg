public void valueChanged(ListSelectionEvent event) {
        ElementWrapper wrapper = null;
+        if (nodes.size() == 1) {
+            wrapper = (ElementWrapper) nodes.get(0);
+        } else if (nodes.isEmpty()) {
+            return;
+        } else if (nodeList.getSelectedValue() == null) {
+            wrapper = (ElementWrapper) nodes.get(0);
        } else {
+            wrapper = (ElementWrapper) nodeList.getSelectedValue();
        }
+        dfaCanvas.setMethod(wrapper.getNode());
+        dfaCanvas.repaint();
    }