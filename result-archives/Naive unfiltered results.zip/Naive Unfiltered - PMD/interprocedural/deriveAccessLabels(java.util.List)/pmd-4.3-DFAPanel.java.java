+private void addAccessLabel(StringBuffer sb, VariableAccess va) {

+        	if (va.isDefinition()) {
+                sb.append("d(");
+            } else if (va.isReference()) {
+                sb.append("r(");
+            } else if (va.isUndefinition()) {
+                sb.append("u(");
                //continue;  // eo - the u() entries add a lot of clutter to the report
            } else {
+                sb.append("?(");
            }

        	sb.append(va.getVariableName()).append(')');
        }
private String[] deriveAccessLabels(List flow) {

+        	if (flow == null || flow.isEmpty()) return StringUtil.EMPTY_STRINGS;

+        	String[] labels = new String[flow.size()];

+        	for (int i=0; i<labels.length; i++) {
+        		List access = ((IDataFlowNode) flow.get(i)).getVariableAccess();

+        		if (access == null || access.isEmpty()) {
+        			continue;	// leave a null at this slot
        		}

+        		StringBuffer exp = new StringBuffer();
+        		addAccessLabel(exp, (VariableAccess) access.get(0));

+        		for (int k = 1; k < access.size(); k++) {
+        			exp.append(", ");
+        			addAccessLabel(exp, (VariableAccess) access.get(k));
                	}

+                labels[i] = exp.toString();
            }
+        	return labels;
        }