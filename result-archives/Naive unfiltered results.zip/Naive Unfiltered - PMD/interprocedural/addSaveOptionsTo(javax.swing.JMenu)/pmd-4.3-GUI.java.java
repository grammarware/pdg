private void addSaveOptionsTo(JMenu menu) {
    	
        JMenuItem saveItem;
        
+        for (int i=0; i<rendererSets.length; i++) {
+        	saveItem = new JMenuItem("Save as " + rendererSets[i][0]);
+        	saveItem.addActionListener(new SaveListener((Renderer)rendererSets[i][1]));
+        	menu.add(saveItem);
        }
    }