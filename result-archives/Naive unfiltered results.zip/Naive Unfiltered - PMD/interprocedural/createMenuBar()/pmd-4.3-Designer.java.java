private JMenuBar createMenuBar() {
+        JMenuBar menuBar = new JMenuBar();
+        JMenu menu = new JMenu("JDK");
+        ButtonGroup group = new ButtonGroup();

+        for (int i=0; i<sourceTypeSets.length; i++) {
+        	JRadioButtonMenuItem button = new JRadioButtonMenuItem(sourceTypeSets[i][0].toString());
+        	sourceTypeMenuItems[i] = button;
+        	group.add(button);
+        	menu.add(button);
        }
        sourceTypeMenuItems[defaultSourceTypeSelectionIndex].setSelected(true);
+        menuBar.add(menu);

+        JMenu actionsMenu = new JMenu("Actions");
+        JMenuItem copyXMLItem = new JMenuItem("Copy xml to clipboard");
+        copyXMLItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                copyXmlToClipboard();
            }
        });
+        actionsMenu.add(copyXMLItem);
+        JMenuItem createRuleXMLItem = new JMenuItem("Create rule XML");
+        createRuleXMLItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                createRuleXML();
            }
        });
+        actionsMenu.add(createRuleXMLItem);
+        menuBar.add(actionsMenu);

        return menuBar;
    }