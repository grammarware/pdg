private String getSimpleFileName(String fileName) {
+		return fileName.substring(fileName.lastIndexOf(FILE_SEPARATOR) + 1);
	}
/**
	 * {@inheritDoc}
	 */
	@Override
	public void renderFileViolations(Iterator<RuleViolation> violations) throws IOException {
	    classAndMethodName = getProperty(CLASS_AND_METHOD_NAME);
	    fileName = getProperty(FILE_NAME);

+		Writer writer = getWriter();
		if (".method".equals(classAndMethodName)) {
			// working on a directory tree
+			renderDirectoy(writer, violations);
		} else {
			// working on one file
+			renderFile(writer, violations);
		}
	}
+private void renderFile(Writer writer, Iterator<RuleViolation> violations) throws IOException {
+		StringBuilder buf = new StringBuilder();
+		while (violations.hasNext()) {
+			buf.setLength(0);
+			RuleViolation rv = violations.next();
+			buf.append(rv.getDescription()).append(PMD.EOL);
+			buf.append(" at ").append(classAndMethodName).append('(')
					.append(fileName).append(':')
					.append(rv.getBeginLine()).append(')').append(PMD.EOL);
+			writer.write(buf.toString());
		}
	}
+private void renderDirectoy(Writer writer, Iterator<RuleViolation> violations) throws IOException {
+		SourcePath sourcePath = new SourcePath(getProperty(SOURCE_PATH));
+		StringBuilder buf = new StringBuilder();
+		while (violations.hasNext()) {
+			buf.setLength(0);
+			RuleViolation rv = violations.next();
+			buf.append(rv.getDescription() + PMD.EOL);
+			buf.append(" at ").append(
+					getFullyQualifiedClassName(rv.getFilename(), sourcePath)).append(".method(");
+			buf.append(getSimpleFileName(rv.getFilename())).append(':')
					.append(rv.getBeginLine()).append(')').append(PMD.EOL);
+			writer.write(buf.toString());
		}
	}
private String getFullyQualifiedClassName(String fileName, SourcePath sourcePath) {
+		String classNameWithSlashes = sourcePath.clipPath(fileName);
+		String className = classNameWithSlashes.replace(FILE_SEPARATOR.charAt(0), '.');
+		return className.substring(0, className.length() - 5);
	}