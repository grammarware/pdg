private String getSimpleFileName(String in) {
+        return in.substring(in.lastIndexOf(FILE_SEPARATOR) + 1);
    }
+private void render(Writer writer, Iterator<IRuleViolation> violations, String classAndMethod, String file) throws IOException {
+        StringBuffer buf = new StringBuffer();
+        while (violations.hasNext()) {
+            buf.setLength(0);
+            IRuleViolation rv = violations.next();
+            buf.append(rv.getDescription()).append(PMD.EOL);
+            buf.append(" at ").append(classAndMethod).append('(').append(file).append(':').append(rv.getBeginLine()).append(')').append(PMD.EOL);
+            writer.write(buf.toString());
        }
    }
+private void render(Writer writer, Iterator<IRuleViolation> violations, String sourcePathString) throws IOException {
+        SourcePath sourcePath = new SourcePath(sourcePathString);
+        StringBuffer buf = new StringBuffer();
+        while (violations.hasNext()) {
+            buf.setLength(0);
+            IRuleViolation rv = violations.next();
+            buf.append(rv.getDescription() + PMD.EOL);
+            buf.append(" at ").append(getFullyQualifiedClassName(rv.getFilename(), sourcePath)).append(".method(");
+            buf.append(getSimpleFileName(rv.getFilename())).append(':').append(rv.getBeginLine()).append(')').append(PMD.EOL);
+            writer.write(buf.toString());
        }
    }
public void renderFileViolations(Iterator<IRuleViolation> violations) throws IOException {
+        Writer writer = getWriter();
        if (args[4].equals(".method")) {
            // working on a directory tree
            String sourcePath = args[3];
+            render(writer, violations, sourcePath);
            return;
        }
        // working on one file
        String classAndMethodName = args[4];
        String singleFileName = args[5];
+        render(writer, violations, classAndMethodName, singleFileName);
    }
private String getFullyQualifiedClassName(String in, SourcePath sourcePath) {
+        String classNameWithSlashes = sourcePath.clipPath(in);
+        String className = classNameWithSlashes.replace(FILE_SEPARATOR.charAt(0), '.');
+        return className.substring(0, className.length() - 5);
    }