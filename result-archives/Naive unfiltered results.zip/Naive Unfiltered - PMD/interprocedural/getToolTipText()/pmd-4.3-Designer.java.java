public String getToolTipText() {
+			String tooltip = "";
+		    if (node instanceof SimpleNode) {
+		        SimpleNode sn = (SimpleNode)node;
		        tooltip = "Line: " + sn.getBeginLine() + " Column: " + sn.getBeginColumn();
		    }

+		    if (node instanceof AccessNode)
		    {
+		    	AccessNode accessNode = (AccessNode)node;
+		    	if ( ! "".equals(tooltip))
+		    		tooltip += ",";
+		    	tooltip += accessNode.isAbstract() ? " Abstract" : "";
+		    	tooltip += accessNode.isStatic() ? " Static" : "";
+		    	tooltip += accessNode.isFinal() ? " Final" : "";
+		    	tooltip += accessNode.isNative() ? " Native" : "";
+		    	tooltip += accessNode.isPrivate() ? " Private" : "";
+		    	tooltip += accessNode.isSynchronized() ? " Synchronised" : "";
+		    	tooltip += accessNode.isTransient() ? " Transient" : "";
+		    	tooltip += accessNode.isVolatile() ? " Volatile" : "";
+		    	tooltip += accessNode.isStrictfp() ? " Strictfp" : "";
		    }
		    return tooltip;
		}