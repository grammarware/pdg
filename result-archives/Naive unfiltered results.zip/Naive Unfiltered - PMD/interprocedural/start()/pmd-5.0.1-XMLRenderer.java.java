private void createVersionAttr(StringBuilder buffer) {
+    	buffer.append("<pmd version=\"").append(PMD.VERSION).append('"');
    }
private void createTimestampAttr(StringBuilder buffer) {
+		buffer.append(" timestamp=\"").append(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(new Date()))
			.append('"');
    }
/**
     * {@inheritDoc}
     */
    @Override
    public void start() throws IOException {
		String encoding = getProperty(ENCODING);

+		Writer writer = getWriter();
		StringBuilder buf = new StringBuilder(500);
		buf.append("<?xml version=\"1.0\" encoding=\"" + encoding + "\"?>").append(PMD.EOL);
+		createVersionAttr(buf);
+		createTimestampAttr(buf);
		// FIXME: elapsed time not available until the end of the processing
		//buf.append(createTimeElapsedAttr(report));
		buf.append('>').append(PMD.EOL);
+		writer.write(buf.toString());
    }