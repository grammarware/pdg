public void merge(Report r) {
+        Iterator<ProcessingError> i = r.errors();
+        while (i.hasNext()) {
+            addError(i.next());
        }
+        Iterator<Metric> m = r.metrics();
+        while (m.hasNext()) {
+            addMetric(m.next());
        }
+        Iterator<RuleViolation> v = r.iterator();
+        while (v.hasNext()) {
+            RuleViolation violation = v.next();
            int index = Collections.binarySearch(violations, violation, RuleViolationComparator.INSTANCE);
+            violations.add(index < 0 ? -index - 1 : index, violation);
+            violationTree.addRuleViolation(violation);
        }
+        Iterator<SuppressedViolation> s = r.getSuppressedRuleViolations().iterator();
+        while (s.hasNext()) {
+            suppressedRuleViolations.add(s.next());
        }
    }
public void addMetric(Metric metric) {
+        metrics.add(metric);
+        for (ReportListener listener: listeners) {
+            listener.metricAdded(metric);
        }
    }
public void addError(ProcessingError error) {
    	if (errors == null) errors = new ArrayList<ProcessingError>();
+        errors.add(error);
    }