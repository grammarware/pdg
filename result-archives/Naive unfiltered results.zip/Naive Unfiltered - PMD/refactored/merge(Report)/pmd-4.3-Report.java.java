public void merge(Report r) {
+        Iterator<ProcessingError> i = r.errors();
+        while (i.hasNext()) {
+            addError(i.next());
        }
+        Iterator<Metric> m = r.metrics();
+        while (m.hasNext()) {
+            addMetric(m.next());
        }
+        Iterator<IRuleViolation> v = r.iterator();
+        while (v.hasNext()) {
+            IRuleViolation violation = v.next();
+            violations.add(violation);
+            violationTree.addRuleViolation(violation);
        }
+        Iterator<SuppressedViolation> s = r.getSuppressedRuleViolations().iterator();
+        while (s.hasNext()) {
+            suppressedRuleViolations.add(s.next());
        }
    }
public void addMetric(Metric metric) {
+        metrics.add(metric);
+        for (ReportListener listener: listeners) {
+            listener.metricAdded(metric);
        }
    }
public void addError(ProcessingError error) {
+        errors.add(error);
    }