public void apply(List acuList, RuleContext ctx) {
        long start = System.nanoTime();
+        for (Rule rule: rules) {
+            if (!rule.usesRuleChain()) {
+                rule.apply(acuList, ctx);
+                long end = System.nanoTime();
+                Benchmark.mark(Benchmark.TYPE_RULE, rule.getName(), end - start, 1);
+                start = end;
            }
        }
    }