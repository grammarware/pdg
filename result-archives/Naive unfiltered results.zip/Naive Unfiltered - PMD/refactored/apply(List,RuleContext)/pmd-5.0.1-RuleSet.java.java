public void apply(List<? extends Node> acuList, RuleContext ctx) {
		long start = System.nanoTime();
+		for (Rule rule : rules) {
            try {
+                if (!rule.usesRuleChain() && applies(rule, ctx.getLanguageVersion())) {
+                    rule.apply(acuList, ctx);
+                    long end = System.nanoTime();
                    Benchmarker.mark(Benchmark.Rule, rule.getName(), end - start, 1);
+                    start = end;
                }
            } catch (ThreadDeath td) {
                throw td;
            } catch (Throwable t) {
+                LOG.log(Level.WARNING, "Exception applying rule " + rule.getName() + ", continuing with next rule", t);
            }
		}
	}