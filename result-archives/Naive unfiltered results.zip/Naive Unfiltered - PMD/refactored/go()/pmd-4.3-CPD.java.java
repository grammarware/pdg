public void go() {
        TokenEntry.clearImages();
+        matchAlgorithm = new MatchAlgorithm(source, tokens, minimumTileSize, listener);
+        matchAlgorithm.findMatches();
    }