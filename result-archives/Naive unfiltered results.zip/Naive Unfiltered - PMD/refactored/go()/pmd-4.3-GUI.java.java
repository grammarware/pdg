private void setListDataFrom(Iterator iter) {

+    	resultsTable.setModel(tableModelFrom(matches));
    	
+    	TableColumnModel colModel = resultsTable.getColumnModel();
+    	TableColumn column;
+    	int width;
    	
+    	for (int i=0; i<matchColumns.length; i++) {
+    		if (matchColumns[i].width() > 0) {
+    			column = colModel.getColumn(i);
+    			width = matchColumns[i].width();
+    			column.setPreferredWidth(width);
+    			column.setMinWidth(width);
+    			column.setMaxWidth(width);
    		}
    	}    	
    }
+private String setLabelFor(Match match) {
    	
+    	Set<String> sourceIDs = new HashSet<String>(match.getMarkCount());
+    	for (Iterator<TokenEntry> occurrences = match.iterator(); occurrences.hasNext();) {
+             sourceIDs.add(occurrences.next().getTokenSrcID());
          }
+    	String label;
    	
+    	if (sourceIDs.size() == 1) {
+    		String sourceId = sourceIDs.iterator().next();
+    		int separatorPos = sourceId.lastIndexOf(File.separatorChar);
+    		label = "..." + sourceId.substring(separatorPos);
    		} else {
+    	    	label = "(" + sourceIDs.size() + " separate files)";
    		}
    		
+    	match.setLabel(label);
+    	return label;
    }
private void go() {
    	String dirPath = rootDirectoryField.getText();
        try {
+            if (!(new File(dirPath)).exists()) {
+                JOptionPane.showMessageDialog(frame,
                        "Can't read from that root source directory",
+                        "Error", JOptionPane.ERROR_MESSAGE);
+                return;
            }
      
+            setProgressControls(true);

+            Properties p = new Properties();
+            p.setProperty(JavaTokenizer.IGNORE_LITERALS, String.valueOf(ignoreLiteralsCheckbox.isSelected()));
+            p.setProperty(LanguageFactory.EXTENSION, extensionField.getText());
+            LanguageConfig conf = languageConfigFor((String)languageBox.getSelectedItem());
+            Language language = conf.languageFor(new LanguageFactory(), p);
+            CPD cpd = new CPD(Integer.parseInt(minimumLengthField.getText()), language);
+            cpd.setEncoding(encodingField.getText());
+            cpd.setCpdListener(this);
+            tokenizingFilesBar.setMinimum(0);
+            phaseLabel.setText("");
+            if (isLegalPath(dirPath, conf)) {	// should use the language file filter instead?
+            	cpd.add(new File(dirPath));
            } else {
+                if (recurseCheckbox.isSelected()) {
+                    cpd.addRecursively(dirPath);
                } else {
+                    cpd.addAllInDirectory(dirPath);
                }
            }
+            final long start = System.currentTimeMillis();
+            Timer t = new Timer(1000, new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    long now = System.currentTimeMillis();
                    long elapsedMillis = now - start;
                    long elapsedSeconds = elapsedMillis / 1000;
                    long minutes = (long) Math.floor(elapsedSeconds / 60);
                    long seconds = elapsedSeconds - (minutes * 60);
                    timeField.setText(munge(String.valueOf(minutes)) + ':' + munge(String.valueOf(seconds)));
                }

                private String munge(String in) {
                    if (in.length() < 2) {
                        in = "0" + in;
                    }
                    return in;
                }
            });
+            t.start();
+            cpd.go();
+            t.stop();
            
+        	matches = new ArrayList<Match>();
+        	Match match;
+        	for (Iterator<Match> i = cpd.getMatches(); i.hasNext();) {
+        		match = i.next();
+        		setLabelFor(match);
+        		matches.add(match);
        	}

+            String report = new SimpleRenderer().render(cpd.getMatches());
+            if (report.length() == 0) {
+                JOptionPane.showMessageDialog(frame,
                        "Done; couldn't find any duplicates longer than " + minimumLengthField.getText() + " tokens");
            } else {
+                resultsTextArea.setText(report);
+                setListDataFrom(cpd.getMatches());
                
            }
+        } catch (IOException t) {
+            t.printStackTrace();
+            JOptionPane.showMessageDialog(frame, "Halted due to " + t.getClass().getName() + "; " + t.getMessage());
+        } catch (RuntimeException t) {
+            t.printStackTrace();
+            JOptionPane.showMessageDialog(frame, "Halted due to " + t.getClass().getName() + "; " + t.getMessage());
        }
+        setProgressControls(false);
    }
private boolean isLegalPath(String path, LanguageConfig config) {
+    	String[] extensions = config.extensions();
+    	for (int i=0; i<extensions.length; i++) {
+    		if (path.endsWith(extensions[i]) && extensions[i].length() > 0) return true;
    	}
+    	return false;
    }
private static LanguageConfig languageConfigFor(String label) {
+		return (LanguageConfig)langConfigsByLabel.get(label);
	}
private void setProgressControls(boolean isRunning) {
+        progressPanel.setVisible(isRunning);
+        goButton.setEnabled(!isRunning);
+        cancelButton.setEnabled(isRunning);
    }
private TableModel tableModelFrom(final List<Match> items) {
    	
+    	TableModel model = new SortingTableModel<Match>() {
    		
    		private int sortColumn;
    		private boolean sortDescending;
    		
    		 public Object getValueAt(int rowIndex, int columnIndex) {
    			Match match = items.get(rowIndex);
    			switch (columnIndex) {
    				case 0: return match.getLabel();
    				case 2: return Integer.toString(match.getLineCount());
    				case 1: return match.getMarkCount() > 2 ? Integer.toString(match.getMarkCount()) : "";
    				case 99: return match;
    				}
    			return "";
    		 	}
			public int getColumnCount() { return matchColumns.length;	}
			public int getRowCount() {	return items.size(); }
			public boolean isCellEditable(int rowIndex, int columnIndex) {	return false;	}
			public Class<?> getColumnClass(int columnIndex) { return Object.class;	}
			public void setValueAt(Object aValue, int rowIndex, int columnIndex) {	}
			public String getColumnName(int i) {	return matchColumns[i].label();	}
			public void addTableModelListener(TableModelListener l) { }
			public void removeTableModelListener(TableModelListener l) { }
			public int sortColumn() { return sortColumn; };
			public void sortColumn(int column) { sortColumn = column; };
			public boolean sortDescending() { return sortDescending; };
			public void sortDescending(boolean flag) { sortDescending = flag; };
			public void sort(Comparator<Match> comparator) { 
				Collections.sort(items, comparator);
				if (sortDescending) Collections.reverse(items);
				}
    		};
    	
+    	return model;
    }