public void add(List<File> files) throws IOException {
+        for (File f: files) {
+            add(files.size(), f);
        }
    }
private void add(int fileCount, File file) throws IOException {

+        if (configuration.skipDuplicates()) {
+            // TODO refactor this thing into a separate class
            String signature = file.getName() + '_' + file.length();
+            if (current.contains(signature)) {
+                System.err.println("Skipping " + file.getAbsolutePath() + " since it appears to be a duplicate file and --skip-duplicate-files is set");
+                return;
            }
+            current.add(signature);
        }

+        if (!file.getCanonicalPath().equals(new File(file.getAbsolutePath()).getCanonicalPath())) {
+            System.err.println("Skipping " + file + " since it appears to be a symlink");
+            return;
        }

+        listener.addedFile(fileCount, file);
+        SourceCode sourceCode = configuration.sourceCodeFor(file);
+        configuration.tokenizer().tokenize(sourceCode, tokens);
+        source.put(sourceCode.getFileName(), sourceCode);
    }
private void addDirectory(String dir, boolean recurse) throws IOException {
+        if (!(new File(dir)).exists()) {
+            throw new FileNotFoundException("Couldn't find directory " + dir);
        }
+        FileFinder finder = new FileFinder();
        // TODO - could use SourceFileSelector here
+        add(finder.findFilesFrom(dir, configuration.filenameFilter(), recurse));
    }