public void valueChanged(ListSelectionEvent e) {
+                if (list.getSelectedValue() != null) {
+                    model.selectNode((SimpleNode) list.getSelectedValue(), EvaluationResultsPanel.this);
                }
            }