private String maybeWrap(String filename, String line) {
+		if (StringUtil.isEmpty(linkPrefix)) {
+		    return filename;
		}
+		String newFileName = filename;
		int index = filename.lastIndexOf('.');
		if (index >= 0) {
		    newFileName = filename.substring(0, index).replace('\\', '/');
		}
+		return "<a href=\"" + linkPrefix + newFileName + ".html#" + line + "\">" + newFileName + "</a>";
    }