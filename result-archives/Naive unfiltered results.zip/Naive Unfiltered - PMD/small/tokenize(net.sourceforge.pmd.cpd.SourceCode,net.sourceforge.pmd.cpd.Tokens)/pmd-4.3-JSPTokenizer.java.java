public void tokenize(SourceCode tokens, Tokens tokenEntries) {
        StringBuffer buffer = tokens.getCodeBuffer();
        JspParserTokenManager tokenMgr = new JspParserTokenManager(new JspCharStream(new StringReader(buffer.toString())));
        Token currentToken = tokenMgr.getNextToken();
+        while (currentToken.image.length() > 0) {
+            tokenEntries.add(new TokenEntry(String.valueOf(currentToken.kind), tokens.getFileName(), currentToken.beginLine));
            currentToken = tokenMgr.getNextToken();
        }
        tokenEntries.add(TokenEntry.getEOF());
    }