public Map<String, Integer> getCountSummary() {
+        Map<String, Integer> summary = new HashMap<String, Integer>();
+        for (Iterator<IRuleViolation> iter = violationTree.iterator(); iter.hasNext();) {
+            IRuleViolation rv = iter.next();
+            String key = "";
            if (rv.getPackageName() != null && rv.getPackageName().length() != 0) {
                key = rv.getPackageName() + '.' + rv.getClassName();
            }
+            Integer o = summary.get(key);
+            if (o == null) {
+                summary.put(key, NumericConstants.ONE);
            } else {
+                summary.put(key, o+1);
            }
        }
        return summary;
    }