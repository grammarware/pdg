public Map<String, Integer> getCountSummary() {
+        Map<String, Integer> summary = new HashMap<String, Integer>();
+        for (Iterator<RuleViolation> iter = violationTree.iterator(); iter.hasNext();) {
+            RuleViolation rv = iter.next();
+            String key = keyFor(rv);
+            Integer o = summary.get(key);
+            summary.put(key, o==null ? NumericConstants.ONE : o+1);
        }
        return summary;
    }