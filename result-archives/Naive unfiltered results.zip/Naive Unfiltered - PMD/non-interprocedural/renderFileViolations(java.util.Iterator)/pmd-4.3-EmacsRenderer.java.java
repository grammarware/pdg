public void renderFileViolations(Iterator<IRuleViolation> violations) throws IOException {
+        Writer writer = getWriter();
+        StringBuffer buf = new StringBuffer();
+        while (violations.hasNext()) {
+            IRuleViolation rv = violations.next();
+            buf.setLength(0);
+            buf.append(EOL).append(rv.getFilename());
+            buf.append(':').append(Integer.toString(rv.getBeginLine()));
+            buf.append(": ").append(rv.getDescription());
+            writer.write(buf.toString());
        }
    }