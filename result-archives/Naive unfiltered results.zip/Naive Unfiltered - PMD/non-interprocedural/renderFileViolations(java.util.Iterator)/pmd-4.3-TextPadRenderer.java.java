public void renderFileViolations(Iterator<IRuleViolation> violations) throws IOException {
+        Writer writer = getWriter();
+        StringBuffer buf = new StringBuffer();
+        while (violations.hasNext()) {
+            IRuleViolation rv = violations.next();
+            buf.setLength(0);
            //Filename
+            buf.append(PMD.EOL).append(rv.getFilename() + "(");
            //Line number
+            buf.append(Integer.toString(rv.getBeginLine())).append(",  ");
            //Name of violated rule
+            buf.append(rv.getRule().getName()).append("):  ");
            //Specific violation message
+            buf.append(rv.getDescription());
+            writer.write(buf.toString());
        }
    }