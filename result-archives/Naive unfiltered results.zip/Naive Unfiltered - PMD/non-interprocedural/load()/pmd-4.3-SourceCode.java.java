protected List<String> load() {
            LineNumberReader lnr = null;
            try {
+                lnr = new LineNumberReader(getReader());
+                List<String> lines = new ArrayList<String>();
+                String currentLine;
+                while ((currentLine = lnr.readLine()) != null) {
+                    lines.add(currentLine);
                }
+                return lines;
+            } catch (Exception e) {
+                e.printStackTrace();
                throw new RuntimeException("Problem while reading " + getFileName() + ":" + e.getMessage());
            } finally {
                try {
+                    if (lnr != null)
+                        lnr.close();
                } catch (Exception e) {
                    throw new RuntimeException("Problem while reading " + getFileName() + ":" + e.getMessage());
                }
            }
        }