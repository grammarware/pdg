/**
	 * Construct a String Filter using set of include and exclude regular
	 * expressions.  If there are no include regular expressions provide, then
	 * a regular expression is added which matches every String by default.
	 * A String is included as long as it matches an include regular expression
	 * and does not match an exclude regular expression.
	 * <p>
	 * In other words, exclude patterns override include patterns.
	 * 
	 * @param includeRegexes The include regular expressions.  May be <code>null</code>.
	 * @param excludeRegexes The exclude regular expressions.  May be <code>null</code>.
	 * @return A String Filter.
	 */
	public static Filter<String> buildRegexFilterExcludeOverInclude(List<String> includeRegexes,
			List<String> excludeRegexes) {
+		OrFilter<String> includeFilter = new OrFilter<String>();
+		if (includeRegexes == null || includeRegexes.isEmpty()) {
+			includeFilter.addFilter(new RegexStringFilter(".*"));
		} else {
+			for (String includeRegex : includeRegexes) {
+				includeFilter.addFilter(new RegexStringFilter(includeRegex));
			}
		}

+		OrFilter<String> excludeFilter = new OrFilter<String>();
+		if (excludeRegexes != null) {
+			for (String excludeRegex : excludeRegexes) {
+				excludeFilter.addFilter(new RegexStringFilter(excludeRegex));
			}
		}

		return new AndFilter<String>(includeFilter, new NotFilter<String>(excludeFilter));
	}